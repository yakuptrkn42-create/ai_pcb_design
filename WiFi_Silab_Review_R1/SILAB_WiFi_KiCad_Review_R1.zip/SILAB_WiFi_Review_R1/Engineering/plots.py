from pathlib import Path
import os,json,math
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parents[1]/'.runtime/mpl');os.environ.update(XDG_CONFIG_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/config'),XDG_CACHE_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/cache'),XDG_DATA_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/data'))
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Polygon
from matplotlib.lines import Line2D
import pcbnew as P
R=Path(__file__).resolve().parents[1];V=R/'Views';b=P.LoadBoard(str(R/'Original/silab_wifi.kicad_pcb'));inv=json.loads((R/'Verification/PCB_Inventory.json').read_text())
xy=lambda q:(P.ToMM(q.x),P.ToMM(q.y))
def color(net):
 if not net:return '#e09000'
 if net=='GND':return '#8b949a'
 if net in ['LT8609_REG_3V3','Net_548','Untitled','Net_14']:return '#d94c4c'
 if 'UART' in net:return '#2076b0'
 return '#37a075'
fig,axes=plt.subplots(1,2,figsize=(13,7))
for ax,layer,title in zip(axes,[P.F_Cu,P.B_Cu],['Top: actual pad / route geometry','Bottom: viewed from top (not mirrored)']):
 ax.set_aspect('equal');ax.set_xlim(129,168);ax.set_ylim(124.5,85.3);ax.set_facecolor('#fbfbf8');ax.set_title(title)
 for d in b.GetDrawings():
  a=xy(d.GetStart());c=xy(d.GetEnd());ax.plot([a[0],c[0]],[a[1],c[1]],color='#222',lw=1.3)
 for t in b.GetTracks():
  if type(t).__name__=='PCB_VIA':
   x,y=xy(t.GetPosition());ax.add_patch(Circle((x,y),P.ToMM(t.GetDrill())/2,facecolor='white',edgecolor='#8e9599',lw=.35));continue
  if t.GetLayer()!=layer:continue
  a=xy(t.GetStart());c=xy(t.GetEnd());ax.plot([a[0],c[0]],[a[1],c[1]],color=color(t.GetNetname()),lw=max(.5,P.ToMM(t.GetWidth())*4),solid_capstyle='round')
 for f in b.GetFootprints():
  for p in f.Pads():
   if not p.IsOnLayer(layer):continue
   x,y=xy(p.GetPosition());w,h=P.ToMM(p.GetSize().x),P.ToMM(p.GetSize().y)
   # Pad orientations are multiples of 90 deg in this source.
   if round(abs(p.GetOrientationDegrees()))%180==90:w,h=h,w
   ax.add_patch(Rectangle((x-w/2,y-h/2),w,h,facecolor=color(p.GetNetname()),edgecolor='white',lw=.25,alpha=.85))
  if f.GetLayer()!=layer:continue
  ref=f.GetReference();x,y=xy(f.GetPosition())
  if ref=='REF**0':ax.text(149,101,'U2 / REF**0\n453-00221R\ninternal RF not exposed',ha='center',va='center',fontsize=8,bbox=dict(facecolor='white',alpha=.9,edgecolor='none'));continue
  offsets={'R207':(-3,-1),'R53':(1,-1),'G1':(-4,1),'C3':(-1,2.2),'C1':(0,3.3),'R211':(2.5,1.3),'C193':(1,-1),'C200':(2,2.7),'C67':(3,-.5),'R4':(-2.5,-1.5),'C201':(-6,-1),'C202':(-6,1),'R213':(-1,-2.5),'C79':(3,0),'C80':(3,1),'J2':(-3,3),'U1':(2,1),'L11':(-3,-2),'R3':(2,1)}
  dx,dy=offsets.get(ref,(1,1));ax.annotate(ref,(x,y),(x+dx,y+dy),fontsize=7,arrowprops=dict(arrowstyle='-',lw=.5,color='#444'),bbox=dict(facecolor='white',alpha=.8,edgecolor='none',pad=.5))
 ax.set_xlabel('PCB X (mm)');ax.set_ylabel('PCB Y (mm)');ax.grid(alpha=.12)
axes[0].add_patch(Circle((150.060267,114.726533),.9,fill=False,edgecolor='#e09000',lw=1.8))
fig.legend(handles=[Line2D([0],[0],color='#d94c4c',lw=3,label='Power-class net names'),Line2D([0],[0],color='#2076b0',lw=3,label='UART-class net names'),Line2D([0],[0],color='#37a075',lw=3,label='Other named nets'),Line2D([0],[0],color='#e09000',lw=3,label='Source pad has no assigned net')],loc='lower center',ncol=2,fontsize=9)
fig.suptitle('silab_wifi — exact source coordinates; ground pour omitted for route visibility',fontsize=13)
fig.tight_layout(rect=(0,.1,1,.95));fig.savefig(V/'PCB_Annotated.png',dpi=180);fig.savefig(V/'PCB_Annotated.pdf');plt.close(fig)
# Conventional first-order microstrip calculation. No actual RF feed is identified.
def z0(w,h,er):
 u=w/h;ee=(er+1)/2+(er-1)/2*(1/math.sqrt(1+12/u)+(0.04*(1-u)**2 if u<1 else 0))
 return 60/math.sqrt(ee)*math.log(8/u+u/4) if u<=1 else 120*math.pi/(math.sqrt(ee)*(u+1.393+.667*math.log(u+1.444)))
lo,hi=.01,20
for _ in range(80):
 mid=(lo+hi)/2
 if z0(mid,1.6,4.2)>50:lo=mid
 else:hi=mid
results={'scope':'Illustrative isolated zero-thickness microstrip model, not actual RF compliance. No board trace has been verified as RF feed. Coplanar GND, soldermask, copper thickness and antenna/module details excluded.','assumed_dielectric_height_mm':1.6,'assumed_Er':4.2,'width_for_50ohm_mm':(lo+hi)/2,'examples':[{'width_mm':w,'Z_ohm':z0(w,1.6,4.2)} for w in [.1524,.2032,.381,.508,(lo+hi)/2]]}
(R/'Verification/RF_Illustrative_Microstrip.json').write_text(json.dumps(results,indent=2));print(results)
