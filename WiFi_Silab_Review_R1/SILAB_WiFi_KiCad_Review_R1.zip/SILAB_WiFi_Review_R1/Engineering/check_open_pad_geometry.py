"""Check physical copper overlap independently of net-code-filtered connectivity APIs."""
from pathlib import Path
import os,json,math
R=Path(__file__).resolve().parents[1]
for k,s in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')]:
 p=R/'.runtime'/s;p.mkdir(parents=True,exist_ok=True);os.environ[k]=str(p)
import pcbnew as P
b=P.LoadBoard(str(R/'Original/silab_wifi.kicad_pcb'));allpads=[p for f in b.GetFootprints() for p in f.Pads()];items=list(b.GetTracks())+allpads;results=[]
for p in [p for p in allpads if not p.GetNetname()]:
 layers=[l for l in [P.F_Cu,P.B_Cu] if p.IsOnLayer(l)];contacts=[];zone_bounds=[]
 for l in layers:
  shape=p.GetEffectiveShape(l)
  for q in items:
   if q.m_Uuid==p.m_Uuid or not q.IsOnLayer(l):continue
   if shape.Collide(q.GetEffectiveShape(l)):
    contacts.append({'type':type(q).__name__,'net':q.GetNetname(),'layer':P.LayerName(l),'uuid':q.m_Uuid.AsString()})
  radius=math.hypot(p.GetSize().x,p.GetSize().y)/2
  for z in b.Zones():
   if not z.IsOnLayer(l):continue
   poly=z.GetFilledPolysList(l);dist=poly.Distance(p.GetPosition())
   zone_bounds.append({'layer':P.LayerName(l),'net':z.GetNetname(),'center_distance_to_fill_mm':dist/1e6,'pad_circumradius_mm':radius/1e6,'conservative_clearance_lower_bound_mm':(dist-radius)/1e6,'guaranteed_no_fill_overlap':dist>radius,'native_pad_vs_fill_shape_collision':shape.Collide(poly) if dist<=radius else False})
 assert not contacts,(p.GetParentFootprint().GetReference(),p.GetNumber(),contacts)
 assert not any(x['native_pad_vs_fill_shape_collision'] for x in zone_bounds),(p.GetParentFootprint().GetReference(),p.GetNumber(),zone_bounds)
 results.append({'ref':p.GetParentFootprint().GetReference(),'pin':p.GetNumber(),'track_via_pad_geometric_contacts':contacts,'filled_zone_clearance_bounds':zone_bounds})
(R/'Verification/Open_Pad_Physical_Geometry.json').write_text(json.dumps({'passed':True,'scope':'Native zero-clearance shape collision with all copper pads/tracks/vias, independent of net code. Filled-zone separation uses center distance minus pad circumradius as a sufficient bound, then exact native shape collision where the bound is inconclusive. Only pad copper layers tested.','open_pad_count':len(results),'results':results},indent=2))
print('PASS:',len(results),'open source pads have no actual pad/track/via collision and are separated from filled GND on their copper layer.')
