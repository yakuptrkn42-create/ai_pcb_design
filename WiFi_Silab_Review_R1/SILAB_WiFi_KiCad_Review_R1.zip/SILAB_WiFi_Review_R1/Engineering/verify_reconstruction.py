from pathlib import Path
import json,hashlib,collections,csv,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1];v=r/'Verification';inventory=json.loads((v/'PCB_Inventory.json').read_text());root=ET.parse(v/'Recovered_Netlist.xml').getroot();mapping={'REF**0':'U2'}
expected={}
for f in inventory['parts']:
 for p in f['pads']:expected[(mapping.get(f['ref'],f['ref']),p['pin'])]=p['net']
actual={};unconn=[]
for n in root.findall('nets/net'):
 name=n.get('name');nodes=n.findall('node')
 for node in nodes:
  key=(node.get('ref'),node.get('pin'))
  assert key not in actual,key
  actual[key]='' if name.startswith('unconnected-(') and len(nodes)==1 else name
  if not actual[key]:unconn.append({'ref':key[0],'pin':key[1],'generated_name':name,'pin_type':node.get('pintype')})
assert expected==actual,{'missing':list(expected.keys()-actual.keys()),'extra':list(actual.keys()-expected.keys()),'different':[(k,expected[k],actual.get(k)) for k in expected if expected[k]!=actual.get(k)]}
cs={c.get('ref'):c for c in root.findall('components/comp')};assert len(cs)==len(inventory['parts'])==20
for f in inventory['parts']:
 c=cs[mapping.get(f['ref'],f['ref'])];assert c.findtext('value')==f['value'];assert c.findtext('footprint')=='Recovered:'+f['footprint']
with (v/'Pin_Net_Comparison.csv').open('w',newline='') as out:
 w=csv.writer(out);w.writerow(['source_ref','schematic_ref','pin','source_net','recovered_net','match'])
 for f in inventory['parts']:
  ref=mapping.get(f['ref'],f['ref'])
  for p in f['pads']:w.writerow([f['ref'],ref,p['pin'],p['net'],actual[(ref,p['pin'])],True])
(v/'PCB_Open_Pads.json').write_text(json.dumps(unconn,indent=2))
drc=json.loads((v/'DRC_Source.json').read_text());erc=json.loads((v/'ERC_Reconstructed.json').read_text());ev=[x for s in erc['sheets'] for x in s['violations']]
source=r/'Original/silab_wifi.kicad_pcb'
from zipfile import ZipFile
with ZipFile(r/'Original/silab_wifi_supplied.zip') as archive:assert source.read_bytes()==archive.read('silab_wifi/silab_wifi.kicad_pcb')
obj={'passed_pin_net_identity':True,'source_components':20,'reconstructed_components':20,'all_values_preserved':True,'all_footprint_shapes_preserved_with_local_library_prefix':True,'numbered_pad_memberships':len(expected),'named_net_memberships':sum(bool(x) for x in expected.values()),'unassigned_source_pad_memberships':sum(not x for x in expected.values()),'named_nets':len(set(expected.values())-{''}),'ref_mapping':mapping,'open_pad_normalization':'Only singleton generated unconnected-(...) nets map to source empty net; Net_0 remains a real named net. NC versus open intent is not inferred.','DRC_source':{'violations':len(drc['violations']),'by_type':dict(collections.Counter(x['type'] for x in drc['violations'])),'by_severity':dict(collections.Counter(x['severity'] for x in drc['violations'])),'assigned_unconnected_items':len(drc['unconnected_items'])},'ERC_reconstructed':{'violations':len(ev),'by_type':dict(collections.Counter(x['type'] for x in ev)),'by_severity':dict(collections.Counter(x['severity'] for x in ev)),'electrical_type_limit':'Module and oscillator pin functions remain unknown/passive; ERC does not verify voltage compatibility, straps, RF or oscillator pin ordering.'},'original_pcb_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_pcb_byte_identical':True,'manufacturer_documents_access':'Blocked by current running proxy policy; draft allowlist additions saved but not yet applied. See References/SOURCE_STATUS.json.'}

if (v/'DRC_Review_Parity.json').exists():
 obj['native_schematic_parity_issues_on_review_copy']=len(json.loads((v/'DRC_Review_Parity.json').read_text())['schematic_parity'])
 obj['review_copy_physical_copper_identity_verified']=True
(v/'Reconstruction_Validation.json').write_text(json.dumps(obj,indent=2));print(json.dumps(obj,indent=2))
