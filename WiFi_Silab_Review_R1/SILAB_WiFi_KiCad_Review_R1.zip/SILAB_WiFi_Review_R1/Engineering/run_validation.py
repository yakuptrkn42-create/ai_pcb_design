"""Run in a COPY of this package: derived Project/Verification files are regenerated.
Linux KiCad 9 Python required: /usr/bin/python3 Engineering/run_validation.py
Known source DRC and open-pin ERC findings are retained, not converted into passes.
"""
from pathlib import Path
import os,sys,subprocess,json
R=Path(__file__).resolve().parents[1]
for key,sub in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('MPLCONFIGDIR','mpl')]:
 p=R/'.runtime'/sub;p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
records=[]
def run(args,allowed=(0,)):
 p=subprocess.run(args,cwd=R,capture_output=True,text=True)
 records.append({'command':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 (R/'Verification/Reproduction_Commands.json').write_text(json.dumps(records,indent=2))
 print(Path(args[0]).name, args[1:3], 'exit',p.returncode,flush=True)
 if p.returncode not in allowed:
  print(p.stdout,p.stderr);raise SystemExit(p.returncode)
py=sys.executable
run([py,'Engineering/inventory.py'])
run([py,'Engineering/generate_schematic.py'])
run(['kicad-cli','sch','export','netlist','--format','kicadxml','-o','Verification/Recovered_Netlist.xml','Project/Recovered_Wifi.kicad_sch'])
run(['kicad-cli','sch','erc','--format','json','--exit-code-violations','-o','Verification/ERC_Reconstructed.json','Project/Recovered_Wifi.kicad_sch'],(0,5))
run(['kicad-cli','pcb','drc','--format','json','--exit-code-violations','-o','Verification/DRC_Source.json','Original/silab_wifi.kicad_pcb'],(0,5))
run([py,'Engineering/link_review_pcb.py'])
run(['kicad-cli','pcb','drc','--schematic-parity','--format','json','--exit-code-violations','-o','Verification/DRC_Review_Parity.json','Project/Recovered_Wifi.kicad_pcb'],(0,5))
run([py,'Engineering/verify_reconstruction.py'])
run([py,'Engineering/engineering_audit.py'])
run([py,'Engineering/check_open_pad_geometry.py'])
run(['kicad-cli','sch','export','pdf','-o','Recovered_Schematic.pdf','Project/Recovered_Wifi.kicad_sch'])
v=json.loads((R/'Verification/Reconstruction_Validation.json').read_text())
assert v['passed_pin_net_identity'] and v['numbered_pad_memberships']==126
assert v['DRC_source']['violations']==38 and v['ERC_reconstructed']['violations']==37
assert v['native_schematic_parity_issues_on_review_copy']==0
print('PASS: package reproduces all 126 pad memberships and 0 parity differences; DRC 38 and ERC 37 findings explicitly remain.')
