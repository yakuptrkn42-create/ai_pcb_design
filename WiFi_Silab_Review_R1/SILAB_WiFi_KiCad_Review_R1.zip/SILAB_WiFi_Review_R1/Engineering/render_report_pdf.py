from pathlib import Path
import re,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
R=Path(__file__).resolve().parents[1];D=R
for name,file in [('DV','DejaVuSans.ttf'),('DV-Bold','DejaVuSans-Bold.ttf'),('DV-Oblique','DejaVuSans-Oblique.ttf')]:pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-Bold',italic='DV-Oblique',boldItalic='DV-Bold')
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='BodyTR',fontName='DV',fontSize=8.5,leading=12,spaceAfter=7))
styles.add(ParagraphStyle(name='TitleTR',fontName='DV-Bold',fontSize=20,leading=24,spaceAfter=13,textColor=colors.HexColor('#174c5b')))
styles.add(ParagraphStyle(name='H2TR',fontName='DV-Bold',fontSize=13,leading=17,spaceBefore=13,spaceAfter=8,textColor=colors.HexColor('#174c5b'),keepWithNext=True))
styles.add(ParagraphStyle(name='H3TR',fontName='DV-Bold',fontSize=10,leading=14,spaceBefore=9,spaceAfter=6,keepWithNext=True))
styles.add(ParagraphStyle(name='SmallTR',fontName='DV',fontSize=7,leading=9,spaceAfter=0))
styles.add(ParagraphStyle(name='MonoTR',fontName='DV',fontSize=7.1,leading=10,backColor=colors.HexColor('#f2f5f6'),spaceAfter=7))
def rich(t):
 t=html.escape(t);t=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',t);t=re.sub(r'`(.*?)`',r'<font color="#1b596b">\1</font>',t)
 return t
lines=(D/'Engineering_Review_TR.md').read_text().splitlines();story=[];i=0
while i<len(lines):
 line=lines[i].strip()
 if not line:i+=1;continue
 if line.startswith('```'):
  code=[];i+=1
  while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
  story.append(Paragraph('<br/>'.join(rich(x).replace(' ','&#160;') for x in code),styles['MonoTR']));i+=1;continue
 if line.startswith('!['):
  path=D/re.search(r'\((.*?)\)',line).group(1);im=Image(str(path));im._restrictSize(510,300);story+=[im,Spacer(1,8)];i+=1;continue
 if line.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].strip().startswith('|'):
   cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
   if not all(re.fullmatch(r':?-+:?',c) for c in cells):rows.append(cells)
   i+=1
  widths=([160,70,280] if len(rows[0])==3 else [175,100,60,175])
  if rows[0][0] in ['Ref','J2 pin']:widths=[55,140,315] if len(rows[0])==3 else widths
  if len(rows[0])==2:widths=[250,260]
  data=[[Paragraph(rich(c),styles['SmallTR']) for c in row] for row in rows]
  table=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT');table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e4eef1')),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#becbd0')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#fafbfc')])]))
  story+=[table,Spacer(1,8)];continue
 if line.startswith('# '):story.append(Paragraph(rich(line[2:]),styles['TitleTR']));i+=1;continue
 if line.startswith('## '):story.append(Paragraph(rich(line[3:]),styles['H2TR']));i+=1;continue
 if line.startswith('### '):story.append(Paragraph(rich(line[4:]),styles['H3TR']));i+=1;continue
 text=[line];i+=1
 while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![','```')) and not re.match(r'^\d+\. |^- ',lines[i]):text.append(lines[i].strip());i+=1
 story.append(Paragraph(rich(' '.join(text)),styles['BodyTR']))
def footer(canvas,doc):
 canvas.saveState();canvas.setStrokeColor(colors.HexColor('#174c5b'));canvas.setLineWidth(.6);canvas.line(42,35,553,35);canvas.setFont('DV',7);canvas.setFillColor(colors.HexColor('#52636c'));canvas.drawString(42,24,'silab_wifi · R1 · Kaynak PCB korunmuştur · Üretim/RF kabulü verilmedi');canvas.drawRightString(553,24,str(doc.page));canvas.restoreState()
doc=SimpleDocTemplate(str(D/'Engineering_Review_TR.pdf'),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=40,bottomMargin=47,title='silab_wifi PCB Bağlantı Kurtarma ve Donanım İncelemesi',author='Engineering review')
doc.build(story,onFirstPage=footer,onLaterPages=footer);print('Report PDF rendered')
