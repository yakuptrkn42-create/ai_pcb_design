from pathlib import Path
import os
os.environ.update(XDG_CONFIG_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/config'),XDG_CACHE_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/cache'),XDG_DATA_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/data'))
import pcbnew as P,json,collections,hashlib
r=Path(__file__).resolve().parents[1];b=P.LoadBoard(str(r/'Original/silab_wifi.kicad_pcb'))
parts=[]
for f in sorted(b.GetFootprints(),key=lambda f:f.GetReference()):
 ps=[]
 for p in f.Pads():
  ps.append({'pin':p.GetNumber(),'net':p.GetNetname(),'netcode':p.GetNetCode(),'xy_mm':[P.ToMM(p.GetPosition().x),P.ToMM(p.GetPosition().y)],'size_mm':[P.ToMM(p.GetSize().x),P.ToMM(p.GetSize().y)],'drill_mm':[P.ToMM(p.GetDrillSize().x),P.ToMM(p.GetDrillSize().y)],'attribute':p.GetAttribute(),'layers':p.GetLayerSet().FmtBin()})
 parts.append({'ref':f.GetReference(),'value':f.GetValue(),'footprint':f.GetFPID().GetUniStringLibId(),'sheetpath':f.GetPath().AsString(),'uuid':f.m_Uuid.AsString(),'xy_mm':[P.ToMM(f.GetPosition().x),P.ToMM(f.GetPosition().y)],'rotation':f.GetOrientationDegrees(),'side':f.GetLayerName(),'pads':ps})
 print(parts[-1]['ref'],parts[-1]['value'],parts[-1]['footprint'], [(x['pin'],x['net']) for x in ps])
tracks=[{'type':type(t).__name__,'net':t.GetNetname(),'layer':t.GetLayerName(),'start':[P.ToMM(t.GetStart().x),P.ToMM(t.GetStart().y)],'end':[P.ToMM(t.GetEnd().x),P.ToMM(t.GetEnd().y)],'width':P.ToMM(t.GetWidth(P.F_Cu)) if type(t).__name__=="PCB_VIA" else P.ToMM(t.GetWidth()),'length':P.ToMM(t.GetLength())} for t in b.GetTracks()]
zones=[{'net':z.GetNetname(),'layers':z.GetLayerSet().FmtBin(),'is_rulearea':z.GetIsRuleArea(),'filled':z.IsFilled(),'min_thickness':P.ToMM(z.GetMinThickness()),'clearance':P.ToMM(z.GetLocalClearance())} for z in b.Zones()]
obj={'parts':parts,'tracks':tracks,'zones':zones,'copper_layers':b.GetCopperLayerCount(),'thickness':P.ToMM(b.GetDesignSettings().GetBoardThickness()),'bbox_mm':[P.ToMM(b.GetBoardEdgesBoundingBox().GetWidth()),P.ToMM(b.GetBoardEdgesBoundingBox().GetHeight())],'source_sha256':hashlib.sha256((r/'Original/silab_wifi.kicad_pcb').read_bytes()).hexdigest()}
(r/'Verification/PCB_Inventory.json').write_text(json.dumps(obj,indent=2));print('counts',len(parts),len(tracks),len(zones));print('zones',zones)
