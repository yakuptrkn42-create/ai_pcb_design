from pathlib import Path
import os,json,collections,math,csv
os.environ.update(XDG_CONFIG_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/config'),XDG_CACHE_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/cache'),XDG_DATA_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/data'))
import pcbnew as P
R=Path(__file__).resolve().parents[1];V=R/'Verification';b=P.LoadBoard(str(R/'Original/silab_wifi.kicad_pcb'));b.BuildConnectivity();conn=b.GetConnectivity()
xy=lambda q:[P.ToMM(q.x),P.ToMM(q.y)]
tracks=[t for t in b.GetTracks() if type(t).__name__!='PCB_VIA'];vias=[t for t in b.GetTracks() if type(t).__name__=='PCB_VIA'];fps={f.GetReference():f for f in b.GetFootprints()};module=fps['REF**0']
netrows=[]
for name in sorted({t.GetNetname() for t in tracks+vias}):
 ts=[t for t in tracks if t.GetNetname()==name];vs=[t for t in vias if t.GetNetname()==name]
 # R is aggregate branch copper, not a measured or extracted supply path.
 r_mohm=sum(.017241*P.ToMM(t.GetLength())/(P.ToMM(t.GetWidth())*.035) for t in ts)
 netrows.append({'net':name,'track_segments':len(ts),'track_length_mm':sum(P.ToMM(t.GetLength()) for t in ts),'widths_mm':sorted({P.ToMM(t.GetWidth()) for t in ts}),'through_vias':len(vs),'layer_lengths_mm':{P.LayerName(l):sum(P.ToMM(t.GetLength()) for t in ts if t.GetLayer()==l) for l in [P.F_Cu,P.B_Cu]},'all_branches_aggregate_R20_mohm_if_35um_copper':r_mohm})
# Zone coverage uses native filled polygons, not a rectangular pour outline.
zones=[];ground_polys={}
for z in b.Zones():
 l=z.GetLayer();poly=z.GetFilledPolysList(l)
 zones.append({'net':z.GetNetname(),'layer':P.LayerName(l),'filled_polygons':poly.OutlineCount(),'filled_area_mm2':poly.Area()/1e12,'clearance_mm':P.ToMM(z.GetLocalClearance()),'min_fill_width_mm':P.ToMM(z.GetMinThickness()),'is_keepout':z.GetIsRuleArea()})
 if z.GetNetname()=='GND':ground_polys[l]=poly
coverage=[]
for name in sorted({t.GetNetname() for t in tracks if t.GetNetname()!='GND'}):
 checked=covered=exempt=0;missing=[]
 same_vias=[v for v in vias if v.GetNetname()==name]
 same_pads=[p for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==name]
 for t in [t for t in tracks if t.GetNetname()==name]:
  a=xy(t.GetStart());c=xy(t.GetEnd());steps=max(1,math.ceil(math.dist(a,c)/.1));opposite=P.B_Cu if t.GetLayer()==P.F_Cu else P.F_Cu
  for i in range(steps+1):
   q=[a[k]+(c[k]-a[k])*i/steps for k in [0,1]]
   # Through-via antipads are inevitable at the layer transition. THT pads also clear the opposite plane.
   if any(math.dist(q,xy(v.GetPosition()))<P.ToMM(v.GetWidth(P.F_Cu))/2+.4 for v in same_vias):exempt+=1;continue
   if any(p.IsOnLayer(opposite) and math.dist(q,xy(p.GetPosition()))<max(P.ToMM(p.GetSize().x),P.ToMM(p.GetSize().y))/2+.4 for p in same_pads):exempt+=1;continue
   checked+=1
   if ground_polys[opposite].Contains(P.VECTOR2I(P.FromMM(q[0]),P.FromMM(q[1]))):covered+=1
   elif len(missing)<8:missing.append(q)
 coverage.append({'net':name,'checked_samples':checked,'covered_by_opposite_GND':covered,'not_covered':checked-covered,'exempt_near_same_net_transition':exempt,'covered_percent':100*covered/checked if checked else None,'first_missing_xy_mm':missing})
# All unassigned pads: record direct copper contacts and native zone center membership.
openpads=[]
for f in b.GetFootprints():
 for p in f.Pads():
  if not p.GetNetname():
   openpads.append({'ref':f.GetReference(),'pin':p.GetNumber(),'xy':xy(p.GetPosition()),'direct_connected_pads':[(x.GetParentFootprint().GetReference(),x.GetNumber(),x.GetNetname()) for x in conn.GetConnectedPads(p)],'direct_connected_tracks':[(x.GetNetname(),type(x).__name__) for x in conn.GetConnectedTracks(p)],'center_in_ground_fill':[P.LayerName(l) for l,poly in ground_polys.items() if p.IsOnLayer(l) and poly.Contains(p.GetPosition())]})
# Via centers under module pad copper (SMD pads, source orientation zero).
under=[]
for via in vias:
 for p in module.Pads():
  box=p.GetBoundingBox()
  q=via.GetPosition()
  if box.Contains(q):under.append({'pad':p.GetNumber(),'pad_net':p.GetNetname(),'via_net':via.GetNetname(),'via_xy':xy(q),'diameter_mm':P.ToMM(via.GetWidth(P.F_Cu)),'drill_mm':P.ToMM(via.GetDrill()),'center_in_pad_bbox':True})
# Simple decoupler proximity, NOT power-loop extraction.
proximity=[]
for ref in ['C79','C80','C193','C200','C201','C202','C67']:
 cap=fps[ref];supply=next(p for p in cap.Pads() if p.GetNetname()!='GND');cp=xy(supply.GetPosition());mp=[p for p in module.Pads() if p.GetNetname()==supply.GetNetname()]
 nearest=min(((math.dist(cp,xy(p.GetPosition())),p.GetNumber()) for p in mp),default=(None,None))
 proximity.append({'ref':ref,'net':supply.GetNetname(),'nearest_same_net_module_pin':nearest[1],'straight_line_pad_distance_mm':nearest[0]})
# Footprint courtyard inventory.
cy=[]
for ref,f in fps.items():cy.append({'ref':ref,'courtyard_graphics':sum(g.GetLayer() in [P.F_CrtYd,P.B_CrtYd] for g in f.GraphicalItems()),'3D_models':len(list(f.Models()))})
obj={'board_dimensions_mm':[34.0,34.0],'board_dimension_basis':'Edge.Cuts centerlines; stroked drawing bounding box is 34.12 x 34.12 mm','nominal_board_thickness_mm':P.ToMM(b.GetDesignSettings().GetBoardThickness()),'tracks':len(tracks),'vias':len(vias),'via_dimensions':dict(collections.Counter(str((P.ToMM(v.GetWidth(P.F_Cu)),P.ToMM(v.GetDrill()))) for v in vias)),'net_metrics':netrows,'GND_zones':zones,'opposite_ground_sampling':coverage,'opposite_ground_sampling_scope':'0.1 mm centerline sampling on opposite filled GND only; local transition exclusions; not a field solver, return-path continuity, RF or EMI acceptance test.','open_pads':openpads,'via_centers_in_module_pad_bounding_boxes':under,'decoupler_euclidean_proximity':proximity,'footprint_metadata':cy,'missing_drc_check_source_settings':'missing_courtyard = ignore; min_track_width = 0; min_copper_edge_clearance = 0.06 mm; no verified fabrication stackup or impedance constraints'}
(V/'Engineering_Audit.json').write_text(json.dumps(obj,indent=2))
with (V/'Net_Routing_Metrics.csv').open('w',newline='') as o:
 w=csv.DictWriter(o,fieldnames=list(netrows[0]));w.writeheader();w.writerows(netrows)
print('vias',len(vias),'via dimensions',obj['via_dimensions']);print('zones',zones);print('vias in module pad bboxes',len(under));print('open C3',[p for p in openpads if p['ref']=='C3']);print('coverage',[(p['net'],round(p['covered_percent'],1) if p['covered_percent'] is not None else None) for p in coverage]);print('courtyards',cy)
