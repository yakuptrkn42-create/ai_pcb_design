"""Create an explicitly non-manufacturing review companion. Source file untouched.
Only reference/library/path and singleton-open-net metadata are aligned to schematic.
Copper coordinates, tracks, vias, pads, zones, outline and all multi-pad nets stay fixed.
"""
from pathlib import Path
import os,json,xml.etree.ElementTree as E
os.environ.update(XDG_CONFIG_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/config'),XDG_CACHE_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/cache'),XDG_DATA_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/data'))
import pcbnew as P
R=Path(__file__).resolve().parents[1];V=R/'Verification';project=R/'Project';src=R/'Original/silab_wifi.kicad_pcb';b=P.LoadBoard(str(src));root=E.parse(V/'Recovered_Netlist.xml').getroot();mapping={'REF**0':'U2'}
comps={c.get('ref'):c for c in root.findall('components/comp')};netmap={}
for net in root.findall('nets/net'):
 for n in net.findall('node'):netmap[(n.get('ref'),n.get('pin'))]=net.get('name')
root_uuid='9f4f4bf4-6697-5845-881e-6cb98e8e4c6e';changed=[]
for f in b.GetFootprints():
 old=f.GetReference();ref=mapping.get(old,old);f.SetReference(ref);f.SetFPID(P.LIB_ID('Recovered',str(f.GetFPID().GetLibItemName())))
 c=comps[ref];path=P.KIID_PATH();path.push_back(P.KIID(root_uuid))
 for item in (c.find('sheetpath').get('tstamps').strip('/')+'/'+c.findtext('tstamps').split()[0]).strip('/').split('/'):
  if item:path.push_back(P.KIID(item))
 f.SetPath(path)
 for p in f.Pads():
  if not p.GetNetname():
   n=netmap[(ref,p.GetNumber())];assert n.startswith('unconnected-(')
   net=P.NETINFO_ITEM(b,n);b.Add(net);p.SetNet(net);changed.append({'ref':ref,'pin':p.GetNumber(),'source_net':'','review_singleton_net':n})
P.SaveBoard(str(project/'Recovered_Wifi.kicad_pcb'),b)
# Geometry signatures compare loaded copies independently of UUID or metadata.
c=P.LoadBoard(str(project/'Recovered_Wifi.kicad_pcb'));a=P.LoadBoard(str(src))
def sig(board):
 tracks=[]
 for t in board.GetTracks():
  typ=type(t).__name__;tracks.append((typ,t.GetNetname(),t.GetStart().x,t.GetStart().y,t.GetEnd().x,t.GetEnd().y,t.GetLayer(),t.GetWidth(P.F_Cu) if typ=='PCB_VIA' else t.GetWidth(),t.GetDrill() if typ=='PCB_VIA' else 0))
 pads=[]
 for f in board.GetFootprints():
  for p in f.Pads():
   net=p.GetNetname();net='' if net.startswith('unconnected-(') else net
   pads.append((mapping.get(f.GetReference(),f.GetReference()),p.GetNumber(),net,p.GetPosition().x,p.GetPosition().y,p.GetSize().x,p.GetSize().y,p.GetDrillSize().x,p.GetDrillSize().y,p.GetShape(),p.GetAttribute(),p.GetLayerSet().FmtBin()))
 return sorted(tracks),sorted(pads)
assert sig(a)==sig(c)
(V/'Review_PCB_Metadata_Changes.json').write_text(json.dumps({'not_a_redesign':True,'source_unchanged':True,'copper_and_named_net_signatures_equal':True,'renamed_ref':mapping,'library_prefix':'Recovered','schematic_paths_added':True,'open_singleton_net_metadata':changed},indent=2))
print('Review-only PCB companion created; all track/via/pad copper signatures unchanged.')
