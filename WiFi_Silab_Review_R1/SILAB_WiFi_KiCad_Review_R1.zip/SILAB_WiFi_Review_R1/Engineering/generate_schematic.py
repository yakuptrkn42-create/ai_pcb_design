"""Build an explicitly PCB-derived, five-sheet schematic. Unknown pin types stay passive.
All global net labels retain PCB spelling; open pads remain open, not guessed NC.
"""
from pathlib import Path
import json,uuid,shutil,os,math
os.environ.update(XDG_CONFIG_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/config'),XDG_CACHE_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/cache'),XDG_DATA_HOME=str(Path(__file__).resolve().parents[1]/'.runtime/data'))
import pcbnew as P
R=Path(__file__).resolve().parents[1];D=R;PROJECT=D/'Project';PROJECT.mkdir(exist_ok=True)
parts=json.loads((D/'Verification/PCB_Inventory.json').read_text())['parts'];byref={p['ref']:p for p in parts}
Q=lambda x:json.dumps(str(x),ensure_ascii=False)
U=lambda key:str(uuid.uuid5(uuid.NAMESPACE_URL,'wifi-recovery/'+key))
def eff(size=1.27,justify='',hide=False):return '(effects (font (size %.3f %.3f)) %s %s)'%(size,size,('(justify '+justify+')') if justify else '', '(hide yes)' if hide else '')
# Pin definitions: number, name, type, x, y, angle in library coordinates.
def pin(num,name,kind,x,y,a):return (str(num),name,kind,x,y,a)
def boxsym(name,pins,w,h,ref='U',desc='PCB-derived; pin functions not independently verified',units=None):
 if units is None:units={1:pins}
 body=f'(symbol {Q(name)} (pin_names (offset 0.8)) (exclude_from_sim no) (in_bom yes) (on_board yes)\n'
 body+=f'(property "Reference" {Q(ref)} (at 0 {h/2+3} 0) {eff()})\n(property "Value" {Q(name)} (at 0 {-h/2-3} 0) {eff()})\n(property "Description" {Q(desc)} (at 0 0 0) {eff(hide=True)})\n'
 for unit,ps in units.items():
  body+=f'(symbol {Q(name+"_"+str(unit)+"_1")} (rectangle (start {-w/2} {h/2}) (end {w/2} {-h/2}) (stroke (width 0.254) (type default)) (fill (type background)))\n'
  # Add pins to the same unit body (KiCad accepts repeated sub-symbol? no: combine).
  body=body[:-2]+'\n' if body.endswith(')\n') else body
  for n,label,kind,x,y,a in ps:
   body+=f'(pin {kind} line (at {x} {y} {a}) (length 2.54) (name {Q(label)} {eff(1.0)}) (number {Q(n)} {eff(1.0)}))\n'
  body+=')\n'
 return body+')\n'
# More explicit symbol builder, avoiding unit geometry parsing.
def symbol(name,units,w,h,ref,desc):
 s=f'(symbol {Q(name)} (pin_names (offset 0.8)) (exclude_from_sim no) (in_bom yes) (on_board yes)\n'
 for k,val,y in [('Reference',ref,h/2+3),('Value',name,-h/2-3),('Description',desc,0)]:s+=f'(property {Q(k)} {Q(val)} (at 0 {y} 0) {eff(hide=k=="Description")})\n'
 for u,ps in units.items():
  s+=f'(symbol {Q(name+"_"+str(u)+"_1")} (rectangle (start {-w/2} {h/2}) (end {w/2} {-h/2}) (stroke (width 0.254) (type default)) (fill (type background)))\n'
  # The final ')' above closes only rectangle and sub-symbol. Reopen by removal.
  for n,label,kind,x,y,a in ps:s+=f'(pin {kind} line (at {x} {y} {a}) (length 2.54) (name {Q(label)} {eff(1.0)}) (number {Q(n)} {eff(1.0)}))\n'
  s+=')\n'
 return s+')\n'
SYMS={};PINS={};DIMS={}
def add(name,units,w,h,ref,desc):SYMS[name]=symbol(name,units,w,h,ref,desc);PINS[name]=units;DIMS[name]=(w,h)
add('R',{1:[pin(1,'~','passive',0,5.08,270),pin(2,'~','passive',0,-5.08,90)]},2.54,5.08,'R','Resistor; original value and numbered pads retained')
add('C',{1:[pin(1,'~','passive',0,5.08,270),pin(2,'~','passive',0,-5.08,90)]},5.08,2.54,'C','Capacitor; original value and numbered pads retained')
SYMS['C']=SYMS['C'].replace('(rectangle (start -2.54 1.27) (end 2.54 -1.27) (stroke (width 0.254) (type default)) (fill (type background)))', '(polyline (pts (xy -2.54 1.27) (xy 2.54 1.27)) (stroke (width 0.254) (type default)) (fill (type none))) (polyline (pts (xy -2.54 -1.27) (xy 2.54 -1.27)) (stroke (width 0.254) (type default)) (fill (type none))) (polyline (pts (xy 0 2.54) (xy 0 1.27)) (stroke (width 0.1524) (type default)) (fill (type none))) (polyline (pts (xy 0 -1.27) (xy 0 -2.54)) (stroke (width 0.1524) (type default)) (fill (type none)))')
add('L',{1:[pin(1,'~','passive',-7.62,0,0),pin(2,'~','passive',7.62,0,180)]},10.16,2.54,'L','PCB value does not specify inductance, impedance or current rating')
add('MAX40200',{1:[pin(1,'VDD','power_in',-12.7,5.08,0),pin(3,'EN','input',-12.7,-5.08,0),pin(2,'GND','power_in',0,-10.16,90),pin(4,'NC','no_connect',12.7,-5.08,180),pin(5,'OUT','passive',12.7,5.08,180)]},20.32,15.24,'U','Pin numbering checked against installed KiCad MAX40200AUK symbol; vendor datasheet access pending')
add('G1_PCB',{1:[pin(1,'PAD1','passive',-12.7,5.08,0),pin(2,'PAD2','passive',12.7,5.08,180),pin(3,'PAD3','passive',-12.7,-5.08,0),pin(4,'PAD4','passive',12.7,-5.08,180)]},20.32,15.24,'G','SiT1532 named by PCB; pin functions NOT independently datasheet verified')
add('J2_PCB',{1:[pin(i,'PIN'+str(i),'passive',-15.24,16.51-(i-1)*2.54,0) for i in range(1,15)]},25.4,38.1,'J','Host connector. Signal directions and supply values require host documentation')
module=byref['REF**0'];connected=[p for p in module['pads'] if p['net']];opened=[p for p in module['pads'] if not p['net']]
def modulepins(pads):
 ps=[];half=math.ceil(len(pads)/2)
 for i,p in enumerate(pads):
  left=i<half;j=i if left else i-half
  ps.append(pin(p['pin'],'PAD'+p['pin'],'passive',-30.48 if left else 30.48,24.13-j*2.54,0 if left else 180))
 return ps
add('Module_PCB_71',{1:modulepins(connected),2:modulepins(opened)},55.88,53.34,'U','453-00221R, source REF**0. PAD names/type passive mean unknown function, not manufacturer NC')
add('External_Power',{1:[pin(1,'EXTERNAL_SOURCE','power_out',0,0,90)]},0,0,'#FLG','Power comes from host; source-only marker, not a PCB component')
# External marker should not draw a zero-sized rectangle; use simple power flag-like diamond.
SYMS['External_Power']=SYMS['External_Power'].replace('(in_bom yes) (on_board yes)','(in_bom no) (on_board no)')
SYMS['External_Power']='(symbol "External_Power" (power) (pin_numbers hide) (pin_names (offset 0) hide) (exclude_from_sim no) (in_bom no) (on_board no)\n(property "Reference" "#FLG" (at 0 3 0) (effects (font (size 1.27 1.27)) (hide yes)))\n(property "Value" "PWR_FLAG" (at 0 -3 0) (effects (font (size 1.27 1.27)) (hide yes)))\n(symbol "External_Power_0_1" (polyline (pts (xy 0 0) (xy 0 1.27) (xy -1.27 1.27) (xy 0 2.54) (xy 1.27 1.27) (xy 0 1.27)) (stroke (width 0.1524) (type default)) (fill (type none))))\n(symbol "External_Power_1_1" (pin power_out line (at 0 0 90) (length 0) (name "pwr" (effects (font (size 1.27 1.27)))) (number "1" (effects (font (size 1.27 1.27)))))))\n'
lib='(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor")\n'+''.join(SYMS.values())+')\n'
(PROJECT/'Recovered.kicad_sym').write_text(lib)
(PROJECT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "Recovered") (type "KiCad") (uri "${KIPRJMOD}/Recovered.kicad_sym") (options "") (descr "PCB-derived symbols; see limitations")))\n')
(PROJECT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Recovered") (type "KiCad") (uri "${KIPRJMOD}/Recovered.pretty") (options "") (descr "Footprints exported from source PCB")))\n')
# Reuse existing UUID paths for new schematic, retain source pad identities through mapping.
ROOT=U('root');names=['Recovered_Wifi','02_Power','03_Module_Connected','04_Module_Open_Pads','05_Clock_Control'];sheets={}
for idx,name in enumerate(names):
 sid=ROOT if idx==0 else U(name)
 sheets[name]={'uuid':sid,'path':'/'+ROOT if idx==0 else '/'+ROOT+'/'+U('sheet-'+name),'items':[],'used':set(),'index':idx+1}
def text(sheet,t,x,y,size=1.27):
 sh=sheets[sheet];sh['items'].append(f'(text {Q(t)} (at {x} {y} 0) {eff(size,"left top")} (uuid {U(sheet+"/text/"+str(len(sh["items"])))}))')
def wire(sheet,a,b):
 sh=sheets[sheet];sh['items'].append(f'(wire (pts (xy {a[0]} {a[1]}) (xy {b[0]} {b[1]})) (stroke (width 0) (type default)) (uuid {U(sheet+"/wire/"+str(len(sh["items"])))}))')
def glabel(sheet,net,pt,angle=0):
 sh=sheets[sheet];x,y=pt
 sh['items'].append(f'(global_label {Q(net)} (shape passive) (at {x} {y} {angle}) {eff(1.0,"left" if angle==0 else "right")} (uuid {U(sheet+"/label/"+str(len(sh["items"])))})(property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {x} {y} {angle}) {eff(1.0,hide=True)}))')
def labelpin(sheet,pt,angle,net):
 x,y=pt
 if not net:return
 # Angle 0 is a left-facing pin tip with label further left; 180 the inverse.
 if angle==0:outer=(x-10.16,y);la=180
 elif angle==180:outer=(x+10.16,y);la=0
 elif angle==270:outer=(x,y-5.08);la=0
 else:outer=(x,y+5.08);la=0
 wire(sheet,pt,outer);glabel(sheet,net,outer,la)
def place(sheet,src,sym,x,y,unit=1,ref=None,connect=True):
 sh=sheets[sheet];sh['used'].add(sym)
 part=byref.get(src);ref=ref or src;val=part['value'] if part else 'HOST_SUPPLY';fp='Recovered:'+part['footprint'] if part else ''
 instuid=U(sheet+'/'+ref+'/'+str(unit));h=DIMS[sym][1]
 s=f'(symbol (lib_id {Q("Recovered:"+sym)}) (at {x} {y} 0) (unit {unit}) (exclude_from_sim no) (in_bom {"yes" if part else "no"}) (on_board {"yes" if part else "no"}) (dnp no) (uuid {instuid})\n'
 for k,v,py,hidden in [('Reference',ref,y-h/2-4,False),('Value',val,y+h/2+4,False),('Footprint',fp,y,True),('Datasheet','',y,True),('Source_Reference',src,y,True)]:
  hidden=hidden or part is None
  prop_x=x+6.35 if sym in ['R','C'] and k in ['Reference','Value'] else x
  if sym in ['R','C'] and k=='Reference':py=y-1.9
  if sym in ['R','C'] and k=='Value':py=y+1.9
  s+=f'(property {Q(k)} {Q(v)} (at {prop_x} {py} 0) {eff(1.0,"left" if prop_x!=x else "",hide=hidden)})\n'
 for n,label,kind,px,py,a in PINS[sym][unit]:s+=f'(pin {Q(n)} (uuid {U(instuid+"/pin/"+n)}))\n'
 s+=f'(instances (project "Recovered_Wifi" (path {Q(sh["path"])} (reference {Q(ref)}) (unit {unit}))))\n)'
 sh['items'].append(s)
 if part and connect:
  pads={p['pin']:p['net'] for p in part['pads']}
  for n,label,kind,px,py,a in PINS[sym][unit]:
   pos=(round(x+px,4),round(y-py,4));net=pads[n]
   if not net and kind=='no_connect':
    sh['items'].append(f'(no_connect (at {pos[0]} {pos[1]}) (uuid {U(instuid+"/NC/"+n)}))')
   elif net:labelpin(sheet,pos,a,net)
 return instuid
# Host sheet, visible system explanation and connector table.
s='Recovered_Wifi';text(s,'PCB-BASED RECONSTRUCTION — electrical intent is not certified',15,15,2.0)
text(s,'20 source footprints; module REF**0 is renamed U2 ONLY in this reconstruction.',15,24)
text(s,'Every named PCB net is retained literally. Net_0 is a real named net; it is not an unassigned pad.',15,30)
place(s,'J2','J2_PCB',88.9,83.82)
text(s,'HOST INTERFACE\nJ2 has 14 pads, including four GND pads.\nSignal names are copied from PCB.\nUART naming is not a verified host direction.\nNo USB/SPI/SDIO connector is present.',130,50)
text(s,'POWER PATH\nJ2.1 LT8609_REG_3V3 -> U1 ideal-diode switch -> L11 -> Untitled rail.\nThere is NO LT8609 regulator on this board; the net name refers to the host.\nJ2.12 WIFI_PWR_EN controls U1.3; R3 provides a 100k pull-down.',130,91)
text(s,'KNOWN LIMITS\nThe original schematic is empty. Module and G1 pin functions remain PADn\nuntil exact manufacturer documents can be checked.\nOpen pads are intentionally left open in this reconstruction;\nERC must expose them. No blanket NC markers or rule suppression are used.',130,120)
# Local flag to express host-powered VDD/GND, with supply assumption visible.
for ref,net,x in [('#FLG01','LT8609_REG_3V3',55.88),('#FLG02','GND',96.52)]:
 place(s,ref,'External_Power',x,132.08,ref=ref,connect=False);glabel(s,net,(x,132.08),0)
text(s,'Power flags indicate an assumed external source at J2, not a measured voltage.',18,149,1.0)
# Child sheet rectangles live on root, compact bottom row.
for i,name in enumerate(names[1:]):
 x=17.78+(i%2)*68.58;y=156.21+(i//2)*20.32;sid=U('sheet-'+name)
 sheets[s]['items'].append(f'(sheet (at {x} {y}) (size 60.96 12.7) (exclude_from_sim no) (in_bom yes) (on_board yes) (dnp no) (stroke (width 0.1524) (type solid)) (fill (color 0 0 0 0.0000)) (uuid {sid}) (property "Sheetname" {Q(name)} (at {x} {y-1} 0) {eff(1.0,"left bottom")}) (property "Sheetfile" {Q(name+".kicad_sch")} (at {x} {y+13.7} 0) {eff(1.0,"left top")}) (instances (project "Recovered_Wifi" (path {Q("/"+ROOT)} (page {Q(i+2)})))))')
# Power sheet retains explicit node labels; no guessed L value.
s='02_Power';text(s,'POWER / ENABLE — exact PCB pad connectivity',15,15,2)
place(s,'U1','MAX40200',66.04,55.88);place(s,'L11','L',154.94,50.8)
place(s,'R3','R',66.04,109.22)
text(s,'U1 pin map: installed KiCad MAX40200AUK symbol.\nIdeal diode / enable switch, not a voltage regulator.\nL11 value is only IND_0805_N: inductance, DCR,\nsaturation current and whether it is a bead are UNKNOWN.',180,39)
text(s,'All six capacitors below share PCB net Untitled, not six independent supplies.',15,130,1.3)
for i,ref in enumerate(['C79','C80','C193','C200','C201','C202']):place(s,ref,'C',30.48+i*43.18,146.05)
place(s,'C67','C',213.36,106.68)
text(s,'C67 connects Net_14 to GND; module pads 36 and 54 share Net_14.\nDo not assume this rail is 3.3 V or an output until module pinout is verified.',105,121)
text(s,'Input bulk capacitor, input TVS/fuse and host source impedance are not present as separate components.',15,188,1.0)
# Module connected and open pad units.
s='03_Module_Connected';text(s,'U2 — PCB-CONNECTED PADS (source REF**0 / value 453-00221R)',15,15,1.8)
place(s,'REF**0','Module_PCB_71',124.46,96.52,unit=1,ref='U2')
place(s,'R207','R',238.76,71.12)
place(s,'R53','R',238.76,111.76)
text(s,'PADn names are deliberate: manufacturer pin functions are not verified.\nAll connected pin numbers and net names are preserved from source PCB.\nPin electrical types remain passive where unknown; ERC cannot certify\nvoltage compatibility, boot straps or UART direction for these pins.',15,146)
text(s,'Pad 1 -> R207 (0R) -> GND\nPad 61 -> R53 (0R) -> GND\nTheir functions MUST be checked before calling these RF ports or straps.',15,171)
text(s,'See unit B on next sheet for all physically open pads.\nGround pads 62..71 are real numbered pads, not omitted hidden power pins.',15,187)
s='04_Module_Open_Pads';text(s,'U2 — PCB-OPEN PADS, NOT VERIFIED MANUFACTURER NC',15,15,1.8)
place(s,'REF**0','Module_PCB_71',124.46,93.98,unit=2,ref='U2')
text(s,'These pads have no assigned PCB net and no observed track/pad contact.\nOpen schematic pins reproduce that observation; they are NOT marked NC.\nTheir necessity for boot, power, RF or programming is still unresolved.\nERC pin-not-connected errors are retained intentionally for review.',15,147)
# Control / oscillator sheet.
s='05_Clock_Control';text(s,'CLOCK / CONTROL / POC — topology preserved, functional names conditional',15,15,1.8)
place(s,'G1','G1_PCB',55.88,60.96);place(s,'R213','R',144.78,60.96)
text(s,'G1 has value SiT1532AI-J4-DCC-32.768D.\nPCB pad 2 -> Net_193 -> R213 33R -> Net_554 -> U2.29.\nPCB pad 3 -> Untitled; pads 1 and 4 -> GND.\nThis is observed wiring, not a verified oscillator pinout.',181,44)
place(s,'R211','R',43.18,132.08);place(s,'C1','C',101.6,132.08)
text(s,'R211 100k + C1 10nF: nominal RC = 1 ms.\nNode Net_553 goes to U2.33.\nReset/strap function remains conditional;\nthreshold and internal pulls are not verified.',16,161)
place(s,'R4','R',195.58,127);place(s,'C3','C',254,127)
text(s,'POC_IN -> U2.31 and C3.1.\nR4 10k links POC_IN to Net_0 -> U2.32.\nC3.2 is physically open in source PCB: no return path.\nDo NOT silently connect it to GND in reconstruction.',160,147)
# Root project and all sheet file serialization.
for name,sh in sheets.items():
 used=''.join(SYMS[k].replace('(symbol '+Q(k),'(symbol '+Q('Recovered:'+k),1) for k in sorted(sh['used']))
 head=f'(kicad_sch (version 20250114) (generator "eeschema") (generator_version "9.0") (uuid {sh["uuid"]}) (paper "A4")\n(title_block (title {Q(name+" — PCB-derived review")}) (date "2026-10-23") (rev "R1") (company "Source PCB preserved; see engineering report"))\n(lib_symbols {used})\n'
 ending=f'(sheet_instances (path "/" (page {Q(sh["index"])})))\n(embedded_fonts no))\n' if sh['index']==1 else '(embedded_fonts no))\n'
 (PROJECT/(name+'.kicad_sch')).write_text(head+'\n'.join(sh['items'])+'\n'+ending)
# Project configuration: source physical rules preserved, no ERC severity overrides.
pro=json.loads((R/'Original/silab_wifi.kicad_pro').read_text());pro['meta']['filename']='Recovered_Wifi.kicad_pro';(PROJECT/'Recovered_Wifi.kicad_pro').write_text(json.dumps(pro,indent=2))
# Local footprint library from actual embedded PCB definitions.
b=P.LoadBoard(str(R/'Original/silab_wifi.kicad_pcb'));libdir=PROJECT/'Recovered.pretty';libdir.mkdir(exist_ok=True);saved=set()
for f in b.GetFootprints():
 name=str(f.GetFPID().GetLibItemName())
 if name not in saved:P.PCB_IO_KICAD_SEXPR().FootprintSave(str(libdir),f);saved.add(name)
# Source PCB is included byte-for-byte in its own folder, not edited.
orig=D/'Original';orig.mkdir(exist_ok=True)
# Original source files are never overwritten.
(D/'Verification/Reference_Mapping.json').write_text(json.dumps({'REF**0':'U2','footprint_library_qualification':'Original unqualified IDs -> Recovered:<same footprint name>','source_pcb_unchanged':True,'module_connected_pad_count':len(connected),'module_open_pad_count':len(opened)},indent=2))
print('Generated',len(sheets),'sheets;',len(saved),'local footprints; module connected/open:',len(connected),len(opened))
