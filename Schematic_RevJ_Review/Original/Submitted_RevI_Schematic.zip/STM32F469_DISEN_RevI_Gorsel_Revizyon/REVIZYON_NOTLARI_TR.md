# STM32F469I-DISCO – DISEN LCD | Rev I Şematik Görsel Revizyonu

**Amaç:** Kaynak `Project.zip` içindeki onaylı Rev I elektroniğini, komponentlerini, netlerini ve PCB bağlantılarını değiştirmeden şematiğin çizim düzenini iyileştirmek.

## Düzenlemeler

- **Ana MIPI/konnektör sayfası:** reset/senkronizasyon grubu 4 mm, alt navigasyon grubu 8 mm, sol alt kullanım notları 4 mm yukarı alındı. Başlık ve iki ana konnektör düzeni korundu.
- **Logic & Touch:** sol dokunmatik bloğu 6 mm, alt açıklama bloğu 12 mm, I²C pull-up bloğu 4 mm, alt doğrulama notları 8 mm yukarı taşındı.
- **Backlight:** sürücü ve test noktaları 4 mm, OVP/PWM alt blokları 8 mm yukarı taşındı.
- **Güç gösterimleri:** güç devrelerinin uygun bölgelerinde 10 global güç etiketi, aynı **özgün net adı** olan özel yerel KiCad güç sembolüne dönüştürüldü. Özel semboller `Adapter_F469.kicad_sym` ve ilgili `.kicad_sch` dosyalarının iç gömülü kütüphanelerinde bulunur. `HOST_3V3`, `HOST_TP_3V3`, `LCD_VCI`, `TP_VDD`, `EXT_5V`, `FUSED_5V`, `BL_5V`, `BL_POWER` gibi özgün güç/net adları korunur. **Güç netleri `+3V3` ya da `+5V` olarak yeniden adlandırılmadı; bu değişiklik elektriksel eşdeğerliği bozardı.**
- Konnektörlerin yoğun pin kümelerindeki GND/diğer net etiketleri ve yer darlığı bulunan OVP bölümündeki birkaç güç etiketi, şematik okunabilirliğini korumak için yerinde bırakıldı.

## Elektriksel ve proje karşılaştırması

| Kontrol | Sonuç |
|---|---|
| Fiziksel bileşenler (referans/değer/footprint/UUID) | 49/49 aynı |
| Şematik kablo segmentleri | 184/184 aynı sayıda, aynı UUID'ler |
| Global etiket yerine geçen özel güç sembolleri | 10 adet, özgün net isimleriyle |
| Bağlantı temas noktası tutarlılığı (wire–pin–label/junction) | Statik eşdeğerlik taraması: 0 kopma |
| PCB (`.kicad_pcb`) | SHA/byte bazında aynen korundu |
| Proje ayarları (`.kicad_pro`) | Byte bazında aynen korundu |
| Netlist/ERC kontrolü | **KiCad native araçları bulunmadığından çalıştırılamadı** |

**Önemli:** Statik eşdeğerlik taraması KiCad'in netlist/ERC doğrulamasının yerine geçmez. Yeni özel güç sembollerinin güç pini semantiğini, KiCad 9'da projenin açılması ve ERC ile ayrıca doğrulayınız. Bu çalışma üretime hazır PCB onayı değildir.

## PDF hakkında

`RevI_Sematik_Gorsel_Revizyon.pdf`, güncel `.kicad_sch` nesnelerinden programatik olarak çizilmiş üç sayfalı **görsel teknik önizleme**dir; KiCad'in kendi PDF Plot motorundan alınmış birebir çıktı değildir. Net ve sembol bilgileri CAD dosyalarında yetkili kaynaktır. Nihai dokümantasyon için KiCad 9 içinde **File → Plot → PDF** komutu ile PDF'yi tekrar dışarı aktarmanız önerilir.

## Açılış

1. ZIP'i çıkartın. `STM32F469_DISEN_RevI.kicad_pro` dosyasını KiCad 9 ile açın.
2. `STM32F469_DISEN_RevI.kicad_sch` ana sayfasını, ardından `Logic_Touch.kicad_sch` ve `Backlight.kicad_sch` alt sayfalarını inceleyin.
3. Tools → Electrical Rules Checker'dan kontrolü çalıştırın. Önceki sürümün uyarıları ile karşılaştırın.
4. `STM32F469_DISEN_RevI.kicad_pcb` dosyası **hiç değiştirilmemiştir**. Görsel şematik güncellemesi PCB routing kararı/onayı anlamına gelmez.
