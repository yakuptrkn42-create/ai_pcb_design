#ifndef SENSOR_CONFIG_H
#define SENSOR_CONFIG_H

/* PC5 and PC4 are not used by this project's motor, SDRAM, QSPI, touch or SD.
 * Use MCU signal names; verify their connector positions against your board.
 * Inputs MUST be conditioned to 0..3.3 V. Never connect an unknown sensor
 * supply/output directly to these pins. See SENSOR_ENTEGRASYONU_TR.md. */
#define SENSOR_OPTICAL_PORT GPIOC
#define SENSOR_OPTICAL_PIN  GPIO_PIN_5
#define SENSOR_AIR_PORT     GPIOC
#define SENSOR_AIR_PIN      GPIO_PIN_4
/* Existing onboard LEDs, active LOW: LED1 green and LED3 red. */
#define SENSOR_OPTICAL_LED_PORT GPIOG
#define SENSOR_OPTICAL_LED_PIN  GPIO_PIN_6
#define SENSOR_AIR_LED_PORT     GPIOD
#define SENSOR_AIR_LED_PIN      GPIO_PIN_5

#define SENSOR_OPTICAL_DEBOUNCE_MS 20U
#define SENSOR_AIR_HOLD_MS         2000U
#define SENSOR_STALE_MS             100U
/* No BS241 electrical datasheet was supplied. Digital polarity follows the
 * user observation (HIGH = air), not a verified manufacturer specification.
 * Confirm voltage/output type before wiring; verify the logic on the bench.
 * Set CONFIRMED to 0 to use raw 0/1 commissioning mode instead of air labels. */
#ifndef SENSOR_AIR_ACTIVE_LEVEL
#define SENSOR_AIR_ACTIVE_LEVEL 1U
#endif
#ifndef SENSOR_AIR_POLARITY_CONFIRMED
#define SENSOR_AIR_POLARITY_CONFIRMED 1U
#endif
#if (SENSOR_AIR_ACTIVE_LEVEL > 1U) || (SENSOR_AIR_POLARITY_CONFIRMED > 1U)
#error Sensor air configuration must be 0 or 1
#endif
#endif
