#ifndef SENSOR_MONITOR_H
#define SENSOR_MONITOR_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct {
    uint8_t valid;          /* sampled, optically settled, not stale */
    uint8_t optical_level; /* filtered raw 0/1; 0 = target */
    uint8_t air_level;     /* instantaneous digital input; no volume estimate */
    uint8_t air_configured;
    uint8_t air_warning;   /* live air or captured pulse; held for 2 seconds */
} SensorSnapshot;
void Sensor_Init(void);
void Sensor_Poll(void); /* single writer: defaultTask, once per RTOS tick */
void Sensor_AirIRQ(void); /* EXTI4 only; never touches GUI, RTOS or motor */
SensorSnapshot Sensor_GetSnapshot(void);
#ifdef SIMULATOR
/* Disconnected by default. Explicit injection for simulator/tests only. */
void Sensor_SimulatorSetLevels(uint8_t optical, uint8_t air);
void Sensor_SimulatorSetConnected(uint8_t connected);
void Sensor_SimulatorAdvance(uint32_t milliseconds);
#endif
#ifdef __cplusplus
}
#endif
#endif
