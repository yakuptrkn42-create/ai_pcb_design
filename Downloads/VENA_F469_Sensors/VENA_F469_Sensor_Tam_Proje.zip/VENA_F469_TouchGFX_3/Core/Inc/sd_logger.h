#ifndef SD_LOGGER_H
#define SD_LOGGER_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SDLOGGER_OK = 0,
    SDLOGGER_NO_CARD = 1,
    SDLOGGER_SD_ERROR = 2,
    SDLOGGER_FS_ERROR = 3,
    SDLOGGER_FULL = 4
} SDLoggerStatus;

void SDLogger_Init(void);
SDLoggerStatus SDLogger_LogPatient(const char *name,
                                   const char *code,
                                   const char *ward,
                                   int age,
                                   int gender,
                                   double weight);
SDLoggerStatus SDLogger_LogInfusion(const char *patient,
                                    const char *code,
                                    const char *ward,
                                    const char *drug,
                                    const char *mode,
                                    int age,
                                    int gender,
                                    double volume_ml,
                                    uint32_t duration_s,
                                    const char *result);
SDLoggerStatus SDLogger_GetLastStatus(void);
const char *SDLogger_StatusText(SDLoggerStatus status);

#ifdef __cplusplus
}
#endif

#endif
