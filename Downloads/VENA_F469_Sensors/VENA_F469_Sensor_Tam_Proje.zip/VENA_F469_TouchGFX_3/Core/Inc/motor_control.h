#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* BENCH MAPPING ONLY. This is not a clinical flow calibration.
 * The UI flow command is limited to 2000 mL/h and mapped linearly onto
 * the proven bench motor range 300..2000 STEP pulses/s.
 * Replace this mapping with measured pulses/mL before volumetric calibration. */
#define MOTOR_MIN_FLOW_ML_H           0.001f
#define MOTOR_MAX_FLOW_ML_H        2000.0f
#define MOTOR_MIN_FREQ_HZ             300U
#define MOTOR_MAX_FREQ_HZ            2000U
#define MOTOR_STEP_HIGH_US          10U
#define MOTOR_RAMP_HZ_PER_SECOND     7400U
#define MOTOR_HEARTBEAT_TIMEOUT_MS   500U
#define MOTOR_DEFAULT_DIRECTION     0U
#define MOTOR_TIMER_TICK_HZ          1000000U

typedef enum { MOTOR_FAULT_NONE=0, MOTOR_FAULT_RANGE=1,
               MOTOR_FAULT_CLOCK=2, MOTOR_FAULT_HEARTBEAT=3 } MotorFault;
void Motor_Init(void);
void Motor_SetFlowRate(float ml_h);
void Motor_Start(void);
void Motor_Pause(void);
void Motor_Resume(void);
void Motor_Stop(void);
/* Direction changes only while stopped/paused. */
void Motor_SetDirection(uint8_t direction);
uint32_t Motor_GetTargetFrequency(void);
uint32_t Motor_GetCurrentFrequency(void);
MotorFault Motor_GetFault(void);
uint8_t Motor_IsRunning(void);
uint8_t Motor_IsFlowRateSupported(float ml_h);
float Motor_GetMinimumFlowRate(void);
float Motor_GetMaximumFlowRate(void);
/* TouchGFX Model tick feeds heartbeat; IRQ never calls RTOS/GUI APIs. */
void Motor_Heartbeat(void);
void Motor_TIM12_IRQHandler(void);
/* Immediately gate the output in fault handlers; no scheduler dependency. */
void Motor_EmergencyStop(void);
#ifdef SIMULATOR
void Motor_SimulatorAdvance(uint32_t milliseconds);
#endif
#ifdef __cplusplus
}
#endif
#endif
