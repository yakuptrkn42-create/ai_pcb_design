#include "../Inc/motor_control.h"
#include <math.h>
#ifndef SIMULATOR
#include "stm32f4xx_hal.h"
#endif
#if MOTOR_MIN_FREQ_HZ == 0 || MOTOR_MAX_FREQ_HZ < MOTOR_MIN_FREQ_HZ
#error Invalid motor frequency limits
#endif
#if MOTOR_MAX_FREQ_HZ * MOTOR_STEP_HIGH_US >= MOTOR_TIMER_TICK_HZ
#error STEP high time must be shorter than the minimum period
#endif
/* Only the GUI task issues commands. The TIM12 IRQ owns ramp progression.
 * Short command updates mask ONLY the unused TIM8_BRK/TIM12 vector, never
 * SysTick, TIM6, LTDC, DSI, DMA2D or all interrupts. */
static volatile uint32_t targetHz, currentHz, heartbeatMs, rampMs, rampRemainder;
static volatile uint8_t running, initialized;
static volatile MotorFault fault;
#ifdef SIMULATOR
static uint32_t simulatedMs;
static uint32_t now_ms(void) { return simulatedMs; }
static uint32_t lock_motor(void) { return 0; }
static void unlock_motor(uint32_t old) { (void)old; }
#else
static uint32_t now_ms(void) { return HAL_GetTick(); }
static uint32_t lock_motor(void) {
    uint32_t enabled = NVIC_GetEnableIRQ(TIM8_BRK_TIM12_IRQn);
    NVIC_DisableIRQ(TIM8_BRK_TIM12_IRQn);
    __DSB(); __ISB();
    return enabled;
}
static void unlock_motor(uint32_t enabled) {
    if (enabled) NVIC_EnableIRQ(TIM8_BRK_TIM12_IRQn);
}
#endif
static void output_off(void) {
#ifndef SIMULATOR
    if (initialized) {
        TIM12->DIER = 0;
        TIM12->CR1 = TIM_CR1_ARPE;
        /* CCR=0 + update forces PWM1 inactive even when counter is stopped. */
        TIM12->CCR1 = 0;
        TIM12->EGR = TIM_EGR_UG;
        TIM12->SR = 0;
        NVIC_ClearPendingIRQ(TIM8_BRK_TIM12_IRQn);
    }
#endif
    running = 0; currentHz = 0; rampRemainder = 0;
}
static void write_frequency(uint32_t hz) {
#ifndef SIMULATOR
    /* ARR preload: period changes only at a PWM boundary, never mid-pulse. */
    TIM12->ARR = (MOTOR_TIMER_TICK_HZ + hz / 2U) / hz - 1U;
#else
    (void)hz;
#endif
}
static uint32_t flow_to_frequency(float rate) {
    if (rate <= 0.0f) return 0U;
    float spanFlow = MOTOR_MAX_FLOW_ML_H - MOTOR_MIN_FLOW_ML_H;
    float spanHz = (float)(MOTOR_MAX_FREQ_HZ - MOTOR_MIN_FREQ_HZ);
    float x = (rate - MOTOR_MIN_FLOW_ML_H) / spanFlow;
    if (x < 0.0f) x = 0.0f;
    if (x > 1.0f) x = 1.0f;
    return (uint32_t)((float)MOTOR_MIN_FREQ_HZ + x * spanHz + 0.5f);
}
float Motor_GetMinimumFlowRate(void) { return MOTOR_MIN_FLOW_ML_H; }
float Motor_GetMaximumFlowRate(void) { return MOTOR_MAX_FLOW_ML_H; }
uint8_t Motor_IsFlowRateSupported(float rate) {
    if (!isfinite(rate) || rate < 0.0f) return 0;
    if (rate == 0.0f) return 1; /* explicit idle / intermittent wait */
    return rate >= MOTOR_MIN_FLOW_ML_H && rate <= MOTOR_MAX_FLOW_ML_H;
}
void Motor_Init(void) {
#ifndef SIMULATOR
    GPIO_InitTypeDef gpio = {0};
    __HAL_RCC_GPIOH_CLK_ENABLE(); __HAL_RCC_GPIOG_CLK_ENABLE();
    __HAL_RCC_TIM12_CLK_ENABLE();
    NVIC_DisableIRQ(TIM8_BRK_TIM12_IRQn);
    __HAL_RCC_TIM12_FORCE_RESET(); __HAL_RCC_TIM12_RELEASE_RESET();
    HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, MOTOR_DEFAULT_DIRECTION ? GPIO_PIN_SET : GPIO_PIN_RESET);
    gpio.Pin = GPIO_PIN_10; gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Pull = GPIO_NOPULL; gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOG, &gpio);
    /* STM32F469 PH6 is AF9 TIM12_CH1 (not AF2 used on some other MCUs). */
    HAL_GPIO_WritePin(GPIOH, GPIO_PIN_6, GPIO_PIN_RESET);
    gpio.Pin = GPIO_PIN_6; gpio.Mode = GPIO_MODE_AF_PP;
    gpio.Pull = GPIO_PULLDOWN; gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    gpio.Alternate = GPIO_AF9_TIM12; HAL_GPIO_Init(GPIOH, &gpio);
    uint32_t clock = HAL_RCC_GetPCLK1Freq();
    /* STM32F469 TIMPRE rule, including future CubeMX clock changes. */
    if ((RCC->DCKCFGR & RCC_DCKCFGR_TIMPRE) == 0U) {
        if ((RCC->CFGR & RCC_CFGR_PPRE1) != 0U) clock *= 2U;
    } else {
        uint32_t divider = HAL_RCC_GetHCLKFreq() / clock;
        clock = divider <= 4U ? HAL_RCC_GetHCLKFreq() : clock * 4U;
    }
    initialized = 1;
    if (clock < MOTOR_TIMER_TICK_HZ || clock % MOTOR_TIMER_TICK_HZ) {
        output_off(); fault = MOTOR_FAULT_CLOCK; return;
    }
    TIM12->PSC = clock / MOTOR_TIMER_TICK_HZ - 1U;
    TIM12->ARR = MOTOR_TIMER_TICK_HZ / MOTOR_MIN_FREQ_HZ - 1U;
    TIM12->CCMR1 = TIM_CCMR1_OC1PE | TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2;
    TIM12->CCER = TIM_CCER_CC1E; /* active high PWM1 */
    TIM12->CR1 = TIM_CR1_ARPE;
    DBGMCU->APB1FZ |= DBGMCU_APB1_FZ_DBG_TIM12_STOP;
    NVIC_SetPriority(TIM8_BRK_TIM12_IRQn, 6U);
#else
    initialized = 1; simulatedMs = 0;
#endif
    targetHz = 0; fault = MOTOR_FAULT_NONE; output_off(); heartbeatMs = now_ms();
#ifndef SIMULATOR
    NVIC_EnableIRQ(TIM8_BRK_TIM12_IRQn);
#endif
}
void Motor_SetFlowRate(float ml_h) {
    uint32_t key = lock_motor();
    if (!Motor_IsFlowRateSupported(ml_h)) {
        targetHz = 0; output_off(); fault = MOTOR_FAULT_RANGE;
    } else {
        targetHz = flow_to_frequency(ml_h);
        if (!targetHz) output_off();
    }
    unlock_motor(key);
}
void Motor_Start(void) {
    uint32_t key = lock_motor();
    if (initialized && !running && fault == MOTOR_FAULT_NONE && targetHz) {
        currentHz = MOTOR_MIN_FREQ_HZ; rampRemainder = 0;
        rampMs = heartbeatMs = now_ms(); running = 1;
        write_frequency(currentHz);
#ifndef SIMULATOR
        TIM12->CCR1 = MOTOR_STEP_HIGH_US;
        TIM12->EGR = TIM_EGR_UG;
        /* First interval is low, giving DIR setup time before first STEP. */
        TIM12->CNT = MOTOR_STEP_HIGH_US;
        TIM12->SR = 0; NVIC_ClearPendingIRQ(TIM8_BRK_TIM12_IRQn);
        TIM12->DIER = TIM_DIER_UIE;
        TIM12->CR1 |= TIM_CR1_CEN;
#endif
    }
    unlock_motor(key);
}
void Motor_Pause(void) { uint32_t key = lock_motor(); output_off(); unlock_motor(key); }
void Motor_Resume(void) { Motor_Start(); }
void Motor_Stop(void) {
    uint32_t key = lock_motor(); output_off(); targetHz = 0;
    if (fault != MOTOR_FAULT_CLOCK) fault = MOTOR_FAULT_NONE;
    unlock_motor(key);
}
void Motor_EmergencyStop(void) { output_off(); targetHz = 0; }
void Motor_SetDirection(uint8_t direction) {
    uint32_t key = lock_motor();
#ifndef SIMULATOR
    if (initialized && !running) HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, direction ? GPIO_PIN_SET : GPIO_PIN_RESET);
#else
    (void)direction;
#endif
    unlock_motor(key);
}
uint32_t Motor_GetTargetFrequency(void) { return targetHz; }
uint32_t Motor_GetCurrentFrequency(void) { return currentHz; }
MotorFault Motor_GetFault(void) { return fault; }
uint8_t Motor_IsRunning(void) { return running; }
void Motor_Heartbeat(void) { heartbeatMs = now_ms(); }
static void advance_ramp(void) {
    if (!running) return;
    uint32_t now = now_ms();
    if (now - heartbeatMs > MOTOR_HEARTBEAT_TIMEOUT_MS) {
        output_off(); fault = MOTOR_FAULT_HEARTBEAT; return;
    }
    uint32_t dt = now - rampMs;
    if (!dt) return;
    rampMs = now;
    /* dt <= heartbeat timeout; no floating point or RTOS calls in ISR. */
    if (dt > MOTOR_HEARTBEAT_TIMEOUT_MS) dt = MOTOR_HEARTBEAT_TIMEOUT_MS;
    uint32_t delta = MOTOR_RAMP_HZ_PER_SECOND * dt + rampRemainder;
    rampRemainder = delta % 1000U; delta /= 1000U;
    if (currentHz < targetHz) currentHz += delta < targetHz-currentHz ? delta : targetHz-currentHz;
    else if (currentHz > targetHz) currentHz -= delta < currentHz-targetHz ? delta : currentHz-targetHz;
    write_frequency(currentHz);
}
void Motor_TIM12_IRQHandler(void) {
#ifndef SIMULATOR
    if ((TIM12->SR & TIM_SR_UIF) && (TIM12->DIER & TIM_DIER_UIE)) {
        TIM12->SR = (uint32_t)~TIM_SR_UIF;
        advance_ramp();
    }
#else
    advance_ramp();
#endif
}
#ifdef SIMULATOR
void Motor_SimulatorAdvance(uint32_t milliseconds) { simulatedMs += milliseconds; advance_ramp(); }
#endif
