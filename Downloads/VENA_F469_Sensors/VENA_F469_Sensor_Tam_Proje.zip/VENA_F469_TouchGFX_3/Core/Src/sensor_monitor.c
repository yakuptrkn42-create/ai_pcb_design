#include "../Inc/sensor_monitor.h"
#include "../Inc/sensor_config.h"
#ifndef SIMULATOR
#include "stm32f4xx_hal.h"
#endif

/* One aligned atomic word publishes a coherent UI snapshot. Only defaultTask
 * writes it; the IRQ exchanges a separate pending flag. No locks, allocation,
 * busy loops, motor APIs, GUI calls, filesystem operations or RTOS APIs. */
static uint32_t published, last_poll, pending_air;
static uint32_t candidate_since, last_air;
static uint8_t sensor_initialized, candidate, optical, optical_ready, air_seen;
#define VALID_BIT 1U
#define OPTICAL_BIT 2U
#define AIR_BIT 4U
#define CONFIGURED_BIT 8U
#define WARNING_BIT 16U
#ifdef SIMULATOR
static uint32_t sim_time;
static uint8_t sim_optical=1U, sim_air, sim_connected;
static uint32_t sensor_now(void) { return sim_time; }
static uint8_t read_optical(void) { return sim_optical; }
static uint8_t read_air(void) { return sim_air; }
static void write_leds(uint8_t target, uint8_t air) { (void)target; (void)air; }
#else
static uint32_t sensor_now(void) { return HAL_GetTick(); }
static uint8_t read_optical(void) {
    return HAL_GPIO_ReadPin(SENSOR_OPTICAL_PORT,SENSOR_OPTICAL_PIN)==GPIO_PIN_SET;
}
static uint8_t read_air(void) {
    return HAL_GPIO_ReadPin(SENSOR_AIR_PORT,SENSOR_AIR_PIN)==GPIO_PIN_SET;
}
static void write_leds(uint8_t target, uint8_t air) {
    HAL_GPIO_WritePin(SENSOR_OPTICAL_LED_PORT,SENSOR_OPTICAL_LED_PIN,
                      target ? GPIO_PIN_RESET : GPIO_PIN_SET);
    HAL_GPIO_WritePin(SENSOR_AIR_LED_PORT,SENSOR_AIR_LED_PIN,
                      air ? GPIO_PIN_RESET : GPIO_PIN_SET);
}
#endif

void Sensor_Init(void) {
    sensor_initialized=0U;
#ifndef SIMULATOR
    GPIO_InitTypeDef gpio={0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    HAL_NVIC_DisableIRQ(EXTI4_IRQn);
    write_leds(0U,0U);
    gpio.Mode=GPIO_MODE_OUTPUT_PP; gpio.Pull=GPIO_NOPULL;
    gpio.Speed=GPIO_SPEED_FREQ_LOW;
    gpio.Pin=SENSOR_OPTICAL_LED_PIN; HAL_GPIO_Init(SENSOR_OPTICAL_LED_PORT,&gpio);
    gpio.Pin=SENSOR_AIR_LED_PIN; HAL_GPIO_Init(SENSOR_AIR_LED_PORT,&gpio);
    gpio.Mode=GPIO_MODE_INPUT; gpio.Pull=GPIO_PULLUP;
    gpio.Pin=SENSOR_OPTICAL_PIN; HAL_GPIO_Init(SENSOR_OPTICAL_PORT,&gpio);
    gpio.Mode=SENSOR_AIR_ACTIVE_LEVEL ? GPIO_MODE_IT_RISING : GPIO_MODE_IT_FALLING;
    gpio.Pin=SENSOR_AIR_PIN; HAL_GPIO_Init(SENSOR_AIR_PORT,&gpio);
    __HAL_GPIO_EXTI_CLEAR_IT(SENSOR_AIR_PIN);
#endif
    __atomic_store_n(&published,0U,__ATOMIC_RELEASE);
    __atomic_store_n(&pending_air,0U,__ATOMIC_RELEASE);
    candidate=read_optical(); optical=candidate; optical_ready=0U; air_seen=0U;
    candidate_since=sensor_now(); last_air=candidate_since;
    __atomic_store_n(&last_poll,candidate_since,__ATOMIC_RELEASE);
    sensor_initialized=1U;
#ifndef SIMULATOR
    /* TIM12 motor priority 6 is higher; touch uses a different EXTI line. */
    HAL_NVIC_SetPriority(EXTI4_IRQn,7U,0U);
    HAL_NVIC_EnableIRQ(EXTI4_IRQn);
#endif
}

void Sensor_AirIRQ(void) {
    /* Called for the configured active edge, even if the complete pulse has
     * ended by ISR entry. EXTI4 itself is configured for that edge only. */
    __atomic_store_n(&pending_air,1U,__ATOMIC_RELEASE);
}

void Sensor_Poll(void) {
    uint32_t now,bits,captured;
    uint8_t raw,air,warning;
    if (!sensor_initialized) return;
    now=sensor_now(); raw=read_optical(); air=read_air();
    captured=__atomic_exchange_n(&pending_air,0U,__ATOMIC_ACQ_REL);
    if (raw!=candidate) { candidate=raw; candidate_since=now; }
    if ((uint32_t)(now-candidate_since)>=SENSOR_OPTICAL_DEBOUNCE_MS) {
        optical=candidate; optical_ready=1U;
    }
    if (air==SENSOR_AIR_ACTIVE_LEVEL || captured) { last_air=now; air_seen=1U; }
    warning=SENSOR_AIR_POLARITY_CONFIRMED && air_seen &&
            (uint32_t)(now-last_air)<SENSOR_AIR_HOLD_MS;
    /* Disarm after expiration to avoid reappearance on a later tick wrap. */
    if (air_seen && !warning && SENSOR_AIR_POLARITY_CONFIRMED) air_seen=0U;
    bits=(optical_ready?VALID_BIT:0U) | (optical?OPTICAL_BIT:0U) |
         (air?AIR_BIT:0U) | (SENSOR_AIR_POLARITY_CONFIRMED?CONFIGURED_BIT:0U) |
         (warning?WARNING_BIT:0U);
#ifdef SIMULATOR
    if (!sim_connected) bits&=~VALID_BIT;
#endif
    write_leds(optical_ready && !optical,
               SENSOR_AIR_POLARITY_CONFIRMED?warning:air);
    __atomic_store_n(&last_poll,now,__ATOMIC_RELEASE);
    __atomic_store_n(&published,bits,__ATOMIC_RELEASE);
}

SensorSnapshot Sensor_GetSnapshot(void) {
    SensorSnapshot s;
    /* Read age first. If acquisition preempts this reader, an old timestamp
     * can conservatively invalidate a new sample, never freshen an old one. */
    uint32_t stamp=__atomic_load_n(&last_poll,__ATOMIC_ACQUIRE);
    uint32_t bits=__atomic_load_n(&published,__ATOMIC_ACQUIRE);
    s.valid=(bits&VALID_BIT)!=0U && (uint32_t)(sensor_now()-stamp)<=SENSOR_STALE_MS;
    s.optical_level=(bits&OPTICAL_BIT)!=0U; s.air_level=(bits&AIR_BIT)!=0U;
    s.air_configured=(bits&CONFIGURED_BIT)!=0U; s.air_warning=(bits&WARNING_BIT)!=0U;
    return s;
}
#ifdef SIMULATOR
void Sensor_SimulatorSetLevels(uint8_t optical_level,uint8_t air_level) {
    uint8_t old=sim_air;
    sim_optical=optical_level?1U:0U; sim_air=air_level?1U:0U;
    if (sim_connected && old!=sim_air && sim_air==SENSOR_AIR_ACTIVE_LEVEL) Sensor_AirIRQ();
}
void Sensor_SimulatorSetConnected(uint8_t connected) {
    sim_connected=connected?1U:0U; Sensor_Init();
}
void Sensor_SimulatorAdvance(uint32_t milliseconds) {
    sim_time+=milliseconds; Sensor_Poll();
}
#endif
