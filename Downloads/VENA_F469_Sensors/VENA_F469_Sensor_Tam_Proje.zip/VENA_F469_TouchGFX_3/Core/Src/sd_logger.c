#include "../Inc/sd_logger.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

static SDLoggerStatus g_last_status = SDLOGGER_OK;

const char *SDLogger_StatusText(SDLoggerStatus status)
{
    switch (status) {
    case SDLOGGER_OK: return "OK";
    case SDLOGGER_NO_CARD: return "NO_CARD";
    case SDLOGGER_SD_ERROR: return "SD_ERROR";
    case SDLOGGER_FS_ERROR: return "FS_ERROR";
    case SDLOGGER_FULL: return "FULL";
    default: return "UNKNOWN";
    }
}

SDLoggerStatus SDLogger_GetLastStatus(void)
{
    return g_last_status;
}

static size_t append_text(char *dst, size_t cap, size_t pos, const char *s)
{
    if (!dst || cap == 0U) return 0U;
    if (!s) s = "";
    while (*s && pos + 1U < cap) dst[pos++] = *s++;
    dst[pos] = 0;
    return pos;
}

static size_t append_csv_string(char *dst, size_t cap, size_t pos, const char *s)
{
    pos = append_text(dst, cap, pos, "\"");
    if (!s) s = "";
    while (*s && pos + 2U < cap) {
        if (*s == '"') dst[pos++] = '"';
        dst[pos++] = *s++;
    }
    pos = append_text(dst, cap, pos, "\"");
    return pos;
}

static const char *gender_text(int gender)
{
    return gender ? "Kadin" : "Erkek";
}

#ifdef SIMULATOR

static SDLoggerStatus append_file(const char *path, const char *header, const char *row)
{
    FILE *f = fopen(path, "rb");
    int empty = 1;
    if (f) {
        if (fseek(f, 0, SEEK_END) == 0 && ftell(f) > 0) empty = 0;
        fclose(f);
    }
    f = fopen(path, "ab");
    if (!f) return SDLOGGER_FS_ERROR;
    if (empty && header) fwrite(header, 1, strlen(header), f);
    if (row) fwrite(row, 1, strlen(row), f);
    fclose(f);
    return SDLOGGER_OK;
}

void SDLogger_Init(void)
{
    g_last_status = SDLOGGER_OK;
}

#else

#include "stm32f4xx_hal.h"

/* STM32F469I-DISCO CN9 microSD connector in SPI mode:
 *   PC12 = CLK, PD2 = CMD/MOSI, PC8 = D0/MISO, PC11 = D3/CS, PG2 = card detect.
 * The board normally exposes these pins to SDIO. Bit-banged SPI is used here so
 * the logger remains self-contained and does not require adding HAL_SD/FatFs
 * middleware to the existing working TouchGFX project.
 */
#define SD_SCK_PORT      GPIOC
#define SD_SCK_PIN       GPIO_PIN_12
#define SD_MOSI_PORT     GPIOD
#define SD_MOSI_PIN      GPIO_PIN_2
#define SD_MISO_PORT     GPIOC
#define SD_MISO_PIN      GPIO_PIN_8
#define SD_CS_PORT       GPIOC
#define SD_CS_PIN        GPIO_PIN_11
#define SD_DET_PORT      GPIOG
#define SD_DET_PIN       GPIO_PIN_2

#define SD_CMD0          0U
#define SD_CMD1          1U
#define SD_CMD8          8U
#define SD_CMD16         16U
#define SD_CMD17         17U
#define SD_CMD24         24U
#define SD_CMD55         55U
#define SD_CMD58         58U
#define SD_ACMD41        41U

#define FAT16_TYPE       16U
#define FAT32_TYPE       32U
#define FAT_ATTR_ARCHIVE 0x20U
#define FAT_EOC16        0xFFF8U
#define FAT_EOC32        0x0FFFFFF8UL

static uint8_t sd_ready;
static uint8_t sd_sdhc;
static uint8_t spi_slow;
static uint8_t fs_mounted;
static uint8_t sector_buf[512];

typedef struct {
    uint8_t type;
    uint8_t sectors_per_cluster;
    uint8_t fat_count;
    uint16_t reserved;
    uint16_t root_entries;
    uint32_t volume_lba;
    uint32_t fat_size;
    uint32_t total_sectors;
    uint32_t first_fat_lba;
    uint32_t root_dir_lba;
    uint32_t root_dir_sectors;
    uint32_t first_data_lba;
    uint32_t root_cluster;
    uint32_t cluster_count;
    uint32_t alloc_hint;
} FsInfo;

static FsInfo fs;

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static uint32_t rd32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void wr16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
}

static void wr32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static void sd_delay_half_cycle(void)
{
    volatile uint32_t n = spi_slow ? 150U : 5U;
    while (n--) __NOP();
}

static void pin_set(GPIO_TypeDef *port, uint16_t pin)
{
    port->BSRR = pin;
}

static void pin_reset(GPIO_TypeDef *port, uint16_t pin)
{
    port->BSRR = ((uint32_t)pin << 16U);
}

static uint8_t sd_spi_byte(uint8_t out)
{
    uint8_t in = 0U;
    uint8_t i;
    for (i = 0U; i < 8U; ++i) {
        if (out & 0x80U) pin_set(SD_MOSI_PORT, SD_MOSI_PIN);
        else pin_reset(SD_MOSI_PORT, SD_MOSI_PIN);
        sd_delay_half_cycle();
        pin_set(SD_SCK_PORT, SD_SCK_PIN);
        in <<= 1U;
        if ((SD_MISO_PORT->IDR & SD_MISO_PIN) != 0U) in |= 1U;
        sd_delay_half_cycle();
        pin_reset(SD_SCK_PORT, SD_SCK_PIN);
        out <<= 1U;
    }
    return in;
}

static void sd_deselect(void)
{
    pin_set(SD_CS_PORT, SD_CS_PIN);
    (void)sd_spi_byte(0xFFU);
}

static void sd_select(void)
{
    pin_reset(SD_CS_PORT, SD_CS_PIN);
}

static uint8_t sd_wait_ready(uint32_t timeout_ms)
{
    uint32_t start = HAL_GetTick();
    do {
        if (sd_spi_byte(0xFFU) == 0xFFU) return 1U;
    } while ((HAL_GetTick() - start) < timeout_ms);
    return 0U;
}

static uint8_t sd_command(uint8_t cmd, uint32_t arg)
{
    uint8_t r = 0xFFU;
    uint8_t crc = 0x01U;
    uint8_t i;

    sd_deselect();
    sd_select();
    if (!sd_wait_ready(100U)) return 0xFFU;

    sd_spi_byte((uint8_t)(0x40U | cmd));
    sd_spi_byte((uint8_t)(arg >> 24));
    sd_spi_byte((uint8_t)(arg >> 16));
    sd_spi_byte((uint8_t)(arg >> 8));
    sd_spi_byte((uint8_t)arg);
    if (cmd == SD_CMD0) crc = 0x95U;
    else if (cmd == SD_CMD8) crc = 0x87U;
    sd_spi_byte(crc);

    for (i = 0U; i < 12U; ++i) {
        r = sd_spi_byte(0xFFU);
        if ((r & 0x80U) == 0U) break;
    }
    return r;
}

static uint8_t sd_card_present(void)
{
    return (HAL_GPIO_ReadPin(SD_DET_PORT, SD_DET_PIN) == GPIO_PIN_RESET) ? 1U : 0U;
}

static void sd_gpio_init(void)
{
    GPIO_InitTypeDef io = {0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();

    pin_set(SD_CS_PORT, SD_CS_PIN);
    pin_reset(SD_SCK_PORT, SD_SCK_PIN);
    pin_set(SD_MOSI_PORT, SD_MOSI_PIN);

    io.Mode = GPIO_MODE_OUTPUT_PP;
    io.Pull = GPIO_NOPULL;
    io.Speed = GPIO_SPEED_FREQ_HIGH;
    io.Pin = SD_CS_PIN | SD_SCK_PIN;
    HAL_GPIO_Init(GPIOC, &io);
    io.Pin = SD_MOSI_PIN;
    HAL_GPIO_Init(GPIOD, &io);

    io.Mode = GPIO_MODE_INPUT;
    io.Pull = GPIO_PULLUP;
    io.Speed = GPIO_SPEED_FREQ_HIGH;
    io.Pin = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10;
    HAL_GPIO_Init(GPIOC, &io);
    io.Pin = SD_DET_PIN;
    HAL_GPIO_Init(GPIOG, &io);
}

static uint8_t sd_init_card(void)
{
    uint8_t r;
    uint8_t r7[4];
    uint32_t start;
    uint8_t i;

    sd_ready = 0U;
    sd_sdhc = 0U;
    fs_mounted = 0U;
    if (!sd_card_present()) return 0U;

    spi_slow = 1U;
    sd_deselect();
    for (i = 0U; i < 12U; ++i) (void)sd_spi_byte(0xFFU);

    start = HAL_GetTick();
    do {
        r = sd_command(SD_CMD0, 0U);
        sd_deselect();
        if (r == 0x01U) break;
    } while ((HAL_GetTick() - start) < 500U);
    if (r != 0x01U) return 0U;

    r = sd_command(SD_CMD8, 0x1AAU);
    if (r == 0x01U) {
        for (i = 0U; i < 4U; ++i) r7[i] = sd_spi_byte(0xFFU);
        sd_deselect();
        if (r7[2] != 0x01U || r7[3] != 0xAAU) return 0U;

        start = HAL_GetTick();
        do {
            r = sd_command(SD_CMD55, 0U);
            sd_deselect();
            if (r > 0x01U) break;
            r = sd_command(SD_ACMD41, 0x40000000UL);
            sd_deselect();
            if (r == 0x00U) break;
        } while ((HAL_GetTick() - start) < 1500U);
        if (r != 0x00U) return 0U;

        r = sd_command(SD_CMD58, 0U);
        if (r != 0x00U) {
            sd_deselect();
            return 0U;
        }
        r7[0] = sd_spi_byte(0xFFU);
        r7[1] = sd_spi_byte(0xFFU);
        r7[2] = sd_spi_byte(0xFFU);
        r7[3] = sd_spi_byte(0xFFU);
        sd_deselect();
        sd_sdhc = (r7[0] & 0x40U) ? 1U : 0U;
    } else {
        sd_deselect();
        start = HAL_GetTick();
        do {
            r = sd_command(SD_CMD55, 0U);
            sd_deselect();
            if (r <= 0x01U) {
                r = sd_command(SD_ACMD41, 0U);
                sd_deselect();
            } else {
                r = sd_command(SD_CMD1, 0U);
                sd_deselect();
            }
            if (r == 0x00U) break;
        } while ((HAL_GetTick() - start) < 1500U);
        if (r != 0x00U) return 0U;
    }

    if (!sd_sdhc) {
        r = sd_command(SD_CMD16, 512U);
        sd_deselect();
        if (r != 0x00U) return 0U;
    }

    spi_slow = 0U;
    sd_ready = 1U;
    return 1U;
}

static uint8_t sd_ensure_ready(void)
{
    if (!sd_card_present()) {
        sd_ready = 0U;
        fs_mounted = 0U;
        return 0U;
    }
    if (sd_ready) return 1U;
    return sd_init_card();
}

static uint8_t sd_read_sector(uint32_t lba, uint8_t *buf)
{
    uint32_t arg;
    uint32_t start;
    uint8_t token;
    uint16_t i;
    if (!sd_ensure_ready()) return 0U;
    arg = sd_sdhc ? lba : lba * 512UL;
    if (sd_command(SD_CMD17, arg) != 0x00U) {
        sd_deselect();
        return 0U;
    }
    start = HAL_GetTick();
    do {
        token = sd_spi_byte(0xFFU);
        if (token == 0xFEU) break;
    } while ((HAL_GetTick() - start) < 250U);
    if (token != 0xFEU) {
        sd_deselect();
        return 0U;
    }
    for (i = 0U; i < 512U; ++i) buf[i] = sd_spi_byte(0xFFU);
    (void)sd_spi_byte(0xFFU);
    (void)sd_spi_byte(0xFFU);
    sd_deselect();
    return 1U;
}

static uint8_t sd_write_sector(uint32_t lba, const uint8_t *buf)
{
    uint32_t arg;
    uint8_t resp;
    uint16_t i;
    if (!sd_ensure_ready()) return 0U;
    arg = sd_sdhc ? lba : lba * 512UL;
    if (sd_command(SD_CMD24, arg) != 0x00U) {
        sd_deselect();
        return 0U;
    }
    (void)sd_spi_byte(0xFFU);
    (void)sd_spi_byte(0xFEU);
    for (i = 0U; i < 512U; ++i) (void)sd_spi_byte(buf[i]);
    (void)sd_spi_byte(0xFFU);
    (void)sd_spi_byte(0xFFU);
    resp = sd_spi_byte(0xFFU);
    if ((resp & 0x1FU) != 0x05U) {
        sd_deselect();
        return 0U;
    }
    if (!sd_wait_ready(600U)) {
        sd_deselect();
        return 0U;
    }
    sd_deselect();
    return 1U;
}

static uint8_t valid_bpb(const uint8_t *b)
{
    uint16_t bps = rd16(b + 11U);
    uint8_t spc = b[13U];
    uint16_t reserved = rd16(b + 14U);
    uint8_t fats = b[16U];
    return (bps == 512U && spc != 0U && (spc & (spc - 1U)) == 0U && reserved != 0U && fats != 0U) ? 1U : 0U;
}

static uint8_t fs_mount(void)
{
    uint32_t base = 0U;
    uint32_t total;
    uint32_t fat_sz;
    uint32_t root_secs;
    uint32_t data_secs;
    uint32_t clusters;
    uint8_t i;

    if (fs_mounted && sd_card_present()) return 1U;
    memset(&fs, 0, sizeof(fs));
    if (!sd_ensure_ready()) return 0U;
    if (!sd_read_sector(0U, sector_buf)) return 0U;

    if (!valid_bpb(sector_buf)) {
        if (sector_buf[510] != 0x55U || sector_buf[511] != 0xAAU) return 0U;
        for (i = 0U; i < 4U; ++i) {
            const uint8_t *p = sector_buf + 446U + (uint16_t)i * 16U;
            if (p[4] != 0U && rd32(p + 8U) != 0U) {
                base = rd32(p + 8U);
                break;
            }
        }
        if (base == 0U || !sd_read_sector(base, sector_buf) || !valid_bpb(sector_buf)) return 0U;
    }

    fs.volume_lba = base;
    fs.sectors_per_cluster = sector_buf[13U];
    fs.reserved = rd16(sector_buf + 14U);
    fs.fat_count = sector_buf[16U];
    fs.root_entries = rd16(sector_buf + 17U);
    total = rd16(sector_buf + 19U);
    if (total == 0U) total = rd32(sector_buf + 32U);
    fat_sz = rd16(sector_buf + 22U);
    if (fat_sz == 0U) fat_sz = rd32(sector_buf + 36U);
    if (total == 0U || fat_sz == 0U) return 0U;

    root_secs = ((uint32_t)fs.root_entries * 32U + 511U) / 512U;
    if (total <= (uint32_t)fs.reserved + (uint32_t)fs.fat_count * fat_sz + root_secs) return 0U;
    data_secs = total - ((uint32_t)fs.reserved + (uint32_t)fs.fat_count * fat_sz + root_secs);
    clusters = data_secs / fs.sectors_per_cluster;
    if (clusters < 4085U) return 0U; /* FAT12 intentionally not supported. */

    fs.type = (clusters < 65525U) ? FAT16_TYPE : FAT32_TYPE;
    fs.fat_size = fat_sz;
    fs.total_sectors = total;
    fs.first_fat_lba = base + fs.reserved;
    fs.root_dir_sectors = root_secs;
    fs.root_dir_lba = fs.first_fat_lba + (uint32_t)fs.fat_count * fat_sz;
    fs.first_data_lba = fs.root_dir_lba + root_secs;
    fs.cluster_count = clusters;
    fs.root_cluster = (fs.type == FAT32_TYPE) ? rd32(sector_buf + 44U) : 0U;
    if (fs.type == FAT32_TYPE && fs.root_cluster < 2U) return 0U;
    fs.alloc_hint = 2U;
    fs_mounted = 1U;
    return 1U;
}

static uint32_t cluster_lba(uint32_t cluster)
{
    return fs.first_data_lba + (cluster - 2U) * fs.sectors_per_cluster;
}

static uint8_t fat_get(uint32_t cluster, uint32_t *value)
{
    uint32_t ofs = cluster * ((fs.type == FAT16_TYPE) ? 2U : 4U);
    uint32_t lba = fs.first_fat_lba + ofs / 512U;
    uint16_t pos = (uint16_t)(ofs % 512U);
    if (!sd_read_sector(lba, sector_buf)) return 0U;
    if (fs.type == FAT16_TYPE) *value = rd16(sector_buf + pos);
    else *value = rd32(sector_buf + pos) & 0x0FFFFFFFUL;
    return 1U;
}

static uint8_t fat_set(uint32_t cluster, uint32_t value)
{
    uint32_t ofs = cluster * ((fs.type == FAT16_TYPE) ? 2U : 4U);
    uint32_t sec_ofs = ofs / 512U;
    uint16_t pos = (uint16_t)(ofs % 512U);
    uint8_t f;
    for (f = 0U; f < fs.fat_count; ++f) {
        uint32_t lba = fs.first_fat_lba + (uint32_t)f * fs.fat_size + sec_ofs;
        if (!sd_read_sector(lba, sector_buf)) return 0U;
        if (fs.type == FAT16_TYPE) wr16(sector_buf + pos, (uint16_t)value);
        else {
            uint32_t old = rd32(sector_buf + pos);
            wr32(sector_buf + pos, (old & 0xF0000000UL) | (value & 0x0FFFFFFFUL));
        }
        if (!sd_write_sector(lba, sector_buf)) return 0U;
    }
    return 1U;
}

static uint8_t fat_is_eoc(uint32_t v)
{
    return (fs.type == FAT16_TYPE) ? (v >= FAT_EOC16) : (v >= FAT_EOC32);
}

static uint8_t zero_cluster(uint32_t cluster)
{
    uint8_t s;
    memset(sector_buf, 0, sizeof(sector_buf));
    for (s = 0U; s < fs.sectors_per_cluster; ++s) {
        if (!sd_write_sector(cluster_lba(cluster) + s, sector_buf)) return 0U;
    }
    return 1U;
}

static uint32_t alloc_cluster(void)
{
    uint32_t c;
    uint32_t v;
    uint32_t start = fs.alloc_hint;
    uint32_t max = fs.cluster_count + 1U;
    if (start < 2U || start > max) start = 2U;

    c = start;
    do {
        if (!fat_get(c, &v)) return 0U;
        if (v == 0U) {
            uint32_t eoc = (fs.type == FAT16_TYPE) ? 0xFFFFU : 0x0FFFFFFFUL;
            if (!fat_set(c, eoc)) return 0U;
            if (!zero_cluster(c)) return 0U;
            fs.alloc_hint = (c < max) ? (c + 1U) : 2U;
            return c;
        }
        ++c;
        if (c > max) c = 2U;
    } while (c != start);
    return 0U;
}

static void dir_get_cluster(const uint8_t *e, uint32_t *cluster)
{
    uint32_t lo = rd16(e + 26U);
    uint32_t hi = (fs.type == FAT32_TYPE) ? rd16(e + 20U) : 0U;
    *cluster = (hi << 16) | lo;
}

static void dir_set_cluster(uint8_t *e, uint32_t cluster)
{
    wr16(e + 26U, (uint16_t)cluster);
    if (fs.type == FAT32_TYPE) wr16(e + 20U, (uint16_t)(cluster >> 16));
}

typedef struct {
    uint32_t dir_lba;
    uint16_t dir_off;
    uint32_t first_cluster;
    uint32_t size;
} FileRef;

static uint8_t scan_dir_sector(uint32_t lba, const uint8_t sfn[11], FileRef *ref,
                               uint32_t *free_lba, uint16_t *free_off, uint8_t *end_seen)
{
    uint16_t off;
    if (!sd_read_sector(lba, sector_buf)) return 0U;
    for (off = 0U; off < 512U; off += 32U) {
        uint8_t *e = sector_buf + off;
        if (e[0] == 0x00U) {
            if (*free_lba == 0U) { *free_lba = lba; *free_off = off; }
            *end_seen = 1U;
            return 2U;
        }
        if (e[0] == 0xE5U) {
            if (*free_lba == 0U) { *free_lba = lba; *free_off = off; }
            continue;
        }
        if (e[11] == 0x0FU || (e[11] & 0x08U) != 0U) continue;
        if (memcmp(e, sfn, 11U) == 0) {
            ref->dir_lba = lba;
            ref->dir_off = off;
            dir_get_cluster(e, &ref->first_cluster);
            ref->size = rd32(e + 28U);
            return 3U;
        }
    }
    return 1U;
}

static uint8_t create_dir_entry(const uint8_t sfn[11], FileRef *ref, uint32_t lba, uint16_t off)
{
    uint8_t *e;
    if (!sd_read_sector(lba, sector_buf)) return 0U;
    e = sector_buf + off;
    memset(e, 0, 32U);
    memcpy(e, sfn, 11U);
    e[11] = FAT_ATTR_ARCHIVE;
    if (!sd_write_sector(lba, sector_buf)) return 0U;
    ref->dir_lba = lba;
    ref->dir_off = off;
    ref->first_cluster = 0U;
    ref->size = 0U;
    return 1U;
}

static uint8_t find_or_create_file(const uint8_t sfn[11], FileRef *ref)
{
    uint32_t free_lba = 0U;
    uint16_t free_off = 0U;
    uint8_t end_seen = 0U;
    uint8_t rc;

    memset(ref, 0, sizeof(*ref));
    if (fs.type == FAT16_TYPE) {
        uint32_t s;
        for (s = 0U; s < fs.root_dir_sectors; ++s) {
            rc = scan_dir_sector(fs.root_dir_lba + s, sfn, ref, &free_lba, &free_off, &end_seen);
            if (rc == 0U) return 0U;
            if (rc == 3U) return 1U;
            if (end_seen) break;
        }
        if (free_lba == 0U) return 0U;
        return create_dir_entry(sfn, ref, free_lba, free_off);
    } else {
        uint32_t cluster = fs.root_cluster;
        uint32_t prev = 0U;
        while (cluster >= 2U && cluster <= fs.cluster_count + 1U) {
            uint8_t s;
            for (s = 0U; s < fs.sectors_per_cluster; ++s) {
                rc = scan_dir_sector(cluster_lba(cluster) + s, sfn, ref, &free_lba, &free_off, &end_seen);
                if (rc == 0U) return 0U;
                if (rc == 3U) return 1U;
                if (end_seen) break;
            }
            if (end_seen) break;
            prev = cluster;
            {
                uint32_t next;
                if (!fat_get(cluster, &next)) return 0U;
                if (fat_is_eoc(next)) break;
                if (next < 2U || next > fs.cluster_count + 1U) return 0U;
                cluster = next;
            }
        }
        if (free_lba == 0U) {
            uint32_t fresh = alloc_cluster();
            if (fresh == 0U || prev == 0U || !fat_set(prev, fresh)) return 0U;
            free_lba = cluster_lba(fresh);
            free_off = 0U;
        }
        return create_dir_entry(sfn, ref, free_lba, free_off);
    }
}

static uint8_t update_dir_entry(FileRef *ref)
{
    uint8_t *e;
    if (!sd_read_sector(ref->dir_lba, sector_buf)) return 0U;
    e = sector_buf + ref->dir_off;
    dir_set_cluster(e, ref->first_cluster);
    wr32(e + 28U, ref->size);
    e[11] |= FAT_ATTR_ARCHIVE;
    return sd_write_sector(ref->dir_lba, sector_buf);
}

static SDLoggerStatus append_bytes(FileRef *ref, const uint8_t *data, uint32_t len)
{
    uint32_t cluster_bytes = (uint32_t)fs.sectors_per_cluster * 512U;
    uint32_t pos = ref->size;
    uint32_t cluster;
    uint32_t steps;
    uint32_t off_in_cluster;
    uint32_t i;

    if (len == 0U) return SDLOGGER_OK;
    if (ref->first_cluster == 0U) {
        ref->first_cluster = alloc_cluster();
        if (ref->first_cluster == 0U) return SDLOGGER_FULL;
    }
    cluster = ref->first_cluster;
    steps = pos / cluster_bytes;
    off_in_cluster = pos % cluster_bytes;

    for (i = 0U; i < steps; ++i) {
        uint32_t next;
        if (!fat_get(cluster, &next)) return SDLOGGER_SD_ERROR;
        if (fat_is_eoc(next)) {
            next = alloc_cluster();
            if (next == 0U) return SDLOGGER_FULL;
            if (!fat_set(cluster, next)) return SDLOGGER_SD_ERROR;
        }
        if (next < 2U || next > fs.cluster_count + 1U) return SDLOGGER_FS_ERROR;
        cluster = next;
    }

    while (len > 0U) {
        uint32_t sec_in_cluster = off_in_cluster / 512U;
        uint16_t sec_off = (uint16_t)(off_in_cluster % 512U);
        uint32_t lba = cluster_lba(cluster) + sec_in_cluster;
        uint32_t chunk = 512U - sec_off;
        if (chunk > len) chunk = len;
        if (!sd_read_sector(lba, sector_buf)) return SDLOGGER_SD_ERROR;
        memcpy(sector_buf + sec_off, data, chunk);
        if (!sd_write_sector(lba, sector_buf)) return SDLOGGER_SD_ERROR;
        data += chunk;
        len -= chunk;
        ref->size += chunk;
        off_in_cluster += chunk;

        if (off_in_cluster >= cluster_bytes && len > 0U) {
            uint32_t next;
            if (!fat_get(cluster, &next)) return SDLOGGER_SD_ERROR;
            if (fat_is_eoc(next)) {
                next = alloc_cluster();
                if (next == 0U) return SDLOGGER_FULL;
                if (!fat_set(cluster, next)) return SDLOGGER_SD_ERROR;
            }
            if (next < 2U || next > fs.cluster_count + 1U) return SDLOGGER_FS_ERROR;
            cluster = next;
            off_in_cluster = 0U;
        }
    }

    if (!update_dir_entry(ref)) return SDLOGGER_SD_ERROR;
    return SDLOGGER_OK;
}

static SDLoggerStatus append_csv(const uint8_t sfn[11], const char *header, const char *row)
{
    FileRef ref;
    SDLoggerStatus st;
    if (!sd_card_present()) return SDLOGGER_NO_CARD;
    if (!fs_mount()) return sd_ready ? SDLOGGER_FS_ERROR : SDLOGGER_SD_ERROR;
    if (!find_or_create_file(sfn, &ref)) return SDLOGGER_FS_ERROR;
    if (ref.size == 0U && header && *header) {
        st = append_bytes(&ref, (const uint8_t *)header, (uint32_t)strlen(header));
        if (st != SDLOGGER_OK) return st;
    }
    st = append_bytes(&ref, (const uint8_t *)row, (uint32_t)strlen(row));
    return st;
}

void SDLogger_Init(void)
{
    sd_gpio_init();
    sd_ready = 0U;
    fs_mounted = 0U;
    g_last_status = SDLOGGER_OK;
}

#endif /* SIMULATOR */

SDLoggerStatus SDLogger_LogPatient(const char *name,
                                   const char *code,
                                   const char *ward,
                                   int age,
                                   int gender,
                                   double weight)
{
    char line[384];
    char num[96];
    size_t p = 0U;
    static const char header[] = "uptime_ms,name,patient_code,ward,age,gender,weight_kg\r\n";
#ifndef SIMULATOR
    static const uint8_t sfn[11] = {'P','A','T','I','E','N','T',' ','C','S','V'};
    unsigned long uptime = (unsigned long)HAL_GetTick();
#else
    unsigned long uptime = 0UL;
#endif

    line[0] = 0;
    snprintf(num, sizeof(num), "%lu,", uptime);
    p = append_text(line, sizeof(line), p, num);
    p = append_csv_string(line, sizeof(line), p, name);
    p = append_text(line, sizeof(line), p, ",");
    p = append_csv_string(line, sizeof(line), p, code);
    p = append_text(line, sizeof(line), p, ",");
    p = append_csv_string(line, sizeof(line), p, ward);
    snprintf(num, sizeof(num), ",%d,", age);
    p = append_text(line, sizeof(line), p, num);
    p = append_csv_string(line, sizeof(line), p, gender_text(gender));
    snprintf(num, sizeof(num), ",%.2f\r\n", weight);
    p = append_text(line, sizeof(line), p, num);
    (void)p;

#ifdef SIMULATOR
    g_last_status = append_file("PATIENT.CSV", header, line);
#else
    g_last_status = append_csv(sfn, header, line);
#endif
    return g_last_status;
}

SDLoggerStatus SDLogger_LogInfusion(const char *patient,
                                    const char *code,
                                    const char *ward,
                                    const char *drug,
                                    const char *mode,
                                    int age,
                                    int gender,
                                    double volume_ml,
                                    uint32_t duration_s,
                                    const char *result)
{
    char line[512];
    char num[112];
    size_t p = 0U;
    static const char header[] = "uptime_ms,patient,patient_code,ward,drug,mode,age,gender,delivered_ml,duration_s,result\r\n";
#ifndef SIMULATOR
    static const uint8_t sfn[11] = {'I','N','F','U','S','I','O','N','C','S','V'};
    unsigned long uptime = (unsigned long)HAL_GetTick();
#else
    unsigned long uptime = 0UL;
#endif

    line[0] = 0;
    snprintf(num, sizeof(num), "%lu,", uptime);
    p = append_text(line, sizeof(line), p, num);
    p = append_csv_string(line, sizeof(line), p, patient);
    p = append_text(line, sizeof(line), p, ",");
    p = append_csv_string(line, sizeof(line), p, code);
    p = append_text(line, sizeof(line), p, ",");
    p = append_csv_string(line, sizeof(line), p, ward);
    p = append_text(line, sizeof(line), p, ",");
    p = append_csv_string(line, sizeof(line), p, drug);
    p = append_text(line, sizeof(line), p, ",");
    p = append_csv_string(line, sizeof(line), p, mode);
    snprintf(num, sizeof(num), ",%d,", age);
    p = append_text(line, sizeof(line), p, num);
    p = append_csv_string(line, sizeof(line), p, gender_text(gender));
    snprintf(num, sizeof(num), ",%.3f,%lu,", volume_ml, (unsigned long)duration_s);
    p = append_text(line, sizeof(line), p, num);
    p = append_csv_string(line, sizeof(line), p, result);
    p = append_text(line, sizeof(line), p, "\r\n");
    (void)p;

#ifdef SIMULATOR
    g_last_status = append_file("INFUSION.CSV", header, line);
#else
    g_last_status = append_csv(sfn, header, line);
#endif
    return g_last_status;
}

#ifdef __cplusplus
}
#endif
