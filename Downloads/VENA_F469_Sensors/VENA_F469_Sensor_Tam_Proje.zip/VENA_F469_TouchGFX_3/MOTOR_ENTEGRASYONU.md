> **6 Ekim 2026 son güncelleme:** Akış üst sınırı 2000 mL/h ve CN9 microSD CSV data logger eklendi.
> Güncel özet için `MOTOR_2000_SD_GUNCELLEME.md`, SD ayrıntıları için `SD_DATA_LOGGER.md` dosyasını okuyun.
> Aşağıdaki eski 1200/4000 Hz ve RAM-only ifadeleri önceki revizyon notlarıdır.

# VENA motor entegrasyonu — 6 Ekim 2026

Gönderilen VENA_F469_TouchGFX(2).zip üzerinde yapıldı. Kart, LCD/DSI, SDRAM/FMC,
QSPI, dokunmatik ve RTOS altyapısı korunmuştur. Motor boot sırasında durur.

## Açma ve çalıştırma

- Designer 4.26: `TouchGFX/MyApplication_9.touchgfx` → Generate Code / Run Simulator.
- CubeIDE: `STM32CubeIDE` içinden mevcut projeyi içe aktar → Clean / Build.
- Ana ekran → Yeni İnfüzyon → Hız Modu → Akış hızı → 100 → Onayla → Başlat.
- STEP 300 Hz'de başlar, yaklaşık 95 ms'de 1000 Hz hedefe ulaşır.
- Ana ekrandaki Duraklat çıkışı keser; Devam yeniden 300 Hz'den rampa başlatır.
- Sonlandır → Sonlandır onayı çıkışı keser ve hedefi sıfırlar.
- Aktif Hız Modu'nda akış kartına dokun → Akış hızı → yeni değer → Onayla.
  Motor çalışmaya devam eder, yeni hedefe rampayla geçer. Geçen süre/verilen hacim
  sıfırlanmaz. PAUSE sırasında değer değişirse RESUME'e kadar motor durur.
- Simülatör aynı hız/rampa API'sinin yazılım backend'ini kullanır, GPIO'ya erişmez.

## Ekran ve kod eşlemesi

| İstenen öğe | Gerçek karşılık |
|---|---|
| Yeni İnfüzyon | Screen003, `vena::MODES` |
| Hız Modu | Screen005, `vena::PARAMS` + `mode == RATE` |
| Akış hızı girişi | Screen006, `vena::NUMPAD`, `editing == RATE_F` |
| Hız değişkeni | `vena::model().v[vena::RATE_F]`; motorun anlık program hedefi `rateNow()` |
| Ana çalışma ekranı | Screen1, `vena::HOME` |
| START | `START` → `vena::Model::start()` → `Motor_SetFlowRate()` / `Motor_Start()` |
| PAUSE | `PRIMARY` (RUNNING) → `pause()` → `Motor_Pause()` |
| RESUME | `PRIMARY` (PAUSED) → `resume()` → `Motor_SetFlowRate()` / `Motor_Resume()` |
| STOP | `STOP_CONFIRM` → Screen042 → `STOP_YES` → `stop()` → `Motor_Stop()` |

Gerçek içerik `VenaScene.cpp`, generated ViewBase dosyaları, texts.xml ve
.touchgfx ile karşılaştırıldı. Runtime View'lar ortak Panel'i kullanıyor;
itemX/routeAnchor isimlerine göre davranış atanmadı. Mevcut ortak Panel →
vena::Model mimarisi korundu. Presenter'lara veya View'lara register kodu eklenmedi.
Motor değişikliği VenaModel + Core API üzerinden gerçekleşir. Designer referans
widget'larını taşımanın runtime Panel'i otomatik değiştirmediği eski yapı korunur.

## Timer ve pinler

- **PH6: AF9 / TIM12_CH1**, push-pull, pulldown, high-speed; aktif yüksek PWM1.
- **PG10: GPIO output push-pull**, no-pull, low-speed; başlangıç DIR=0.
- Yön API'si motor çalışırken değişiklik yapmaz; durduktan sonra değiştirilebilir.
- TIM12 APB1 timer saati mevcut projede 90 MHz; PSC=89 ile sayaç 1 MHz.
- CCR1=10 → 10 µs yüksek süre; ARR yaklaşık `1000000 / Hz - 1`.
- ARR preload açık: frekans yalnızca periyot sınırında değişir. Darbe kenarları
  kesmede yazılımla oluşturulmaz; PWM donanımı üretir.
- TIM8_BRK_TIM12 kesmesi, öncelik 6, yalnızca rampa ve heartbeat kontrolü yapar.
  TIM8 bu projede kullanılmıyor. TIM6 HAL timebase ve SysTick/RTOS değiştirilmedi.
- Komutlar yalnızca bu motor kesmesini kısa süre maskeler; global interrupt kapatma,
  busy-wait, Delay_us/HAL_Delay veya motor döngüsü yoktur.
- Stop/pause: sayaç ve update interrupt kapanır, PWM compare=0 ile STEP düşük tutulur.
  ENABLE bağlanmadığından sürücü bobin tutma akımını kesmek bu API'nin görevi değildir.
- Ana Model tick heartbeat gönderir. 500 ms boyunca GUI heartbeat gelmezse timer
  kesmesi motoru durdurup hatayı kilitler. Kendiliğinden başlamaz; Sonlandır ile
  hata sıfırlanır. Bu mekanizma fiziksel sensör/interlock veya bağımsız watchdog değildir.

## Tek noktadan kalibrasyon

`Core/Inc/motor_control.h`:

```c
#define PULSES_PER_ML              36000.0f // geçici tezgah testi katsayısı
#define MOTOR_MIN_FREQ_HZ          300U
#define MOTOR_MAX_FREQ_HZ          4000U
#define MOTOR_RAMP_HZ_PER_SECOND   7400U
```

Dönüşüm `Core/Src/motor_control.c`, `Motor_SetFlowRate()` içindedir:
`Hz = ml_h * PULSES_PER_ML / 3600.0f`.

100 mL/h → 1000 Hz, 200 mL/h → 2000 Hz, 400 mL/h → 4000 Hz.
Bu katsayıyla geçerli hız 30–400 mL/h'dir. Sınır dışı, negatif, NaN ve sonsuz değer
çalıştırılmaz; UI açık hata gösterir. Alt sınırın altında istenen akışı 300 Hz'e
sessizce yükseltmez. 0 hız bekleme/durma anlamındadır. Kalibrasyon: bilinen pulse
sayısı / ölçülen mL. 1/8 microstep'te 1600 pulse/tur bilgisi tek başına mL/tur vermez.

Kalibrasyonu, maksimum frekansı veya rampayı değiştirdikten sonra yeniden derleyin.
Ölçülmüş kalibrasyon olmadan mL/h etiketi gerçek sıvı akışı garantisi değildir.

## Diğer mevcut akışlarla ilişki

- Hız, Zaman, Sekans, Piggyback, Ağırlık, Aralıklı ve Mikro programları hesaplanan
  tüm segment hızları motor sınırlarına uygunsa motoru sürer.
- Aralıklı modun sıfır hız/bekleme segmentinde çıkış kesilir; yeni dozda rampa başlar.
- TPN ve Trapezoidal modların sıfırdan başlayan program rampaları 300 Hz altına
  indiği için bu sürümde açık hata ile başlatılmaz. Bu, motor kalkış rampasından farklıdır.
- Bolus hızı uygunsa motor hedefi bolus hızına çıkar; bırakınca/bitince ana hıza döner.
- KVO da aynı fiziksel hız aralığına uymalıdır. Varsayılan 1 mL/h bu test
  kalibrasyonuyla desteklenmez; KVO açıksa START hata verir. Varsayılan KVO kapalıdır.
- Alarm, VTBI/süre tamamlanması ve STOP çıkışı keser. Uygun KVO varsa tamamlanınca
  KVO hedefine geçilir. Prime ekranı bu entegrasyon kapsamı dışındadır ve demo kalır.
- Gösterilen hacim/süre mevcut set değeri hesabıdır: ölçülmüş hacim, gerçek pulse
  sayımı veya kapalı çevrim kontrol değildir; hızlanma rampasının hacmi hesaba katılmaz.

## Doğrulama ve derleme

- Arm GNU 14.3.1 ile gerçek HAL/RTOS/TouchGFX hedef kaynakları derlenip linklendi.
- `Validation/build_arm.py` CubeIDE .project/.cproject kaynak/include listesini
  kullanır; Cortex-M4, hard-float ABI, gerçek ST libtouchgfx-float-abi-hard.a.
- ELF ve birleşik internal+QSPI HEX: `Firmware/`. QSPI loader olmadan yalnızca
  internal Flash yüklemek görüntü kaynaklarını karta taşımaz.
- `Validation/arm_cubeide_build.log`: ARM derleme, linker ve bellek özeti.
- `Validation/motor_tests.log`: gerçek motor API/Model kodunda dönüşüm, sınırlar,
  rampa, canlı değişiklik, durdurma, alarm, heartbeat, mod/segment testleri.
- `Validation/click_tests.log`: gerçek TouchGFX kütüphanesiyle dokunma → API testleri.
- Windows Designer/CubeIDE uygulaması açılışı ve gerçek kartta motor/oscilloscope
  testi bu ortamda yapılamadı. Yazılımdaki 10 µs/Hz değerleri kartta ölçülmedi.

Yeniden ARM kontrolü: `python3 Validation/build_arm.py <arm-toolchain/bin>`.
Host kontrolü: `python3 Validation/build_host.py` (Linux, g++, Python).

## CubeMX yeniden üretim

.ioc içinde PH6/TIM12_CH1, PG10 ve IRQ önceliği kaydedildi. Motor_Init USER CODE
bloğundadır; timer register ayarı motor modülüne aittir. Motor IRQ handler'ı
stm32f4xx_it.c USER CODE BEGIN 1 içinde korunur; .ioc bu handler'ın otomatik
üretilmesini kapalı tutar. TIM12'yi başka bir modüle/interrupt callback'e vermeyin.
CubeMX yeniden üretimi bu ortamda test edilmedi; mevcut teslim dosyaları doğrudan
derlenir. Üretim sonrası tek TIM8_BRK_TIM12_IRQHandler ve Motor_Init çağrısının
korunduğunu, motor_control.c'nin CubeIDE kaynak listesinde kaldığını kontrol edin.

Kaynak: ST STM32F469 datasheet, PH6 alternate function tablosu:
https://www.st.com/resource/en/datasheet/stm32f469vi.pdf
