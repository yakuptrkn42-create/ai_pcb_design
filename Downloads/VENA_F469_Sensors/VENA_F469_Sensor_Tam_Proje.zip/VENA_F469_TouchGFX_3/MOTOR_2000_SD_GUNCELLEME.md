# 2000 mL/h motor + SD logger güncellemesi

Bu paket mevcut çalışan `VENA_F469_TouchGFX_Motor` projesinin üzerine güncellendi.

## Motor

- Arayüzde ana akış hızı, sekans hızları, sekonder hız ve manuel bolus üst sınırı: **2000 mL/h**.
- Test eşlemesi: **0.001–2000 mL/h → 300–2000 STEP/s**.
- 2000 mL/h girildiğinde hedef STEP frekansı 2000 Hz olur.
- Motor rampa, pause/resume/stop ve heartbeat güvenlik davranışı korunmuştur.
- Bu eşleme yalnızca tezgah testidir; gerçek mL/h için ölçülmüş pulse/mL kalibrasyonu gerekir.

## SD data logger

- Hasta kaydı: `PATIENT.CSV`
- Tamamlanan/sonlandırılan infüzyon: `INFUSION.CSV`
- CN9 dahili microSD yuvası kullanılır.
- Kart FAT16/FAT32 olmalıdır; exFAT desteklenmez.
- Kart/yazma hatası tedaviyi durdurmaz; olay geçmişine hata yazılır.

Detaylar: `SD_DATA_LOGGER.md`.

## Doğrulama

- TouchGFX/Linux host build: başarılı, 319 C++ birimi derlenip linklendi.
- Motor/Model regresyon testi: başarılı.
- CSV logger simülatör testi: başarılı.
- Yeni donanım logger C kodu STM32F469 HAL başlıklarıyla syntax kontrolden geçti.
- Bu ortamda `arm-none-eabi-gcc` bulunmadığı için güncel ELF/HEX üretilmedi. CubeIDE'de
  **Clean Project → Build Project** yapıp kartı güncel build ile programlayın.
