> **Optik + BS241 güncellemesi:** Önce [SENSOR_ENTEGRASYONU_TR.md](SENSOR_ENTEGRASYONU_TR.md) dosyasını okuyun. Güncel firmware adı `VENA_F469_Sensors` şeklindedir. Aşağıdaki notlar önceki proje tesliminden korunmuştur.

> **6 Ekim 2026 son güncelleme:** Akış üst sınırı 2000 mL/h ve CN9 microSD CSV data logger eklendi.
> Güncel özet için `MOTOR_2000_SD_GUNCELLEME.md`, SD ayrıntıları için `SD_DATA_LOGGER.md` dosyasını okuyun.
> Aşağıdaki eski 1200/4000 Hz ve RAM-only ifadeleri önceki revizyon notlarıdır.

# VENA — STM32F469I-DISCO / TouchGFX + TB6600 motor

Bu revizyonda gerçek motor bağlantısı eklendi. Önce `MOTOR_ENTEGRASYONU.md` okuyun.
PH6/TIM12 STEP, PG10 DIR; kullanıcı START vermeden STEP çıkışı kapalıdır.
Kalibrasyon şimdilik 36000 pulse/mL test katsayısıdır; ölçülmüş hacim değildir.


Bu paket, gönderilen MyApplication_9(1).zip kart projesi üzerine hazırlanmıştır.
TouchGFX 4.26.0, 800×480 yatay arayüz, RGB565 kullanır. LCD/DSI, dokunmatik,
SDRAM, QSPI, HAL/BSP ve FreeRTOS dosyaları gönderilen projeden korunmuştur.

## Açma

1. ZIP'i kısa, boşluksuz bir yola çıkarın; örnek: C:\VENA_F469.
2. TouchGFX Designer 4.26.0 ile `TouchGFX/MyApplication_9.touchgfx` dosyasını açın.
3. Generate Code, ardından Run Simulator çalıştırın.
4. STM32CubeIDE'de File → Import → Existing Projects into Workspace ile
   `STM32CubeIDE` klasörünü seçin. Aynı isimli eski proje açıksa kapatın veya
   ayrı workspace kullanın. İlk açılışta Project → Clean → Build Project yapın.
5. Kart yüklemesinde mevcut çalışan projenizdeki QSPI external loader ve debug
   ayarlarını kullanın. Bu sürümden üretilen ELF ve birleşik HEX `Firmware` içindedir.
   HEX hem dahili Flash hem QSPI içerir; QSPI external loader kullanılmalıdır.

## Bu sürümde çalışan arayüz akışları

- Ana ekran: verilen/kalan/hedef hacim, süre, mod, hasta ve ilaç.
- Hız, Zaman, Sekans, Piggyback, Ağırlık, TPN, Aralıklı, Mikro ve Trapezoidal mod.
- Sayısal giriş, alan aralığı denetimi, mod hesapları; Hız Modu'nda VTBI opsiyonel.
- Başlat, Duraklat, Devam, Sonlandır onayı; sekans ve rampa demo ilerlemesi.
- Manuel bolus: basılı tutunca başlar; bırakma, dışarı sürükleme ve ekrandan
  çıkışta durur. Otomatik bolus ve bolus sonuç ekranı.
- KVO açık/kapalı seçimi, demo alarm → giderme → kullanıcı onaylı devam.
- Genel ve infüzyon ayarları; ekran/ses sürgüleri; açık/koyu görünüm, ekran kilidi.
- Hasta ekleme/seçme, örnek ilaç kataloğu, oturum raporları ve olay listesi.
- Servis PIN'i 0000; sensör durum sayfası, set hacmi taslağı, bakım kayıtları.

## Doğrulama durumu

Gerçek ST TouchGFX 4.26 Linux kütüphanesiyle 319 C++ derleme birimi derlendi ve
bağlandı. Headless HAL ile gerçek TouchGFX çizimi ve dokunma olayları çalıştırıldı.
Ana menü → mod → sayısal giriş → 125 mL/h → başlat → duraklat/devam → manuel bolus
basma/bırakma akışı geçti. Motor API ve mod sınır testleri AddressSanitizer ve
UndefinedBehaviorSanitizer altında geçti (ortam kısıtı nedeniyle leak taraması kapalı).
38 ekranın yerleşim sınırları kontrol edildi. Ekran görüntüleri Validation/previews
altındadır; bunlar maket değil, TouchGFX'in ürettiği görüntülerdir.

Bu motor revizyonunda tam ARM derlemesi/link kontrolü yapıldı; sonuçlar
Validation/arm_cubeide_build.log içindedir. Windows Designer/CubeIDE uygulamasında
yeniden kod üretimi ve fiziksel karta yükleme testi yapılmadı.

## Kapsam ve kalan işler

Bu bir **arayüz geliştirme sürümüdür**. EXE'nin bütün ekran/servis özelliklerinin
birebir, tamamlanmış dönüşümü değildir. EXE'nin ikili incelemesi ve daha önce
paylaşılmış VENA_PC_Simulator kaynaklarındaki 800×480 yerleşim referans alındı;
EXE ile bu kaynakların birebir aynı revizyon olduğu doğrulanamadı.

- Motor STEP/DIR çıkışı bağlandı. Sensör, RTC, ses ve fiziksel parlaklık sürücüsü
  bağlanmadı. Gösterilen hacim/süre set değerlerinden hesaplanır; ölçülmüş sıvı
  hacmi veya encoder geri bildirimi değildir. Motor rampası hacim hesabına dahil değildir.
- Basınç ve batarya gibi bağlı olmayan veriler gerçek ölçümmüş gibi gösterilmez.
- Hasta/rapor/ayarlar RAM'dedir; güç kesilince kaybolur. 12 hasta, 24 uygulama,
  24 olay kapasitesi vardır. Listeler ilk/son 6 kaydı gösterir; sayfalama eklenmelidir.
- Rapor filtresi yaş, cinsiyet ve ilaç içindir. Tarih aralığı, demografik grafik,
  hasta bazlı ayrıntılı log ve dışa aktarım henüz eklenmedi.
- İlaç kataloğu örnektir; klinik ilaç limitlerini içermez.
- Dil seçimi Türkçe ile sınırlıdır. Wi-Fi, tarih seçici ve kapsamlı servis/set
  yönetimi bu sürüme taşınmadı. Metin klavyesi temel Latin karakterleridir.
- Yazı tipi Verdana'dır; EXE'deki bütün ikonlar, animasyonlar ve yuvarlatılmış
  kart köşeleri birebir kopyalanmadı.

## Geliştirme yeri

`TouchGFX/gui/src/vena/VenaScene.cpp`: yerleşim, metin, düğme, sürgü ve eylemler.
`TouchGFX/gui/src/vena/VenaModel.cpp`: UI verisi, hesaplar ve demo durum makinesi.
`TouchGFX/gui/src/vena/VenaPanel.cpp`: native TouchGFX Box/TextArea çizimi ve touch.
`TouchGFX/gui/src/vena/VenaNavigation.cpp`: gerçek View geçişleri.
`TouchGFX/gui/src/model/Model.cpp`: 100 ms aralıkla UI modelinin güncellenmesi.

38 gerçek View/Presenter ekranı vardır. Designer'daki ekran bileşenleri yerleşim
referanslarıdır. Çalışma sırasında View, ortak native Panel'i ekler. Bu nedenle
Designer'da referans kutuyu taşımanın çalışan Panel'i otomatik değiştirmediğine
dikkat edin: çalışma zamanı yerleşimi VenaScene.cpp içinden düzenlenir. Designer
Generate Code, gui/vena kullanıcı kodunu silmez. Ekran dışındaki routeAnchor
bileşenleri navigation API'lerinin yeniden üretilmesi için bırakılmıştır.

`Validation/SCREENS.csv` ekran adlarını eşler. Host doğrulaması için Linux/g++ ile
`python3 Validation/build_host.py` çalıştırılabilir. STM32CubeIDE linkedResources
listesine yeni C++ kaynakları eklendi; ondalık yazdırma için linker script'e
EXTERN(_printf_float) eklendi. Generated dosyalarını elle düzenlemek yerine ilgili
kaynak düzenlenmeli ve Designer/Validation üretim adımları çalıştırılmalıdır.
