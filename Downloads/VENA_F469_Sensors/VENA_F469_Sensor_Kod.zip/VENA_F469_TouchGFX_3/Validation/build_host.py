from pathlib import Path
import subprocess,concurrent.futures,os,json
r=Path(__file__).resolve().parents[1];t=r/'TouchGFX';sdk=r/'Middlewares/ST/touchgfx';o=r/'Validation/host_build';o.mkdir(exist_ok=True)
incs=[t/'gui/include',t/'generated/gui_generated/include',t/'generated/texts/include',t/'generated/images/include',t/'generated/fonts/include',sdk/'framework/include']
files=list((t/'gui/src').rglob('*.cpp'))+list((t/'generated/gui_generated/src').rglob('*.cpp'))+list((t/'generated/fonts/src').rglob('*.cpp'))+list((t/'generated/texts/src').rglob('*.cpp'))+list((t/'generated/images/src').rglob('*.cpp'))+[r/'Validation/headless.cpp']
def compile(pair):
 i,f=pair;obj=o/(str(i)+'.o');cmd=['g++','-std=c++11','-O0','-ffunction-sections','-fdata-sections','-DSIMULATOR','-DUSE_BPP=16']+['-I'+str(p) for p in incs]+['-c',str(f),'-o',str(obj)];p=subprocess.run(cmd,capture_output=True,text=True);return p.returncode,obj,p.stderr
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:res=list(ex.map(compile,enumerate(files)))
errs=[x for x in res if x[0]];print('Compiled',len(res),'errors',len(errs),flush=True)
for e in errs[:5]:print(e[2][:2500])
if errs:raise SystemExit(1)
cmd=['g++','-no-pie','-Wl,--gc-sections']+[str(x[1]) for x in res]+[str(sdk/'lib/linux/libtouchgfx.a'),'-lpthread','-o',str(o/'vena_headless')];p=subprocess.run(cmd,capture_output=True,text=True);print('Link:',p.returncode,p.stderr[:10000]);(r/'Validation/headless_build.log').write_text(p.stderr if p.returncode else f'{len(files)} translation units compiled and linked with the real TouchGFX 4.26 Linux library.\n')
if p.returncode:raise SystemExit(1)
cmd=['g++','-std=c++11','-Wall','-Wextra','-Wno-misleading-indentation','-fsanitize=address,undefined','-DSIMULATOR','-I'+str(t/'gui/include'),str(r/'Validation/test_motor.cpp'),str(t/'gui/src/vena/VenaModel.cpp'),str(t/'gui/src/vena/VenaScene.cpp'),str(t/'gui/src/vena/MotorSimulator.cpp'),'-o',str(o/'test_state')]
subprocess.run(cmd,check=True);runtime=o/'runtime';runtime.mkdir(exist_ok=True);p=subprocess.run([str(o/'test_state')],cwd=runtime,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'),capture_output=True,text=True);print(p.stdout,p.stderr);(r/'Validation/motor_tests.log').write_text(p.stdout+p.stderr);assert p.returncode==0
