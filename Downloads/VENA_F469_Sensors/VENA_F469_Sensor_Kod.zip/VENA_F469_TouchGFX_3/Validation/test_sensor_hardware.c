/* Real hardware branch, HAL replaced at the boundary; deterministic time. */
#include "sensor_hal/stm32f4xx_hal.h"
#include "../Core/Inc/sensor_monitor.h"
#include "../Core/Inc/sensor_config.h"
#include <assert.h>
#include <stdio.h>
GPIO_TypeDef test_c={0},test_g={1},test_d={2};
static uint32_t now;
static uint8_t opt=1,air;
static GPIO_PinState optical_led,air_led;
static unsigned input_count,output_count,irq_enabled;
uint32_t HAL_GetTick(void){return now;}
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef*p,uint16_t pin){
 assert(p==GPIOC);assert(pin==GPIO_PIN_5||pin==GPIO_PIN_4);
 return (pin==GPIO_PIN_5?opt:air)?GPIO_PIN_SET:GPIO_PIN_RESET;
}
void HAL_GPIO_WritePin(GPIO_TypeDef*p,uint16_t pin,GPIO_PinState level){
 if(p==GPIOG&&pin==GPIO_PIN_6)optical_led=level;
 else {assert(p==GPIOD&&pin==GPIO_PIN_5);air_led=level;}
}
void HAL_GPIO_Init(GPIO_TypeDef*p,GPIO_InitTypeDef*g){
 if(p==GPIOC){
  assert(g->Pull==GPIO_PULLUP);
  if(g->Pin==GPIO_PIN_5)assert(g->Mode==GPIO_MODE_INPUT);
  else {assert(g->Pin==GPIO_PIN_4);assert(g->Mode==(SENSOR_AIR_ACTIVE_LEVEL?GPIO_MODE_IT_RISING:GPIO_MODE_IT_FALLING));}
  input_count++;
 }else {assert(g->Mode==GPIO_MODE_OUTPUT_PP);output_count++;}
}
void HAL_NVIC_DisableIRQ(int irq){assert(irq==EXTI4_IRQn);irq_enabled=0;}
void HAL_NVIC_EnableIRQ(int irq){assert(irq==EXTI4_IRQn);irq_enabled=1;}
void HAL_NVIC_SetPriority(int irq,uint32_t pre,uint32_t sub){assert(irq==EXTI4_IRQn&&pre==7&&sub==0);}
static void poll(uint32_t dt){now+=dt;Sensor_Poll();}
int main(void){
 air=!SENSOR_AIR_ACTIVE_LEVEL;
 assert(!Sensor_GetSnapshot().valid);
 Sensor_Init();assert(input_count==2&&output_count==2&&irq_enabled);
 assert(optical_led==GPIO_PIN_SET&&air_led==GPIO_PIN_SET);
 poll(19);assert(!Sensor_GetSnapshot().valid);
 poll(1);assert(Sensor_GetSnapshot().valid&&Sensor_GetSnapshot().optical_level==1);
 /* Optical bounce resets the 20 ms qualification; no LED flicker. */
 opt=0;poll(1);poll(19);assert(Sensor_GetSnapshot().optical_level==1);
 opt=1;poll(1);opt=0;poll(1);poll(20);
 assert(Sensor_GetSnapshot().optical_level==0&&optical_led==GPIO_PIN_RESET);
 opt=1;poll(1);poll(20);assert(Sensor_GetSnapshot().optical_level==1&&optical_led==GPIO_PIN_SET);
 /* A complete air pulse ends between polls. The active-edge IRQ retains it. */
 Sensor_AirIRQ();poll(1);
 assert(Sensor_GetSnapshot().air_level==!SENSOR_AIR_ACTIVE_LEVEL);
 assert(Sensor_GetSnapshot().air_warning==SENSOR_AIR_POLARITY_CONFIRMED);
 assert(Sensor_GetSnapshot().air_configured==SENSOR_AIR_POLARITY_CONFIRMED);
 if(SENSOR_AIR_POLARITY_CONFIRMED){
  assert(air_led==GPIO_PIN_RESET);poll(1999);assert(Sensor_GetSnapshot().air_warning);
  poll(1);assert(!Sensor_GetSnapshot().air_warning&&air_led==GPIO_PIN_SET);
 }
 air=SENSOR_AIR_ACTIVE_LEVEL;poll(1);poll(5000);
 assert(Sensor_GetSnapshot().air_warning==SENSOR_AIR_POLARITY_CONFIRMED);
 if(!SENSOR_AIR_POLARITY_CONFIRMED)assert(air_led==(air?GPIO_PIN_RESET:GPIO_PIN_SET));
 /* Stalled acquisition never displays old values as current. */
 now+=SENSOR_STALE_MS+1;assert(!Sensor_GetSnapshot().valid);
 poll(0);assert(Sensor_GetSnapshot().valid);
 /* Filtering and warning expiry work across the HAL 32-bit tick rollover. */
 now=UINT32_MAX-10U;air=!SENSOR_AIR_ACTIVE_LEVEL;Sensor_Init();poll(20);
 assert(Sensor_GetSnapshot().valid);
 Sensor_AirIRQ();poll(0);poll(1999);
 assert(Sensor_GetSnapshot().air_warning==SENSOR_AIR_POLARITY_CONFIRMED);
 poll(1);assert(!Sensor_GetSnapshot().air_warning);
 printf("PASS hardware branch: GPIO/IRQ/LED, optical bounce, sub-poll pulse, hold, stale, tick wrap; air confirmed=%u active=%u\n",SENSOR_AIR_POLARITY_CONFIRMED,SENSOR_AIR_ACTIVE_LEVEL);
 return 0;
}
