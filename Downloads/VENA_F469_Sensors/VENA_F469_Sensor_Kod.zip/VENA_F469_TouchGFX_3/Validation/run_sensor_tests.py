"""Deterministic sensor tests and existing motor regression, without hardware.
Usage: python3 Validation/run_sensor_tests.py
Requires GCC/G++ with AddressSanitizer and UndefinedBehaviorSanitizer.
"""
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
out = root / "Validation/sensor_build"
out.mkdir(exist_ok=True)
runtime = out / "runtime"
runtime.mkdir(exist_ok=True)
log = []

def execute(command, cwd=root):
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
    if result.stdout or result.stderr:
        print(result.stdout + result.stderr, end="", flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    return result.stdout + result.stderr

common = ["-Wall", "-Wextra", "-Werror", "-fsanitize=address,undefined"]
model_sources = ["TouchGFX/gui/src/vena/" + name for name in
                 ("VenaModel.cpp", "VenaScene.cpp", "MotorSimulator.cpp")]
for confirmed, active in ((0, 1), (1, 1), (1, 0)):
    defines = [f"-DSENSOR_AIR_POLARITY_CONFIRMED={confirmed}",
               f"-DSENSOR_AIR_ACTIVE_LEVEL={active}"]
    binary = out / f"hardware_{confirmed}_{active}"
    execute(["gcc", "-std=c11"] + common + defines +
            ["-IValidation/sensor_hal", "Core/Src/sensor_monitor.c",
             "Validation/test_sensor_hardware.c", "-o", str(binary)])
    log.append(execute([str(binary)]))
    binary = out / f"integration_{confirmed}_{active}"
    execute(["g++", "-std=c++11", "-Wno-misleading-indentation"] + common + defines +
            ["-DSIMULATOR", "-ITouchGFX/gui/include", "Validation/test_sensors.cpp"] +
            model_sources + ["-o", str(binary)])
    log.append(execute([str(binary)], runtime))

binary = out / "motor_regression"
execute(["g++", "-std=c++11", "-Wno-misleading-indentation"] + common +
        ["-DSIMULATOR", "-ITouchGFX/gui/include", "Validation/test_motor.cpp"] +
        model_sources + ["-o", str(binary)])
log.append(execute([str(binary)], runtime))
(root / "Validation/sensor_tests.log").write_text("".join(log))
print("PASS: 6 sensor configurations/suites + existing motor regression.")
