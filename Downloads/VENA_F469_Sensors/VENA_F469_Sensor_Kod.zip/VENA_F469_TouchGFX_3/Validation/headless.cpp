#include <platform/driver/lcd/LCD16bpp.hpp>
#include <platform/driver/touch/TouchController.hpp>
#include <touchgfx/hal/NoDMA.hpp>
#include <touchgfx/hal/OSWrappers.hpp>
#include <common/TouchGFXInit.hpp>
#include <gui/vena/VenaPanel.hpp>
#include <gui/vena/MotorPort.hpp>
#include <cstdio>
#include <cstdarg>
#include <touchgfx/hal/PaintImpl.hpp>
#include <touchgfx/hal/PaintRGB565Impl.hpp>
#include <cstring>
#include <cstdlib>
#include <cassert>
using namespace touchgfx;
static uint16_t pixels[800*480];
class NoTouch:public TouchController{public:void init(){}bool sampleTouch(int32_t&,int32_t&){return false;}};
class TestHAL:public HAL{public:TestHAL(DMA_Interface&d,LCD&l,TouchController&t,uint16_t w,uint16_t h):HAL(d,l,t,w,h){}void configureInterrupts(){}void enableInterrupts(){}void disableInterrupts(){}void enableLCDControllerInterrupt(){}uint16_t*getTFTFrameBuffer()const{return pixels;}void setTFTFrameBuffer(uint16_t*){}void flushFrameBuffer(){}void flushFrameBuffer(const Rect&){}void frame(){backPorchExited();} };
namespace touchgfx {void simulator_printf(const char*f,va_list a){vfprintf(stderr,f,a);} void OSWrappers::initialize(){}void OSWrappers::deinitialize(){}void OSWrappers::signalVSync(){}void OSWrappers::signalRenderingDone(){}void OSWrappers::waitForVSync(){}bool OSWrappers::isVSyncAvailable(){return true;}void OSWrappers::takeFrameBufferSemaphore(){}void OSWrappers::tryTakeFrameBufferSemaphore(){}void OSWrappers::giveFrameBufferSemaphore(){}void OSWrappers::giveFrameBufferSemaphoreFromISR(){}void OSWrappers::taskDelay(uint16_t){}void OSWrappers::taskYield(){} }
int main(int argc,char**argv){NoDMA dma;LCD16bpp lcd;NoTouch tc;HAL&hal=touchgfx_generic_init<TestHAL>(dma,lcd,tc,800,480,0,0);hal.setFrameBufferStartAddresses(pixels,0,0);if(argc>1&&!strcmp(argv[1],"running")){auto&m=vena::model();m.newProgram(vena::RATE);m.set(vena::RATE_F,100);m.start();Motor_Heartbeat();Motor_SimulatorAdvance(100);vena::navigateNative(vena::HOME);}else if(argc>1&&strcmp(argv[1],"test")){vena::model().page=(vena::Page)atoi(argv[1]);vena::navigateNative(vena::model().page);}
if(argc>1&&(!strcmp(argv[1],"air")||!strcmp(argv[1],"clear")||!strcmp(argv[1],"locked")||!strcmp(argv[1],"sensors"))){
 auto&m=vena::model();m.newProgram(vena::RATE);m.set(vena::RATE_F,100);assert(m.start());
 Sensor_SimulatorSetConnected(1);Sensor_SimulatorSetLevels(0,strcmp(argv[1],"clear")!=0);
 Sensor_SimulatorAdvance(1);Sensor_SimulatorAdvance(20);m.refreshSensors();
 Motor_Heartbeat();Motor_SimulatorAdvance(100);
 m.locked=!strcmp(argv[1],"locked");vena::navigateNative(!strcmp(argv[1],"sensors")?vena::SENSORS:vena::HOME);
}
for(int i=0;i<3;i++)static_cast<TestHAL&>(hal).frame();if(argc>1&&!strcmp(argv[1],"test")){
 auto frame=[&](){for(int i=0;i<2;i++)static_cast<TestHAL&>(hal).frame();};
 auto click=[&](int x,int y){Application::getInstance()->handleClickEvent(ClickEvent(ClickEvent::PRESSED,x,y));Application::getInstance()->handleClickEvent(ClickEvent(ClickEvent::RELEASED,x,y));frame();};
 click(100,160);assert(vena::model().page==vena::MODES);
 click(180,100);assert(vena::model().page==vena::PARAMS);
 click(180,100);assert(vena::model().page==vena::NUMPAD);
 click(465,240);click(590,240);click(590,165);click(320,440);
 assert(vena::model().page==vena::PARAMS);assert(vena::model().v[vena::RATE_F]==125);
 click(560,280);assert(vena::model().state==vena::RUNNING);assert(vena::model().page==vena::HOME);assert(Motor_GetTargetFrequency()==406);assert(Motor_IsRunning());
 // Live sensor event must survive the real Panel without pausing the motor.
 Sensor_SimulatorSetConnected(1);Sensor_SimulatorSetLevels(0,1);
 Sensor_SimulatorAdvance(1);Sensor_SimulatorAdvance(20);vena::model().refreshSensors();frame();
 assert(vena::model().sensors.air_warning&&vena::model().state==vena::RUNNING&&Motor_IsRunning());
 click(100,160);assert(vena::model().state==vena::PAUSED);assert(!Motor_IsRunning());click(100,160);assert(vena::model().state==vena::RUNNING);
 click(100,244);assert(vena::model().page==vena::BOLUS);
 Application::getInstance()->handleClickEvent(ClickEvent(ClickEvent::PRESSED,190,280));assert(vena::model().bolusActive);
 Application::getInstance()->handleClickEvent(ClickEvent(ClickEvent::RELEASED,190,280));assert(!vena::model().bolusActive);assert(Motor_GetTargetFrequency()==406);
 click(710,440);click(710,440);click(680,300);assert(vena::model().state==vena::STOPPED);assert(!Motor_IsRunning());assert(Motor_GetTargetFrequency()==0);
 puts("PASS: real TouchGFX click routing, rate entry, start, pause/resume, manual bolus press/release, STOP and actual motor API state.");
}
FILE*f=fopen(argc>2?argv[2]:"frame.raw","wb");fwrite(pixels,2,800*480,f);fclose(f);printf("Rendered %u bytes; Panel %zu bytes; model %zu bytes\n",800*480*2,sizeof(vena::Panel),sizeof(vena::Model));return 0;}
