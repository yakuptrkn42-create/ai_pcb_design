"""Build actual CubeIDE linked sources with Arm GNU; no generated mock HAL.
Usage: python3 Validation/build_arm.py /path/to/toolchain/bin
"""
from pathlib import Path
import sys,subprocess,concurrent.futures,xml.etree.ElementTree as ET,urllib.parse
r=Path(__file__).resolve().parents[1];tool=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/usr/bin');o=r/'Validation/arm_build';o.mkdir(exist_ok=True)
project=ET.parse(r/'STM32CubeIDE/.project');sources=[]
for link in project.findall('.//link'):
 uri=urllib.parse.unquote(link.findtext('locationURI',''));rel=uri.split('/',1)[-1];p=r/rel
 if p.suffix.lower() in ('.c','.cpp','.s'): assert p.is_file(),p;sources.append(p)
sources += [p for p in (r/'STM32CubeIDE/Application').rglob('*') if p.suffix.lower() in ('.c','.cpp','.s')]
sources=sorted(set(sources))
config=ET.parse(r/'STM32CubeIDE/.cproject');incs=[]
for option in config.findall('.//option'):
 if option.get('valueType')=='includePath':
  for el in option.findall('listOptionValue'):
   v=el.get('value','');p=(r/'STM32CubeIDE/Debug'/v).resolve()
   if p.is_dir() and p not in incs:incs.append(p)
arch=['-mcpu=cortex-m4','-mthumb','-mfpu=fpv4-sp-d16','-mfloat-abi=hard']
flags=arch+['-g','-Os','-ffunction-sections','-fdata-sections','-Wall','-DUSE_HAL_DRIVER','-DSTM32F469xx','-DUSE_BPP=16']+['-I'+str(i) for i in incs]
def compile(pair):
 i,p=pair;obj=o/(str(i)+'.o');cpp=p.suffix=='.cpp';cmd=[str(tool/('arm-none-eabi-g++' if cpp else 'arm-none-eabi-gcc'))]+flags
 if cpp:cmd+=['-std=c++11','-fno-exceptions','-fno-rtti']
 elif p.suffix.lower()=='.s':cmd+=['-x','assembler-with-cpp']
 else:cmd+=['-std=gnu11']
 cmd+=['-c',str(p),'-o',str(obj)];v=subprocess.run(cmd,capture_output=True,text=True);return p,obj,v.returncode,v.stdout+v.stderr
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:result=list(pool.map(compile,enumerate(sources)))
log=f'Arm GNU; Cortex-M4; fpv4-sp-d16; hard float; CubeIDE linked source inventory: {len(sources)} units.\n'
for p,obj,rc,msg in result:
 if msg:log+=str(p.relative_to(r))+'\n'+msg
errors=sum(bool(v[2]) for v in result);log+=f'Compile errors: {errors}\n';print(log,flush=True)
if errors:(r/'Validation/arm_cubeide_build.log').write_text(log);sys.exit(1)
out=r/'Firmware';out.mkdir(exist_ok=True);elf=out/'VENA_F469_Sensors.elf'
args=o/'objects.rsp';args.write_text('\n'.join('"'+str(x[1])+'"' for x in result))
lib=r/'Middlewares/ST/touchgfx/lib/core/cortex_m4f/gcc/libtouchgfx-float-abi-hard.a'
cmd=[str(tool/'arm-none-eabi-g++')]+arch+['-specs=nano.specs','-specs=nosys.specs','-Wl,--gc-sections','-Wl,--print-memory-usage','-Wl,--fatal-warnings','-Wl,-Map='+str(out/'VENA_F469_Sensors.map'),'-T',str(r/'STM32F469XX_FLASH.ld'),'@'+str(args),'-Wl,--start-group',str(lib),'-lm','-lc','-lstdc++','-lsupc++','-Wl,--end-group','-o',str(elf)]
v=subprocess.run(cmd,capture_output=True,text=True);log+=v.stdout+v.stderr+f'Link result: {v.returncode}\n';(r/'Validation/arm_cubeide_build.log').write_text(log);print(v.stdout,v.stderr,flush=True)
if v.returncode:sys.exit(v.returncode)
subprocess.run([str(tool/'arm-none-eabi-objcopy'),'-O','ihex',str(elf),str(out/'VENA_F469_Sensors.hex')],check=True)
# HEX contains both internal Flash and external QSPI data; do not flatten to BIN.
print('PASS: full ARM compile/link; Firmware ELF + combined HEX created.')
