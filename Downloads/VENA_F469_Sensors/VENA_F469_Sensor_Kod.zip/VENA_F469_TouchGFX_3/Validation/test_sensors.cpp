#include <gui/vena/VenaModel.hpp>
#include <gui/vena/VenaScene.hpp>
#include <gui/vena/MotorPort.hpp>
#include "../Core/Inc/sensor_config.h"
#include <cassert>
#include <cstring>
#include <cstdio>
using namespace vena;
static void advance(Model&m,unsigned ms){
 while(ms){unsigned d=ms>10?10:ms;Motor_Heartbeat();Motor_SimulatorAdvance(d);Sensor_SimulatorAdvance(d);m.tick(d/1000.0);ms-=d;}
}
static bool has(const Scene&s,const char*t){for(int i=0;i<s.count;i++)if(strstr(s.nodes[i].text,t))return true;return false;}
static void sceneBounds(Model&m){
 Scene s;
 for(int page=1;page<=44;page++){
  if(page>35&&page<42)continue;
  m.page=(Page)page;buildScene(m,s);assert(s.count<100);
  for(int i=0;i<s.count;i++){const Node&n=s.nodes[i];assert(n.x>=0&&n.y>=0&&n.x+n.w<=800&&n.y+n.h<=480);}
 }
 m.page=HOME;m.locked=true;buildScene(m,s);assert(has(s,"BS241")||has(s,"HAVA KABARCIĞI")||has(s,"Hava sinyali yok"));m.locked=false;
}
int main(){
 Motor_Init();Sensor_Init();Model m;Scene s;
 m.refreshSensors();assert(!m.sensors.valid);m.page=HOME;buildScene(m,s);assert(has(s,"okuma bekleniyor"));
 Sensor_SimulatorSetLevels(1,!SENSOR_AIR_ACTIVE_LEVEL);Sensor_SimulatorSetConnected(1);
 advance(m,20);assert(m.sensors.valid&&m.sensors.optical_level==1);
 assert(m.set(RATE_F,100));assert(m.start());advance(m,100);
 unsigned hz=Motor_GetCurrentFrequency(),target=Motor_GetTargetFrequency();assert(hz==385&&target==385);
 for(unsigned opt=0;opt<2;opt++)for(unsigned air=0;air<2;air++){
  Sensor_SimulatorSetLevels(opt,air);advance(m,40);
  assert(m.sensors.optical_level==opt&&m.sensors.air_level==air);
  assert(m.state==RUNNING&&Motor_IsRunning()&&Motor_GetCurrentFrequency()==hz&&Motor_GetTargetFrequency()==target);
  assert(m.error[0]==0);sceneBounds(m);
 }
 m.page=HOME;Sensor_SimulatorSetLevels(0,!SENSOR_AIR_ACTIVE_LEVEL);advance(m,2100);
 /* Entire air pulse between polls. No UI alarm, navigation or motor pause. */
 Sensor_SimulatorSetLevels(0,SENSOR_AIR_ACTIVE_LEVEL);Sensor_SimulatorSetLevels(0,!SENSOR_AIR_ACTIVE_LEVEL);advance(m,10);
 assert(m.sensors.air_warning==SENSOR_AIR_POLARITY_CONFIRMED);
 buildScene(m,s);
 if(SENSOR_AIR_POLARITY_CONFIRMED)assert(has(s,"HAVA KABARCIĞI"));
 else {assert(has(s,"ayar gerekli"));assert(!has(s,"HAVA KABARCIĞI"));}
 assert(m.page==HOME&&m.state==RUNNING&&Motor_IsRunning()&&Motor_GetTargetFrequency()==target);
 advance(m,2000);assert(!m.sensors.air_warning);
 m.pause();Sensor_SimulatorSetLevels(0,SENSOR_AIR_ACTIVE_LEVEL);advance(m,40);assert(m.state==PAUSED&&!Motor_IsRunning());
 assert(m.resume());assert(m.beginBolus(true));advance(m,40);assert(m.bolusActive&&Motor_IsRunning());m.endBolus();
 m.stop();advance(m,40);assert(m.state==STOPPED&&!Motor_IsRunning());
 /* Active sensor at START never prevents starting; KVO also keeps running. */
 assert(m.start());assert(m.state==RUNNING&&Motor_IsRunning());m.stop();
 m.newProgram(RATE);assert(m.set(RATE_F,100));assert(m.set(VOLUME,.1));m.kvoEnabled=true;assert(m.start());advance(m,4000);
 assert(m.state==KVO&&Motor_IsRunning());Sensor_SimulatorSetConnected(0);advance(m,40);
 assert(!m.sensors.valid&&m.state==KVO&&Motor_IsRunning());m.stop();
 puts("PASS sensor/UI integration: all 0/1 combinations; short pulse; hold; unknown polarity; 38 screen bounds + lock; start/run/pause/resume/bolus/stop/KVO unaffected.");
}
