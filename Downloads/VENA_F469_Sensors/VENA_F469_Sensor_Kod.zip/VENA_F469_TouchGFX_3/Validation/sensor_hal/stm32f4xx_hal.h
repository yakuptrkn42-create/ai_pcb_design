#ifndef SENSOR_TEST_HAL_H
#define SENSOR_TEST_HAL_H
#include <stdint.h>
typedef struct { int id; } GPIO_TypeDef;
extern GPIO_TypeDef test_c,test_g,test_d;
#define GPIOC (&test_c)
#define GPIOG (&test_g)
#define GPIOD (&test_d)
#define GPIO_PIN_4 (1U<<4)
#define GPIO_PIN_5 (1U<<5)
#define GPIO_PIN_6 (1U<<6)
typedef enum { GPIO_PIN_RESET=0,GPIO_PIN_SET=1 } GPIO_PinState;
typedef struct { uint32_t Pin,Mode,Pull,Speed; } GPIO_InitTypeDef;
#define GPIO_MODE_INPUT 0U
#define GPIO_MODE_OUTPUT_PP 1U
#define GPIO_MODE_IT_RISING 2U
#define GPIO_MODE_IT_FALLING 3U
#define GPIO_NOPULL 0U
#define GPIO_PULLUP 1U
#define GPIO_SPEED_FREQ_LOW 0U
#define EXTI4_IRQn 4
#define __HAL_RCC_GPIOC_CLK_ENABLE() ((void)0)
#define __HAL_RCC_GPIOG_CLK_ENABLE() ((void)0)
#define __HAL_RCC_GPIOD_CLK_ENABLE() ((void)0)
#define __HAL_GPIO_EXTI_CLEAR_IT(pin) ((void)(pin))
uint32_t HAL_GetTick(void);
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef*,uint16_t);
void HAL_GPIO_WritePin(GPIO_TypeDef*,uint16_t,GPIO_PinState);
void HAL_GPIO_Init(GPIO_TypeDef*,GPIO_InitTypeDef*);
void HAL_NVIC_DisableIRQ(int);
void HAL_NVIC_EnableIRQ(int);
void HAL_NVIC_SetPriority(int,uint32_t,uint32_t);
#endif
