#include <gui/model/Model.hpp>
#include <gui/model/ModelListener.hpp>
#include <gui/vena/VenaModel.hpp>
#include <gui/vena/VenaPanel.hpp>
#include <gui/vena/MotorPort.hpp>
#ifdef SIMULATOR
#include <chrono>
static uint32_t nowMs(){using namespace std::chrono;return (uint32_t)duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();}
#else
extern "C" uint32_t HAL_GetTick(void);
static uint32_t nowMs(){return HAL_GetTick();}
#endif
Model::Model():modelListener(0){
#ifdef SIMULATOR
 Motor_Init();
 Sensor_Init();
#endif
}
void Model::tick(){Motor_Heartbeat();static uint32_t last=nowMs();uint32_t now=nowMs();uint32_t diff=now-last;if(diff>=100){last=now;
#ifdef SIMULATOR
 Motor_SimulatorAdvance(diff);
 Sensor_SimulatorAdvance(diff);
#endif
vena::Page before=vena::model().page;vena::model().tick(diff/1000.0);if(vena::model().page!=before)vena::navigateNative(vena::model().page);}}
