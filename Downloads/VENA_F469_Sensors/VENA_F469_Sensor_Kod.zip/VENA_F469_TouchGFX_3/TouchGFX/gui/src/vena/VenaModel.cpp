#include <gui/vena/VenaModel.hpp>
#include <gui/vena/MotorPort.hpp>
#include <gui/vena/DataLoggerPort.hpp>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <algorithm>
namespace vena {
const FieldDef Model::fields[NFIELDS]={
 {"Akış hızı","mL/h",.001,2000,3},{"Hedef hacim · VTBI","mL",.001,9999,3},{"Toplam süre","dk",1,1440,0},
 {"Doz hızı","mcg/kg/dk",.01,100,2},{"Hasta ağırlığı","kg",.5,300,1},{"İlaç miktarı","mg",.01,10000,2},{"Çözelti hacmi","mL",.1,9999,2},
 {"Doz hacmi","mL",.1,9999,2},{"Doz süresi","dk",1,1440,0},{"Başlangıçlar arası","dk",1,1440,0},{"Doz sayısı","adet",1,20,0},
 {"1. sekans hızı","mL/h",.1,2000,2},{"1. sekans hacmi","mL",.1,9999,2},{"2. sekans hızı","mL/h",.1,2000,2},{"2. sekans hacmi","mL",.1,9999,2},{"3. sekans hızı","mL/h",.1,2000,2},{"3. sekans hacmi","mL",.1,9999,2},
 {"Sekonder hacim","mL",.1,9999,2},{"Sekonder hız","mL/h",.1,2000,2},{"Artış süresi","dk",0,1440,0},{"Plato süresi","dk",0,1440,0},{"Azalış süresi","dk",0,1440,0},
 {"Bolus hacmi","mL",.1,10,2},{"Bolus süresi","sn",1,120,0},{"Manuel bolus hızı","mL/h",.1,2000,2},{"KVO hızı","mL/h",.1,20,2},{"KVO süresi","dk",1,120,0},
 {"Ekran parlaklığı","%",10,100,0},{"Alarm ses seviyesi","%",0,100,0},{"UP alt limit","mmHg",-1000,1000,0},{"UP üst limit","mmHg",-1000,1000,0},{"DOWN alt limit","mmHg",-1000,1000,0},{"DOWN üst limit","mmHg",-1000,1000,0},{"Tek kabarcık filtresi","µL",10,1000,0},{"Toplam hava / 15 dk","µL",10,10000,0},
 {"En küçük yaş","yıl",0,120,0},{"En büyük yaş","yıl",0,120,0},{"Set kalibrasyon hacmi","mL",.1,9999,2}
};
static void copy(char* out,size_t n,const char* in){snprintf(out,n,"%s",in?in:"");}
Model::Model():page(HOME),returnPage(HOME),editReturn(PARAMS),mode(RATE),state(READY),editing(RATE_F),elapsed(0),delivered(0),bolusDelivered(0),bolusElapsed(0),bolusGoal(0),bolusDuration(0),bolusRate(0),primeVolume(0),kvoElapsed(0),planVolume(0),planSeconds(0),planRate(0),stepElapsed(0),stepCount(0),stepIndex(0),seqTab(0),derived(MINUTES),bolusActive(false),bolusManual(false),primeActive(false),kvoEnabled(false),muted(false),serviceUnlocked(false),dirty(true),light(false),locked(false),historyCount(0),selectedPatient(-1),selectedDrug(-1),patientCount(0),recordCount(0),filterGender(-1),filterDrug(-1),settingChannel(0),textField(-1),formAge(30),formGender(0),brightness(80),sound(60),replaceEntry(true),recordOpen(false){
 sensors=SensorSnapshot{};
 for(int i=0;i<NFIELDS;i++)v[i]=NAN;
 memset(entry,0,sizeof entry);memset(error,0,sizeof error);memset(patientName,0,sizeof patientName);memset(drugName,0,sizeof drugName);memset(history,0,sizeof history);memset(patients,0,sizeof patients);memset(records,0,sizeof records);memset(&draft,0,sizeof draft);
 v[BOL_VOLUME]=2;v[BOL_SECONDS]=24;v[BOL_RATE]=300;v[KVO_RATE]=1;v[KVO_MIN]=30;v[BRIGHTNESS]=80;v[SOUND]=60;v[AIR_SINGLE]=50;v[AIR_TOTAL]=500;
 log("Arayüz başlatıldı");
}
Model& model(){static Model m;return m;}
const char* Model::modeLabel(int m){static const char* a[]={"Hız Modu","Zaman Modu","Sekans","Piggyback","Ağırlık Modu","TPN","Aralıklı Mod","Mikro Mod","Trapezoidal Mod"};return m>=0&&m<9?a[m]:"";}
const char* Model::drugLabel(int i){static const char* a[]={"Dopamine","Dobutamine","Noradrenaline","Adrenaline","Heparin","Insulin","Furosemide","Saline"};return i>=0&&i<8?a[i]:"İlaç seçilmedi";}
const char* Model::modeName()const{return modeLabel(mode);}
const char* Model::stateName()const{static const char* a[]={"İNFÜZYONA HAZIR","İNFÜZYON SÜRÜYOR","DURAKLATILDI","ALARM","TAMAMLANDI","KVO AKTİF","SONLANDIRILDI"};return bolusActive?"BOLUS AKTİF":a[state];}
const FieldDef& Model::definition(Field f)const{return fields[f];}
bool Model::busy()const{return state==RUNNING||state==PAUSED||state==ALARM||state==KVO;}
void Model::log(const char* s){for(int i=23;i>0;--i)copy(history[i],96,history[i-1]);snprintf(history[0],96,"%02u:%02u  %s",unsigned(elapsed)/60,unsigned(elapsed)%60,s);historyCount=std::min(24,historyCount+1);dirty=true;}
void Model::navigate(Page p){
 if(page==PRIME){primeActive=false;}
 if(page==BOLUS&&p!=BOLUS&&bolusActive)endBolus();
 if((p<SERVICE||p>SERVICE_RECORDS)&&!(p==NUMPAD&&editReturn>=SERVICE&&editReturn<=SERVICE_RECORDS))serviceUnlocked=false;
 if(p>=SERVICE&&p<=SERVICE_RECORDS&&!serviceUnlocked)p=PIN;
 page=p;error[0]=0;dirty=true;
}
void Model::newProgram(Mode m){if(busy())return;mode=m;for(int i=0;i<=FALL;i++)v[i]=NAN;derived=MINUTES;seqTab=0;state=READY;delivered=elapsed=0;stepCount=0;planVolume=planSeconds=planRate=0;error[0]=0;dirty=true;}
void Model::applyDerived(Field changed){
 if(mode!=RATE&&mode!=TIME)return;
 if(changed==VOLUME&&!isfinite(v[VOLUME])&&mode==RATE){derived=MINUTES;v[MINUTES]=NAN;return;}
 if(changed==derived){derived=changed==MINUTES?VOLUME:MINUTES;}
 double r=v[RATE_F],vol=v[VOLUME],t=v[MINUTES];
 double x=derived==RATE_F?vol*60/t:derived==VOLUME?r*t/60:vol*60/r;
 v[derived]=isfinite(x)&&x>0?x:NAN;
}
bool Model::set(Field f,double value){
 if(f<0||f>=NFIELDS)return false;
 if(f<=FALL&&!canEdit(f)){copy(error,sizeof error,"Aktif program değiştirilemez.");return false;}
 bool optional=(f==VOLUME&&mode==RATE)||f==AGE_MIN||f==AGE_MAX;
 if(!isfinite(value)&&optional){v[f]=NAN;applyDerived(f);dirty=true;return true;}
 const FieldDef& d=fields[f];double lo=d.low;if(mode!=MICRO&&(f==RATE_F||f==VOLUME))lo=.1;
 if(!isfinite(value)||value<lo||value>d.high){snprintf(error,sizeof error,"%s: %.3g–%.3g %s",d.label,lo,d.high,d.unit);return false;}
 if ((f==RATE_F || f==BOL_RATE || f==KVO_RATE) && !Motor_IsFlowRateSupported((float)value)) {
  snprintf(error,sizeof error,"Motor aralığı: %.0f–%.0f mL/h",Motor_GetMinimumFlowRate(),Motor_GetMaximumFlowRate());return false;
 }
 if(f==RATE_F && busy()) {
  // Keep delivered volume and elapsed time; only replan the remaining segment.
  v[RATE_F]=planRate=value;double rest=remaining()/value*3600.0;
  steps[0]={value,rest,0};stepCount=1;stepIndex=0;stepElapsed=0;
  planSeconds=elapsed+rest;v[MINUTES]=isfinite(planSeconds)?planSeconds/60.0:NAN;
  derived=MINUTES;error[0]=0;log("Akış hızı değiştirildi");syncMotor();return true;
 }
 v[f]=value;applyDerived(f);error[0]=0;dirty=true;return true;
}
void Model::addStep(double r,double s,int k){if(stepCount<40&&s>0){steps[stepCount++]={r,s,k};}}
bool Model::calculate(){
 stepCount=0;planVolume=planSeconds=planRate=0;double r=v[RATE_F],vol=v[VOLUME],sec=vol/r*3600;
 if(mode==RATE&&!isfinite(vol)){planVolume=INFINITY;planSeconds=INFINITY;planRate=r;addStep(r,INFINITY);return isfinite(r)&&r>0;}
 switch(mode){
 case TIME:sec=v[MINUTES]*60;r=vol/sec*3600;break;
 case WEIGHT:r=v[DOSE]*v[WEIGHT_F]*60*v[DILUENT]/(v[DRUG_AMOUNT]*1000);sec=vol/r*3600;break;
 case SEQUENCE:vol=sec=0;for(int i=0;i<3;i++){double vr=v[R1+i*2],vv=v[V1+i*2];vol+=vv;sec+=vv/vr*3600;addStep(vr,vv/vr*3600);}r=v[R1];break;
 case PIGGYBACK:vol=v[VOLUME]+v[SECONDARY];sec=v[SECONDARY]/v[SECOND_RATE]*3600+v[VOLUME]/r*3600;addStep(v[SECOND_RATE],v[SECONDARY]/v[SECOND_RATE]*3600);addStep(r,v[VOLUME]/r*3600);r=v[SECOND_RATE];break;
 case INTERMITTENT:r=v[EACH]/v[DOSE_MIN]*60;vol=v[EACH]*v[COUNT];sec=((v[COUNT]-1)*v[INTERVAL]+v[DOSE_MIN])*60;for(int i=0;i<int(isfinite(v[COUNT])?v[COUNT]:0)&&i<20;i++){addStep(r,v[DOSE_MIN]*60);if(i+1<v[COUNT])addStep(0,(v[INTERVAL]-v[DOSE_MIN])*60,3);}break;
 case TPN:case TRAPEZOID:{double rise=v[RISE],fall=v[FALL],plateau=mode==TPN?v[MINUTES]-rise-fall:v[PLATEAU];sec=(rise+plateau+fall)*60;r=vol*60/(plateau+(rise+fall)*.5);addStep(r,rise*60,1);addStep(r,plateau*60);addStep(r,fall*60,2);break;}
 default:break;
 }
if (!stepCount)
{
    addStep(r, sec);
}

planVolume = vol;
planSeconds = sec;
planRate = r; return isfinite(r)&&r>0&&r<=2000&&isfinite(vol)&&vol>0&&isfinite(sec)&&sec>0;
}
bool Model::validate(){
 error[0]=0;
 int f[8],n=0;
 switch(mode){case RATE:case TIME:case MICRO:f[n++]=RATE_F;if(mode!=RATE||isfinite(v[VOLUME]))f[n++]=VOLUME;if(mode==TIME)f[n++]=MINUTES;break;
 case WEIGHT:f[n++]=DOSE;f[n++]=WEIGHT_F;f[n++]=DRUG_AMOUNT;f[n++]=DILUENT;f[n++]=VOLUME;break;
 case SEQUENCE:for(int i=R1;i<=V3;i++)f[n++]=i;break;
 case PIGGYBACK:f[n++]=RATE_F;f[n++]=VOLUME;f[n++]=SECONDARY;f[n++]=SECOND_RATE;break;
 case INTERMITTENT:f[n++]=EACH;f[n++]=DOSE_MIN;f[n++]=INTERVAL;f[n++]=COUNT;break;
 case TPN:case TRAPEZOID:f[n++]=VOLUME;f[n++]=RISE;f[n++]=FALL;f[n++]=mode==TPN?MINUTES:PLATEAU;break;}
 for(int i=0;i<n;i++){int k=f[i];if(!isfinite(v[k])||v[k]<fields[k].low||v[k]>fields[k].high){snprintf(error,sizeof error,"%s girin.",fields[k].label);return false;}}
 if(mode==INTERMITTENT&&(v[INTERVAL]<v[DOSE_MIN]||v[COUNT]!=floor(v[COUNT]))){copy(error,sizeof error,"Aralık doz süresinden kısa olamaz.");return false;}
 if(mode==TPN&&v[RISE]+v[FALL]>=v[MINUTES]){copy(error,sizeof error,"Artış + azalış toplam süreden küçük olmalı.");return false;}
 if(!calculate()){copy(error,sizeof error,"Hesaplanan program geçersiz (hız / süre).");return false;}
 for(int i=0;i<stepCount;i++)if(!isfinite(steps[i].rate)||steps[i].rate<0||steps[i].rate>2000){copy(error,sizeof error,"Adım hızı aralık dışında.");return false;}
 return true;
}
bool Model::start(){if(busy()||!validate()||!motorProgramValid())return false;Motor_Stop();state=RUNNING;elapsed=delivered=bolusDelivered=stepElapsed=0;stepIndex=0;recordOpen=true;log("İnfüzyon başlatıldı");navigate(HOME);syncMotor();return state==RUNNING;}
void Model::pause(){if(state==RUNNING){state=PAUSED;Motor_Pause();endBolus();log("İnfüzyon duraklatıldı");}}
bool Model::resume(){if(state!=PAUSED)return false;
 if(Motor_GetFault()!=MOTOR_FAULT_NONE){copy(error,sizeof error,"Motor hatası: Sonlandır ile sıfırlayın.");dirty=true;return false;}
 state=RUNNING;Motor_SetFlowRate((float)rateNow());Motor_Resume();syncMotor();log("İnfüzyon devam ediyor");return state==RUNNING;}
void Model::stop(){state=STOPPED;Motor_Stop();endBolus();primeActive=false;finishRecord("STOPPED");state=STOPPED;log("İnfüzyon sonlandırıldı");navigate(RESULT);}
void Model::raiseAlarm(const char* reason){state=ALARM;Motor_Pause();endBolus();primeActive=false;copy(error,sizeof error,reason);log(reason);dirty=true;}
void Model::clearAlarm(){if(state==ALARM){state=PAUSED;muted=false;error[0]=0;log("Alarm giderildi; devam onayı bekleniyor");}}
bool Model::beginBolus(bool manual){if(state!=RUNNING||bolusActive)return false;double rate=manual?v[BOL_RATE]:v[BOL_VOLUME]*3600/v[BOL_SECONDS];if(!isfinite(rate)||rate<=0||rate>2000){copy(error,sizeof error,"Bolus hızı 0–2000 mL/h aralığında olmalı.");dirty=true;return false;}if(!Motor_IsFlowRateSupported((float)rate)){snprintf(error,sizeof error,"Motor aralığı: %.0f–%.0f mL/h",Motor_GetMinimumFlowRate(),Motor_GetMaximumFlowRate());dirty=true;return false;}bolusActive=true;bolusManual=manual;bolusRate=rate;bolusElapsed=0;bolusGoal=manual?INFINITY:v[BOL_VOLUME];bolusDuration=manual?INFINITY:v[BOL_SECONDS];log(manual?"Manuel bolus başladı":"Otomatik bolus başladı");syncMotor();return true;}
void Model::endBolus(){if(bolusActive){bolusActive=false;log("Bolus sonlandı");syncMotor();}}
double Model::rateNow()const{if(bolusActive)return bolusRate;if(state==KVO)return v[KVO_RATE];if(state!=RUNNING||stepIndex>=stepCount)return planRate;const Step&s=steps[stepIndex];double q=s.seconds>0?stepElapsed/s.seconds:0;return s.kind==1?s.rate*q:s.kind==2?s.rate*(1-q):s.rate;}
double Model::remaining()const{return isfinite(planVolume)?std::max(0.,planVolume-delivered):INFINITY;}
double Model::remainingSeconds()const{return isfinite(planSeconds)?std::max(0.,planSeconds-elapsed):INFINITY;}
void Model::complete(){endBolus();finishRecord("COMPLETED");if(kvoEnabled){state=KVO;kvoElapsed=0;}else state=COMPLETE;log("Program tamamlandı");dirty=true;syncMotor();}
void Model::refreshSensors(){
 SensorSnapshot s=Sensor_GetSnapshot();
 if(s.valid!=sensors.valid || s.optical_level!=sensors.optical_level ||
    s.air_level!=sensors.air_level || s.air_configured!=sensors.air_configured ||
    s.air_warning!=sensors.air_warning){sensors=s;dirty=true;}
}
void Model::tick(double dt){
 refreshSensors(); /* Status only. Never call raiseAlarm or alter motor state. */
 // All early returns (KVO expiry, wait, bolus end, completion) synchronize output.
 struct MotorSync { Model& m; ~MotorSync(){m.syncMotor();} } sync{*this};
 if(!isfinite(dt)||dt<=0)return;
 if(primeActive&&!busy()){primeVolume+=15.*dt/60.;dirty=true;}
 if(state==KVO){double d=std::min(dt,std::max(0.,v[KVO_MIN]*60-kvoElapsed));kvoElapsed+=d;if(kvoElapsed>=v[KVO_MIN]*60){state=COMPLETE;log("KVO süresi doldu");}dirty=true;return;}
 if(state!=RUNNING)return;
 if(bolusActive){double d=std::min(dt,std::max(0.,bolusDuration-bolusElapsed));double volume=bolusRate*d/3600;bolusDelivered+=volume;bolusElapsed+=d;if(bolusElapsed>=bolusDuration){endBolus();if(page==BOLUS)page=BOLUS_DONE;}dirty=true;return;}
 while(dt>1e-8&&state==RUNNING&&stepIndex<stepCount){Step&s=steps[stepIndex];double d=std::min(dt,s.seconds-stepElapsed);if(d<=1e-8){stepIndex++;stepElapsed=0;continue;}double r=s.rate;if(s.kind==1)r*=((stepElapsed+d*.5)/s.seconds);if(s.kind==2)r*=(1-(stepElapsed+d*.5)/s.seconds);delivered+=r*d/3600;elapsed+=d;stepElapsed+=d;dt-=d;if(stepElapsed>=s.seconds-1e-8){stepIndex++;stepElapsed=0;}if(stepIndex>=stepCount){if(isfinite(planVolume))delivered=planVolume;complete();}}
 dirty=true;
}
bool Model::canEdit(Field f) const {
 return !busy() || (mode==RATE && f==RATE_F && !bolusActive && (state==RUNNING||state==PAUSED));
}
bool Model::motorProgramValid() {
 for(int i=0;i<stepCount;i++) {
  if(steps[i].kind==1 || steps[i].kind==2) {
   copy(error,sizeof error,"Rampa modu: 300 Hz altı desteklenmiyor.");dirty=true;return false;
  }
  if(!Motor_IsFlowRateSupported((float)steps[i].rate)) {
   snprintf(error,sizeof error,"Motor aralığı: %.0f–%.0f mL/h",Motor_GetMinimumFlowRate(),Motor_GetMaximumFlowRate());dirty=true;return false;
  }
 }
 if(kvoEnabled&&!Motor_IsFlowRateSupported((float)v[KVO_RATE])) {
  copy(error,sizeof error,"KVO hızı motor aralığı dışında.");dirty=true;return false;
 }
 return true;
}
void Model::syncMotor() {
 if(state!=RUNNING && state!=KVO) {Motor_Pause();return;}
 if(Motor_GetFault()!=MOTOR_FAULT_NONE) {
  raiseAlarm("Motor durdu: bağlantı / hız hatası.");return;
 }
 double rate=rateNow();
 if(!Motor_IsFlowRateSupported((float)rate)) {raiseAlarm("Motor hızı sınır dışında.");return;}
 Motor_SetFlowRate((float)rate);
 if(rate>0 && !Motor_IsRunning()) Motor_Start();
}
void Model::finishRecord(const char* result){if(!recordOpen)return;recordOpen=false;if(recordCount==24){for(int i=1;i<24;i++)records[i-1]=records[i];recordCount--;}
 Record&r=records[recordCount++];copy(r.patient,sizeof r.patient,patientName[0]?patientName:"Hasta seçilmedi");copy(r.drug,sizeof r.drug,drugName[0]?drugName:"İlaç seçilmedi");r.mode=mode;r.age=selectedPatient>=0?patients[selectedPatient].age:-1;r.gender=selectedPatient>=0?patients[selectedPatient].gender:-1;r.volume=delivered+bolusDelivered;r.seconds=(uint32_t)elapsed;
 const Patient* p=selectedPatient>=0?&patients[selectedPatient]:0;SDLoggerStatus st=SDLogger_LogInfusion(r.patient,p?p->code:"",p?p->ward:"",r.drug,modeName(),r.age,r.gender,r.volume,r.seconds,result?result:"");if(st!=SDLOGGER_OK)log("SD infüzyon kaydı yazılamadı");}
void Model::edit(Field f,Page back){editing=f;editReturn=back;replaceEntry=true;if(isfinite(v[f]))snprintf(entry,sizeof entry,"%.*f",fields[f].decimals,v[f]);else entry[0]=0;navigate(NUMPAD);}
void Model::key(char c){if(c=='C'){entry[0]=0;replaceEntry=false;}else if(c=='<'){size_t n=strlen(entry);if(n)entry[n-1]=0;replaceEntry=false;}else{if(replaceEntry){entry[0]=0;replaceEntry=false;}size_t n=strlen(entry);if(n>=14)return;if(c=='.'&&strchr(entry,'.'))return;if(c=='-'&&n)return;entry[n]=c;entry[n+1]=0;}error[0]=0;dirty=true;}
bool Model::accept(){char*end=0;double value=entry[0]?strtod(entry,&end):NAN;if(entry[0]&&(!end||*end)){copy(error,sizeof error,"Geçerli sayı girin.");return false;}if(entry[0]){const char* dot=strchr(entry,'.');if(dot&&strlen(dot+1)>fields[editing].decimals){copy(error,sizeof error,"Ondalık basamak sayısı fazla.");return false;}}if(!set(editing,value))return false;navigate(editReturn);return true;}
void Model::savePatient(){if(!draft.name[0]){copy(error,sizeof error,"Hasta adı girin.");dirty=true;return;}if(patientCount>=12){copy(error,sizeof error,"Hasta belleği dolu (12).");return;}draft.age=formAge;draft.gender=formGender;patients[patientCount]=draft;selectedPatient=patientCount++;copy(patientName,sizeof patientName,draft.name);SDLoggerStatus st=SDLogger_LogPatient(draft.name,draft.code,draft.ward,draft.age,draft.gender,draft.weight);log(st==SDLOGGER_OK?"Hasta kaydedildi + SD":"Hasta kaydedildi; SD yazılamadı");navigate(PATIENT_CONFIRM);}
int Model::matchingRecords()const{int n=0;for(int i=0;i<recordCount;i++){const Record&r=records[i];if(filterGender>=0&&r.gender!=filterGender)continue;if(isfinite(v[AGE_MIN])&&r.age<v[AGE_MIN])continue;if(isfinite(v[AGE_MAX])&&r.age>v[AGE_MAX])continue;if(filterDrug>=0&&strcmp(r.drug,drugLabel(filterDrug)))continue;n++;}return n;}
}
