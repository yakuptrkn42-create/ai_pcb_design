// Simulator links the same conversion/ramp/state logic, without STM32 registers.
#ifdef SIMULATOR
#include "../../../../Core/Src/motor_control.c"
#include "../../../../Core/Src/sd_logger.c"
#include "../../../../Core/Src/sensor_monitor.c"
#endif
