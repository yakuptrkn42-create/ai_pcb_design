#include <gui/vena/VenaScene.hpp>
#include <gui/vena/MotorPort.hpp>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <algorithm>
namespace vena {
static const unsigned BG=0x080c0e,CARD=0x252d31,EDIT_BG=0x233b40,ACCENT=0x59cbd3,DIM=0xb2c1c7,TEXT=0xf2f6f7,LINE=0x3c494e,OK=0x70d5a0,DANGER=0xff8189;
static unsigned bgColor=BG,cardColor=CARD,textColor=TEXT;
static Node* node(Scene&s,int x,int y,int w,int h){if(s.count>=100)return 0;Node*n=&s.nodes[s.count++];memset(n,0,sizeof *n);n->x=x;n->y=y;n->w=w;n->h=h;return n;}
void Scene::box(int x,int y,int w,int h,unsigned color){Node*n=node(*this,x,y,w,h);if(n){n->kind=0;n->bg=color;}}
void Scene::text(int x,int y,int w,int h,const char*t,int size,unsigned c,int align){Node*n=node(*this,x,y,w,h);if(n){n->kind=1;n->size=size;n->color=c==TEXT?textColor:c;n->align=align;snprintf(n->text,sizeof n->text,"%s",t);}}
void Scene::button(int x,int y,int w,int h,const char*t,int a,unsigned bg,unsigned fg,int size){Node*n=node(*this,x,y,w,h);if(n){n->kind=2;n->action=a;n->size=size;n->color=fg==TEXT?textColor:fg;n->bg=bg==CARD?cardColor:bg;n->align=1;snprintf(n->text,sizeof n->text,"%s",t);}}
void Scene::slider(int x,int y,int w,int h,Field f,double val){Node*n=node(*this,x,y,w,h);if(n){n->kind=3;n->action=EDIT+f;n->size=int(val);n->bg=LINE;n->color=ACCENT;}}
static void fmt(char*b,size_t n,double v,const char*unit="",int dec=2){if(!isfinite(v)){snprintf(b,n,"—");return;}char a[50];snprintf(a,sizeof a,"%.*f",dec,v);if(strchr(a,'.')){int i=strlen(a)-1;while(i>=0&&a[i]=='0')a[i--]=0;if(i>=0&&a[i]=='.')a[i]=0;}snprintf(b,n,"%s%s%s",a,unit[0]?" ":"",unit);}
static void clockText(char*b,size_t n,double sec){if(!isfinite(sec)){snprintf(b,n,"—");return;}unsigned t=(unsigned)std::max(0.,sec);snprintf(b,n,"%02u:%02u:%02u",t/3600,(t/60)%60,t%60);}
static const char* airText(const Model&m){
 if(!m.sensors.valid)return "BS241: okuma bekleniyor";
 if(!m.sensors.air_configured)return m.sensors.air_level?"BS241: 1 (ayar gerekli)":"BS241: 0 (ayar gerekli)";
 return m.sensors.air_warning?"HAVA KABARCIĞI":"Hava sinyali yok";
}
static const char* opticalText(const Model&m){
 if(!m.sensors.valid)return "Optik: okuma bekleniyor";
 return m.sensors.optical_level?"Optik: hedef yok (1)":"Optik: hedef var (0)";
}
static unsigned airColor(const Model&m){return !m.sensors.valid||!m.sensors.air_configured?DIM:m.sensors.air_warning?DANGER:OK;}
static void sensorHeader(Model&m,Scene&s){
 s.text(508,5,276,24,airText(m),14,airColor(m),2);
 s.text(508,28,276,22,opticalText(m),14,m.sensors.valid&&!m.sensors.optical_level?OK:DIM,2);
}
static void header(Model&m,Scene&s,const char*title,Page back=HOME){s.box(0,0,800,480,bgColor);s.text(16,10,470,38,title,26,ACCENT);sensorHeader(m,s);s.box(16,52,768,1,LINE);s.button(16,412,128,52,"‹ Geri",NAV+back);s.button(656,412,128,52,"Ana sayfa",NAV+HOME,0x18383e);if(m.error[0])s.text(156,374,490,32,m.error,16,DANGER,1);}
static void tile(Scene&s,int i,int n,const char*t,int act){int cols=n<=3?1:2,rows=(n+cols-1)/cols;int w=(768-(cols-1)*12)/cols,h=(300-(rows-1)*12)/rows;s.button(16+(i%cols)*(w+12),68+(i/cols)*(h+12),w,h,t,act);}
static void field(Model&m,Scene&s,int x,int y,int w,int h,Field f,bool derived=false){char b[96];fmt(b,sizeof b,m.v[f],"",m.mode==MICRO?3:m.definition(f).decimals);s.button(x,y,w,h,"",derived||!m.canEdit(f)?NONE:EDIT+f,derived?0x172125:EDIT_BG);s.text(x+14,y+8,w-28,28,(f==VOLUME&&m.mode==RATE?"VTBI · Opsiyonel":m.definition(f).label),16,DIM);s.text(x+14,y+38,w-110,h>100?54:36,b,h>100?36:26,derived?TEXT:ACCENT);s.text(x+w-105,y+h-31,91,26,m.definition(f).unit,14,DIM,2);if(!derived&&m.canEdit(f))s.box(x+14,y+h-3,w-28,2,0xa56b70);}
static void caption(Scene&s,const char*t){s.text(156,419,486,40,t,16,DIM,1);}
void buildScene(Model&m,Scene&s){
 s.count=0;bgColor=m.light?0xffffff:BG;cardColor=m.light?0xf4f7f8:CARD;textColor=m.light?0x26383e:TEXT;
 char b[160],c[80];
 if(m.page==HOME){
 s.box(0,0,800,480,bgColor);s.text(16,10,125,36,"VENA",26,ACCENT);s.text(154,14,342,30,m.stateName(),18,m.state==ALARM?DANGER:ACCENT);snprintf(b,sizeof b,"STEP %lu / %lu Hz",(unsigned long)Motor_GetCurrentFrequency(),(unsigned long)Motor_GetTargetFrequency());s.text(546,16,238,27,b,16,DIM,2);
 s.button(16,56,176,65,"Menü",NAV+MENU);s.button(16,133,176,65,m.state==RUNNING?"Duraklat":m.state==PAUSED?"Devam":m.state==ALARM?"Alarm":m.state==KVO?"KVO":"Yeni İnfüzyon",PRIMARY,ACCENT,0x10292e);s.button(16,210,176,65,"Bolus",NAV+BOLUS);
 s.button(204,56,300,220,"",NAV+PARAMS,bgColor);s.text(222,68,190,26,m.mode==SEQUENCE?"Sekans":"Akış hızı",18,DIM);s.text(422,68,64,26,"mL/h",18,DIM,2);
 if(m.mode==SEQUENCE&&m.stepCount){for(int i=0;i<3;i++){s.box(220+i*90,103,86,84,m.state==RUNNING&&m.stepIndex==i?0x18362a:cardColor);snprintf(b,sizeof b,"Sekans %d",i+1);s.text(223+i*90,109,80,24,b,14,DIM,1);fmt(b,sizeof b,m.v[R1+i*2]);s.text(223+i*90,137,80,38,b,24,m.stepIndex==i?OK:TEXT,1);}}else{fmt(b,sizeof b,m.state==READY?m.v[RATE_F]:m.rateNow());s.text(214,112,280,74,b,48,m.busy()?TEXT:ACCENT,1);}
 double pct=isfinite(m.planVolume)&&m.planVolume>0?100*m.remaining()/m.planVolume:NAN;s.text(222,200,155,24,"Kalan hacim",14,DIM);if(isfinite(pct))snprintf(b,sizeof b,"%%%d",int(ceil(pct)));else strcpy(b,"—");s.text(370,195,115,32,b,24,ACCENT,2);s.box(222,236,264,8,LINE);if(isfinite(pct)&&pct>0)s.box(222,236,int(264*std::min(100.,pct)/100),8,ACCENT);s.text(214,249,280,23,m.mode==RATE?"Akış hızını düzenle ›":m.busy()?"Programı görüntüle ›":"Parametreleri düzenle ›",14,ACCENT,1);s.box(204,274,300,2,ACCENT);
 s.box(516,56,268,220,cardColor);s.text(534,70,232,28,"Verilen hacim",18);fmt(b,sizeof b,m.delivered,"",2);s.text(534,98,198,54,b,36);s.text(727,123,40,25,"mL",16,DIM,2);fmt(c,sizeof c,m.bolusDelivered,"mL",2);snprintf(b,sizeof b,"Bolus: %s",c);s.text(534,151,232,22,b,14,DIM);s.text(534,177,232,26,"Hat basıncı",18);s.text(534,207,232,22,"UP —     DOWN — mmHg",14,DIM);s.text(534,242,232,24,"Set bilgisi ›",16,OK);s.button(534,240,232,29,"Set bilgisi ›",NAV+CHECK,cardColor,OK,16);
 s.box(16,288,378,100,bgColor);s.box(204,302,1,60,LINE);s.text(32,300,172,24,"Kalan hacim",16);s.text(220,302,166,23,"Hedef hacim · VTBI",14);fmt(b,sizeof b,m.busy()||m.state==COMPLETE?m.remaining():m.v[VOLUME],"",0);s.text(32,331,135,44,b,30);fmt(b,sizeof b,m.busy()?m.planVolume:m.v[VOLUME],"",0);s.text(220,331,142,44,b,30);s.text(166,347,30,23,"mL",14,DIM);s.text(358,347,30,23,"mL",14,DIM);s.box(16,386,378,2,ACCENT);
 s.box(406,288,378,100,bgColor);s.box(594,302,1,72,LINE);s.text(422,300,170,24,isfinite(m.planSeconds)?"Kalan süre":"Geçen süre",16);s.text(610,300,166,24,"Planlanan süre",16);clockText(b,sizeof b,isfinite(m.planSeconds)?m.remainingSeconds():m.elapsed);s.text(422,329,168,44,b,26);clockText(b,sizeof b,m.planSeconds>0?m.planSeconds:NAN);s.text(610,329,169,44,b,26);s.text(422,364,160,22,"sa:dk:sn",14,DIM);s.text(610,364,160,22,"sa:dk:sn",14,DIM);s.box(406,386,378,2,ACCENT);
 s.box(16,400,372,64,cardColor);s.text(32,406,235,29,m.drugName[0]?m.drugName:"İlaç seçilmedi",18,ACCENT);s.text(32,438,235,22,m.patientName[0]?m.patientName:"Hasta seçilmedi",14,DIM);s.text(267,420,110,32,m.modeName(),14,DIM,2);
 s.box(400,400,m.busy()?196:384,64,cardColor);s.text(408,404,m.busy()?180:368,27,airText(m),14,airColor(m),1);s.text(408,437,m.busy()?180:368,24,opticalText(m),14,m.sensors.valid&&!m.sensors.optical_level?OK:DIM,1);if(m.busy())s.button(608,400,176,64,"Sonlandır",STOP_CONFIRM,0x372024,DANGER);
 if(m.locked){s.box(0,0,800,480,0x080c0e);s.text(120,160,560,60,"Ekran kilitli",36,ACCENT,1);s.button(250,270,300,64,"Kilidi aç",UNLOCK);s.text(120,358,560,28,airText(m),20,airColor(m),1);s.text(120,398,560,28,opticalText(m),18,DIM,1);}
 return;
 }
 switch(m.page){
 case MENU:header(m,s,"Menü");{const char*t[]={"Yeni İnfüzyon","Hasta Yönetimi","İlaç Kütüphanesi","Raporlar","Olay Kayıtları","Ayarlar"};Page p[]={MODES,PATIENTS,DRUGS,REPORTS,HISTORY,SETTINGS};for(int i=0;i<6;i++)tile(s,i,6,t[i],NAV+p[i]);}break;
 case MODES:header(m,s,"Yeni İnfüzyon");for(int i=0;i<4;i++)tile(s,i,4,Model::modeLabel(i),SELECT_MODE+i);s.button(160,412,480,52,"Daha Fazla Mod ›",NAV+MORE);break;
 case MORE:header(m,s,"Daha Fazla Mod",MODES);for(int i=0;i<5;i++)tile(s,i,6,Model::modeLabel(i+4),SELECT_MODE+i+4);break;
 case PARAMS:{header(m,s,m.modeName(),MODES);if(m.mode==RATE||m.mode==TIME||m.mode==MICRO){field(m,s,16,68,378,140,RATE_F,m.derived==RATE_F&&m.mode!=MICRO);field(m,s,406,68,378,140,VOLUME,m.derived==VOLUME&&m.mode!=MICRO);field(m,s,16,220,378,140,MINUTES,m.derived==MINUTES||m.mode==MICRO);s.button(406,220,378,140,m.busy()?"Aktif program":"Başlat",m.busy()?NAV+HOME:START,ACCENT,0x10292e,30);if(!m.busy()&&m.mode!=MICRO)s.button(160,412,228,52,"Giriş çifti ↔",PAIR);}
 else{int fs[6],n=0;if(m.mode==SEQUENCE){for(int i=0;i<3;i++){snprintf(b,sizeof b,"Sekans %d",i+1);s.button(16+i*260,68,248,48,b,SEQ1+i,i==m.seqTab?0x18362a:cardColor);}fs[n++]=R1+m.seqTab*2;fs[n++]=V1+m.seqTab*2;for(int i=0;i<n;i++)field(m,s,16+i*390,132,378,148,(Field)fs[i]);}
 else{if(m.mode==WEIGHT){int a[]={DOSE,WEIGHT_F,DRUG_AMOUNT,DILUENT,VOLUME};n=5;memcpy(fs,a,sizeof a);}if(m.mode==TPN||m.mode==TRAPEZOID){int a[]={VOLUME,m.mode==TPN?MINUTES:PLATEAU,RISE,FALL};n=4;memcpy(fs,a,sizeof a);}if(m.mode==INTERMITTENT){int a[]={EACH,DOSE_MIN,INTERVAL,COUNT};n=4;memcpy(fs,a,sizeof a);}if(m.mode==PIGGYBACK){int a[]={RATE_F,VOLUME,SECOND_RATE,SECONDARY};n=4;memcpy(fs,a,sizeof a);}for(int i=0;i<n;i++)field(m,s,16+(i%2)*390,68+(i/2)*99,378,89,(Field)fs[i]);}
 s.button(406,412,234,52,m.busy()?"Programa dön":"Başlat",m.busy()?NAV+HOME:START,ACCENT,0x10292e);}
 if(!m.busy())s.button(404,374,178,30,"Hasta",NAV+PATIENTS,CARD,TEXT,16);
 // Error text is kept above controls, never under a button.
 if(m.error[0]){s.box(16,366,768,40,bgColor);s.text(20,370,760,36,m.error,16,DANGER,1);}break;}
 case NUMPAD:header(m,s,m.definition(m.editing).label,m.editReturn);s.box(16,68,378,106,EDIT_BG);s.text(32,82,344,56,m.entry[0]?m.entry:"—",36,ACCENT,2);s.text(32,145,344,25,m.definition(m.editing).unit,16,DIM,2);if(m.editing==RATE_F)snprintf(b,sizeof b,"Motor: %.0f – %.0f mL/h",Motor_GetMinimumFlowRate(),Motor_GetMaximumFlowRate());else snprintf(b,sizeof b,"Aralık: %.3g – %.3g",m.definition(m.editing).low,m.definition(m.editing).high);s.text(20,196,368,38,b,18,DIM);{const char*keys="789456123.0-";for(int i=0;i<12;i++){char k[2]={keys[i],0};s.button(412+i%3*124,68+i/3*72,116,64,k,KEY+keys[i]);}}s.button(16,266,180,64,"Sil",BACKSPACE);s.button(210,266,184,64,"Temizle",CLEAR);s.button(160,412,480,52,"Onayla",ACCEPT,ACCENT,0x10292e);break;
 case BOLUS:header(m,s,"Bolus");s.text(20,68,756,28,m.state==RUNNING?"Ana infüzyon sürerken bolus uygulanabilir.":"Bolus için aktif infüzyon gerekli.",18,m.state==RUNNING?DIM:DANGER);s.box(16,112,378,249,cardColor);s.text(32,125,340,35,"Manuel Bolus",26,ACCENT);fmt(b,sizeof b,m.v[BOL_RATE],"mL/h");s.text(32,172,340,47,b,30);s.button(32,242,346,94,m.bolusActive&&m.bolusManual?"Bırakınca sonlanır":"Basılı tut · Bolus",HOLD_BOLUS,ACCENT,0x10292e);field(m,s,406,112,378,100,BOL_VOLUME);field(m,s,406,222,378,100,BOL_SECONDS);s.button(406,332,378,48,m.bolusActive?"Bolusu durdur":"Otomatik başlat",m.bolusActive?STOP_BOLUS:AUTO_BOLUS,0x18362a,OK);fmt(c,sizeof c,m.bolusDelivered,"mL");snprintf(b,sizeof b,"Verilen bolus: %s",c);caption(s,b);break;
 case BOLUS_DONE:header(m,s,"Bolus tamamlandı");fmt(b,sizeof b,m.bolusDelivered,"mL");s.text(60,117,680,60,b,48,ACCENT,1);s.text(60,208,680,40,"Ana infüzyona devam ediliyor.",24,TEXT,1);s.button(220,292,360,65,"Ana ekrana dön",NAV+HOME,ACCENT,0x10292e);break;
 case SETTINGS:header(m,s,"Ayarlar",MENU);tile(s,0,3,"Genel Ayarlar",NAV+GENERAL);tile(s,1,3,"İnfüzyon Ayarları",NAV+INF_SETTINGS);tile(s,2,3,"Cihaz Bilgileri",NAV+SYSTEM);break;
 case GENERAL:header(m,s,"Genel Ayarlar",SETTINGS);tile(s,0,4,"Ekran / Görünüm",NAV+DISPLAY);tile(s,1,4,"Ses",NAV+AUDIO);tile(s,2,4,"Dil",NAV+LANGUAGE);tile(s,3,4,"Saat",NAV+CLOCK);break;
 case DISPLAY:header(m,s,"Ekran / Görünüm",GENERAL);s.text(32,82,730,32,"Ekran parlaklığı",24);snprintf(b,sizeof b,"%%%d",int(m.v[BRIGHTNESS]));s.text(620,127,142,40,b,30,ACCENT,2);s.slider(32,180,730,56,BRIGHTNESS,m.v[BRIGHTNESS]);s.button(32,266,354,70,m.light?"Açık tema ✓":"Açık tema",TOGGLE_LIGHT);s.button(408,266,354,70,"Ekranı kilitle",LOCK);caption(s,"Değerler bu oturumda tutulur.");break;
 case AUDIO:header(m,s,"Ses",GENERAL);s.text(32,82,730,36,"Alarm ses seviyesi",24);snprintf(b,sizeof b,"%%%d",int(m.v[SOUND]));s.text(620,132,142,40,b,30,ACCENT,2);s.slider(32,190,730,56,SOUND,m.v[SOUND]);s.text(32,288,730,50,"Ses sürücüsü: donanım bağlantısı bekleniyor",18,DIM);break;
 case LANGUAGE:header(m,s,"Dil",GENERAL);tile(s,0,2,"Türkçe ✓",NONE);s.text(32,238,730,90,"Bu portun arayüz dili Türkçe.\nÇeviriler texts.xml üzerinden geliştirilebilir.",20,DIM);break;
 case CLOCK:header(m,s,"Saat",GENERAL);s.text(32,98,736,55,"RTC bağlantısı bekleniyor",30,ACCENT,1);clockText(b,sizeof b,m.elapsed);s.text(32,180,736,66,b,48,TEXT,1);s.text(32,266,736,45,"Ekrandaki süre: aktif programın geçen süresi",18,DIM,1);break;
 case INF_SETTINGS:header(m,s,"İnfüzyon Ayarları",SETTINGS);tile(s,0,4,"Basınç · UP / DOWN",NAV+PRESSURE);tile(s,1,4,"Hava Algılama",NAV+AIR);tile(s,2,4,"KVO",NAV+KVO_SETTINGS);tile(s,3,4,"Bolus",NAV+BOLUS_SETTINGS);break;
 case PRESSURE:header(m,s,"Basınç Ayarları",INF_SETTINGS);s.button(16,68,378,52,"UPSTREAM",CHANNEL_UP,m.settingChannel==0?EDIT_BG:cardColor);s.button(406,68,378,52,"DOWNSTREAM",CHANNEL_DOWN,m.settingChannel==1?EDIT_BG:cardColor);field(m,s,16,144,378,145,m.settingChannel?DOWN_LOW:UP_LOW);field(m,s,406,144,378,145,m.settingChannel?DOWN_HIGH:UP_HIGH);caption(s,"Sensör ölçümü henüz bağlı değil.");break;
 case AIR:header(m,s,"Hava Algılama",INF_SETTINGS);
 s.text(32,88,730,44,airText(m),30,airColor(m));
 snprintf(b,sizeof b,"BS241 dijital giriş: %s",m.sensors.valid?(m.sensors.air_level?"1 / HIGH":"0 / LOW"):"—");s.text(32,148,730,32,b,22);
 s.text(32,204,730,110,"Yalnızca durum / uyarı gösterimi.\nMotor çalışması sensörden etkilenmez.\nDijital çıkıştan kabarcık hacmi (µL) ölçülmez.",20,DIM);
 s.text(32,330,730,44,m.sensors.air_configured?"Uyarı kısa darbelerden sonra 2 sn tutulur.":"BS241 çıkış tipi ve polaritesi doğrulanmalı.",18,DIM);break;
 case KVO_SETTINGS:header(m,s,"KVO",INF_SETTINGS);field(m,s,16,68,378,170,KVO_RATE);field(m,s,406,68,378,170,KVO_MIN);s.button(16,266,768,72,m.kvoEnabled?"İnfüzyon sonunda KVO ile devam ✓":"İnfüzyon sonunda akışı durdur",TOGGLE_KVO);break;
 case BOLUS_SETTINGS:header(m,s,"Bolus Ayarları",INF_SETTINGS);field(m,s,16,68,768,110,BOL_RATE);field(m,s,16,194,378,140,BOL_VOLUME);field(m,s,406,194,378,140,BOL_SECONDS);break;
 case SYSTEM:header(m,s,"Cihaz Bilgileri",SETTINGS);s.text(32,80,730,38,"VENA · STM32F469I-DISCO",26,ACCENT);s.text(32,137,730,34,"TouchGFX 4.26 · 800×480 · RGB565",20);s.text(32,188,730,34,"Arayüz prototipi · Motor / sensör sürücüsü bağlı değil",18,DIM);s.button(32,262,730,74,"Bakım / Kalibrasyon ›",NAV+PIN);break;
 case PIN:header(m,s,"Servis girişi",SYSTEM);s.text(32,82,342,50,"PIN",30,ACCENT);snprintf(b,sizeof b,"%.*s",int(strlen(m.entry)),"********");s.text(32,145,342,56,b,36);s.text(32,218,342,66,"Bakım / Kalibrasyon\nVarsayılan PIN: 0000",18,DIM);{const char*k="1234567890";for(int i=0;i<10;i++){char t[2]={k[i],0};s.button(412+(i%3)*124,68+(i/3)*72,116,64,t,1000+k[i]);}}s.button(16,324,178,52,"Temizle",PIN_CLEAR);s.button(210,324,184,52,"Giriş",PIN_ACCEPT,ACCENT,0x10292e);break;
 case SERVICE:header(m,s,"Bakım / Kalibrasyon",SYSTEM);tile(s,0,3,"Sensör Durumu",NAV+SENSORS);tile(s,1,3,"Set Kalibrasyonu",NAV+CALIBRATION);tile(s,2,3,"Bakım Kayıtları",NAV+SERVICE_RECORDS);break;
 case SENSORS:header(m,s,"Sensör Durumu",SERVICE);
 s.text(32,80,730,40,opticalText(m),26,m.sensors.valid&&!m.sensors.optical_level?OK:DIM);
 s.text(32,136,730,40,airText(m),26,airColor(m));
 snprintf(b,sizeof b,"BS241 ham giriş: %s | Optik LED: %s",m.sensors.valid?(m.sensors.air_level?"1":"0"):"—",m.sensors.valid&&!m.sensors.optical_level?"AÇIK":"KAPALI");s.text(32,192,730,34,b,20);
 s.text(32,246,730,104,"Optik: PC5 · LED1 (yeşil)\nBS241: PC4 · LED3 (kırmızı)\nSensörler motor için kilitleme oluşturmaz.",20,DIM);
 s.text(32,358,730,30,"UP / DOWN / batarya: sensör bağlantısı yok",18,DIM);break;
 case CALIBRATION:header(m,s,"Set Kalibrasyonu",SERVICE);field(m,s,32,80,730,150,SET_VOLUME);s.text(32,251,730,58,"Bu alan arayüz taslağıdır; pompa kalibrasyonu uygulamaz.",18,DIM);s.button(32,321,730,54,"Taslağı kaydet",SERVICE_SAVE,EDIT_BG,ACCENT);break;
 case SERVICE_RECORDS:header(m,s,"Bakım Kayıtları",SERVICE);for(int i=0;i<std::min(m.historyCount,6);i++)s.text(32,76+i*46,730,40,m.history[i],18);break;
 case PATIENTS:header(m,s,"Hasta Yönetimi",MENU);if(!m.patientCount)s.text(32,132,730,50,"Henüz hasta kaydı yok.",26,DIM,1);for(int i=0;i<std::min(m.patientCount,6);i++)tile(s,i,6,m.patients[i].name,SELECT_PATIENT+i);s.button(160,412,480,52,"+ Yeni hasta",NEW_PATIENT,EDIT_BG,ACCENT);break;
 case PATIENT_FORM:header(m,s,"Hasta Bilgileri",PATIENTS);if(m.textField>=0){s.box(16,65,768,63,EDIT_BG);s.text(28,78,744,42,m.entry,24,ACCENT);const char*keys="QWERTYUIOPASDFGHJKLZXCVBNM0123456789";int len=strlen(keys);for(int i=0;i<len;i++){char t[2]={keys[i],0};s.button(16+i%10*77,142+i/10*55,70,47,t,1200+keys[i],CARD,TEXT,18);}s.button(16,366,180,36,"Boşluk",1200+' ');s.button(210,366,180,36,"Sil",BACKSPACE);s.button(410,366,374,36,"Kaydet",SAVE_TEXT,ACCENT,0x10292e);}
 else{snprintf(b,sizeof b,"Ad Soyad: %s",m.draft.name);s.button(16,68,768,60,b,TEXT_NAME);snprintf(b,sizeof b,"Hasta kodu: %s",m.draft.code);s.button(16,140,378,60,b,TEXT_CODE);snprintf(b,sizeof b,"Servis: %s",m.draft.ward);s.button(406,140,378,60,b,TEXT_WARD);snprintf(b,sizeof b,"Yaş: %d",m.formAge);s.text(32,233,190,38,b,26);s.button(226,220,72,58,"−",AGE_MINUS);s.button(310,220,72,58,"+",AGE_PLUS);s.button(406,220,378,58,m.formGender?"Kadın":"Erkek",GENDER);s.button(16,310,768,62,"Hastayı kaydet",SAVE_PATIENT,ACCENT,0x10292e);}
 break;
 case PATIENT_CONFIRM:header(m,s,"Hasta Seçimi",PATIENTS);s.text(32,95,730,58,m.patientName,36,ACCENT,1);if(m.selectedPatient>=0){Patient&p=m.patients[m.selectedPatient];snprintf(b,sizeof b,"%s · %d yaş · %s",p.code,p.age,p.gender?"Kadın":"Erkek");s.text(32,177,730,42,b,24,TEXT,1);s.text(32,236,730,36,p.ward,20,DIM,1);}s.button(210,302,380,62,"Seçili hasta ile devam",NAV+PARAMS,ACCENT,0x10292e);break;
 case DRUGS:header(m,s,"İlaç Kütüphanesi",MENU);for(int i=0;i<8;i++){s.button(16+(i%2)*390,68+(i/2)*76,378,66,Model::drugLabel(i),SELECT_DRUG+i,i==m.selectedDrug?EDIT_BG:cardColor);}caption(s,"İlaç adları: örnek katalog");break;
 case DRUG_DETAIL:header(m,s,"İlaç Bilgisi",DRUGS);s.text(32,98,730,60,m.drugName,36,ACCENT,1);s.text(32,184,730,80,"Doz / konsantrasyon sınırları tanımlanmadı.\nProgram değerleri parametre ekranından girilir.",20,DIM,1);s.button(210,302,380,62,"Programı düzenle",NAV+PARAMS,ACCENT,0x10292e);break;
 case REPORTS:header(m,s,"Raporlar",MENU);tile(s,0,3,"Filtreler",NAV+FILTERS);tile(s,1,3,"Uygulama Listesi",NAV+REPORT_LIST);snprintf(b,sizeof b,"Toplam %d uygulama",m.matchingRecords());tile(s,2,3,b,NAV+REPORT_LIST);break;
 case FILTERS:header(m,s,"Rapor Filtreleri",REPORTS);field(m,s,16,68,378,112,AGE_MIN);field(m,s,406,68,378,112,AGE_MAX);s.button(16,194,378,68,m.filterGender<0?"Cinsiyet: Tümü":m.filterGender?"Cinsiyet: Kadın":"Cinsiyet: Erkek",FILTER_GENDER);snprintf(b,sizeof b,"İlaç: %s",m.filterDrug<0?"Tümü":Model::drugLabel(m.filterDrug));s.button(406,194,378,68,b,FILTER_DRUG);s.button(16,286,378,68,"Filtreleri temizle",RESET_FILTERS);s.button(406,286,378,68,"Sonuçları göster",NAV+REPORT_LIST,ACCENT,0x10292e);caption(s,"Ekranda son kayıtlar; kalıcı CSV kayıtları SD kartta.");break;
 case REPORT_LIST:header(m,s,"Uygulama Listesi",REPORTS);{int j=0;for(int i=m.recordCount-1;i>=0&&j<6;i--){Record&r=m.records[i];if(m.filterGender>=0&&r.gender!=m.filterGender)continue;if(isfinite(m.v[AGE_MIN])&&r.age<m.v[AGE_MIN])continue;if(isfinite(m.v[AGE_MAX])&&r.age>m.v[AGE_MAX])continue;if(m.filterDrug>=0&&strcmp(r.drug,Model::drugLabel(m.filterDrug)))continue;snprintf(b,sizeof b,"%s · %s · %.2f mL",r.patient,r.drug,r.volume);s.box(16,68+j*48,768,42,cardColor);s.text(28,74+j*48,744,36,b,16);j++;}if(!j)s.text(32,136,730,60,"Filtreye uygun kayıt yok.",26,DIM,1);}break;
 case HISTORY:header(m,s,"Olay Kayıtları",MENU);for(int i=0;i<std::min(m.historyCount,6);i++){s.box(16,68+i*49,768,43,cardColor);s.text(28,76+i*49,744,32,m.history[i],16);}caption(s,"Son 24 olay RAM belleğinde tutulur.");break;
 case RESULT:header(m,s,"İnfüzyon Sonucu");s.text(32,88,730,42,m.stateName(),30,ACCENT,1);fmt(c,sizeof c,m.delivered,"mL");snprintf(b,sizeof b,"Verilen hacim: %s",c);s.text(32,161,730,45,b,26,TEXT,1);clockText(c,sizeof c,m.elapsed);snprintf(b,sizeof b,"Süre: %s",c);s.text(32,222,730,42,b,26,TEXT,1);s.button(210,296,380,65,m.state==KVO?"KVO sonlandır":"Yeni İnfüzyon",m.state==KVO?STOP_YES:NAV+MODES,ACCENT,0x10292e);break;
 case CONFIRM:header(m,s,"İnfüzyonu sonlandır",HOME);s.text(40,116,720,98,"Mevcut infüzyon sonlandırılsın mı?",30,TEXT,1);s.button(32,270,354,78,"Vazgeç",NAV+HOME);s.button(408,270,354,78,"Sonlandır",STOP_YES,0x372024,DANGER);break;
 case CHECK:header(m,s,m.state==ALARM?"Alarm":"Cihaz Hazırlığı");if(m.state==ALARM){s.text(32,90,730,100,m.error[0]?m.error:"Demo alarmı aktif",30,DANGER,1);s.button(32,222,354, 70,m.muted?"Ses kapalı":"Sesi sustur",MUTE);s.button(408,222,354,70,"Demo alarmını gider",CLEAR_ALARM,EDIT_BG,ACCENT);s.text(32,318,730,46,"Giderildikten sonra Devam onayı gerekir.",18,DIM,1);}else{s.text(32,86,730,162,"Kapak / set: donanım bağlantısı bekleniyor\nUP / DOWN: sensör bağlantısı bekleniyor\nArayüz demo durumu: hazır",22,DIM);s.button(32,288,730,70,"Hat Doldurma",NAV+PRIME);}break;
 case PRIME:header(m,s,"Hat Doldurma",CHECK);fmt(b,sizeof b,m.primeVolume,"mL");s.text(32,92,730,60,b,48,ACCENT,1);s.text(32,174,730,62,"Basılı tutarken demo hacmi artar.\nBırakınca durur.",20,DIM,1);s.button(120,268,560,88,m.primeActive?"Bırakınca durur":"Basılı tut · Hat doldur",HOLD_PRIME,ACCENT,0x10292e);break;
 default:header(m,s,"VENA");break;
 }
 if(m.error[0]&&m.page!=CHECK&&m.page!=PARAMS){s.box(16,375,768,33,bgColor);s.text(22,379,756,28,m.error,14,DANGER,1);}
}
void sliderSet(Model&m,Field f,int x,int width){if(width<=0)return;double value=std::max(0.,std::min(100.,100.*x/width));if(f==BRIGHTNESS)value=std::max(10.,value);m.v[f]=floor(value+.5);m.dirty=true;}
void dispatch(Model&m,int a,bool pressed,bool released){
 if(a==HOLD_BOLUS){if(pressed)m.beginBolus(true);if(released&&m.bolusManual)m.endBolus();m.dirty=true;return;}
 if(a==HOLD_PRIME){if(pressed&&!m.busy())m.primeActive=true;if(released)m.primeActive=false;m.dirty=true;return;}
 if(pressed||released)return;
 if(a>=NAV&&a<NAV+100){Page p=(Page)(a-NAV);if(p==MODES&&m.busy()){snprintf(m.error,sizeof m.error,"Önce aktif infüzyonu sonlandırın.");m.dirty=true;return;}if(p==PIN){if(m.busy()){snprintf(m.error,sizeof m.error,"Aktif infüzyonda servis açılamaz.");m.dirty=true;return;}m.entry[0]=0;}if(p==CHECK&&m.state==ALARM){m.page=CHECK;m.dirty=true;return;}m.navigate(p);return;}
 if(a>=EDIT&&a<EDIT+NFIELDS){m.edit((Field)(a-EDIT),m.page);return;}
 if(a>=SELECT_MODE&&a<SELECT_MODE+9){if(m.busy())return;m.newProgram((Mode)(a-SELECT_MODE));m.navigate(PARAMS);return;}
 if(a>=SELECT_DRUG&&a<SELECT_DRUG+8){if(m.busy()){snprintf(m.error,sizeof m.error,"Aktif tedavide ilaç değiştirilemez.");m.dirty=true;return;}m.selectedDrug=a-SELECT_DRUG;snprintf(m.drugName,sizeof m.drugName,"%s",Model::drugLabel(m.selectedDrug));m.navigate(DRUG_DETAIL);return;}
 if(a>=SELECT_PATIENT&&a<SELECT_PATIENT+12){if(m.busy()){snprintf(m.error,sizeof m.error,"Aktif tedavide hasta değiştirilemez.");m.dirty=true;return;}m.selectedPatient=a-SELECT_PATIENT;snprintf(m.patientName,sizeof m.patientName,"%s",m.patients[m.selectedPatient].name);m.navigate(PATIENT_CONFIRM);return;}
 if(a>=KEY&&a<KEY+128){m.key(char(a-KEY));return;}
 // Text/PIN action ranges are separate from all enumerated commands.
 if(a>=1000&&a<1128){size_t n=strlen(m.entry);if(n<8){m.entry[n]=char(a-1000);m.entry[n+1]=0;}m.dirty=true;return;}
 if(a>=1200&&a<1328){size_t n=strlen(m.entry);size_t limit=m.textField==1?23:m.textField==2?31:47;if(n<limit){m.entry[n]=char(a-1200);m.entry[n+1]=0;}m.dirty=true;return;}
 switch(a){
 case START:m.start();break;
 case PRIMARY:if(m.state==RUNNING)m.pause();else if(m.state==PAUSED)m.resume();else if(m.state==ALARM){m.page=CHECK;}else if(m.state==KVO)m.navigate(RESULT);else m.navigate(MODES);break;
 case STOP_CONFIRM:m.navigate(CONFIRM);break;case STOP_YES:m.stop();break;
 case ACCEPT:m.accept();break;case CLEAR:m.key('C');break;case BACKSPACE:{size_t n=strlen(m.entry);if(n)m.entry[n-1]=0;}break;
 case PAIR:if(!m.busy()){m.derived=m.derived==MINUTES?RATE_F:m.derived==RATE_F?VOLUME:MINUTES;}break;
 case SEQ1:case SEQ2:case SEQ3:m.seqTab=a-SEQ1;break;
 case AUTO_BOLUS:m.beginBolus(false);break;case STOP_BOLUS:m.endBolus();m.navigate(BOLUS_DONE);break;
 case TOGGLE_KVO:m.kvoEnabled=!m.kvoEnabled;break;case TOGGLE_LIGHT:m.light=!m.light;break;
 case MUTE:m.muted=!m.muted;break;case CLEAR_ALARM:m.clearAlarm();m.navigate(HOME);break;
 case TEST_ALARM:m.raiseAlarm("Demo: downstream tıkanıklık");m.page=CHECK;break;
 case PIN_ACCEPT:if(!strcmp(m.entry,"0000")){m.serviceUnlocked=true;m.page=SERVICE;m.error[0]=0;}else snprintf(m.error,sizeof m.error,"PIN yanlış.");break;
 case PIN_CLEAR:m.entry[0]=0;break;
 case NEW_PATIENT:if(!m.busy()){memset(&m.draft,0,sizeof m.draft);m.textField=-1;m.formAge=30;m.formGender=0;m.navigate(PATIENT_FORM);}break;
 case TEXT_NAME:case TEXT_CODE:case TEXT_WARD:m.textField=a==TEXT_NAME?0:a==TEXT_CODE?1:2;snprintf(m.entry,sizeof m.entry,"%s",m.textField==0?m.draft.name:m.textField==1?m.draft.code:m.draft.ward);break;
 case SAVE_TEXT:if(m.textField==0)snprintf(m.draft.name,sizeof m.draft.name,"%.47s",m.entry);if(m.textField==1)snprintf(m.draft.code,sizeof m.draft.code,"%.23s",m.entry);if(m.textField==2)snprintf(m.draft.ward,sizeof m.draft.ward,"%.31s",m.entry);m.textField=-1;break;
 case SAVE_PATIENT:m.savePatient();break;case GENDER:m.formGender=!m.formGender;break;case AGE_PLUS:m.formAge=std::min(120,m.formAge+1);break;case AGE_MINUS:m.formAge=std::max(0,m.formAge-1);break;
 case FILTER_GENDER:m.filterGender=m.filterGender==1?-1:m.filterGender+1;break;case FILTER_DRUG:m.filterDrug=m.filterDrug==7?-1:m.filterDrug+1;break;
 case RESET_FILTERS:m.filterGender=m.filterDrug=-1;m.v[AGE_MIN]=m.v[AGE_MAX]=NAN;break;
 case SERVICE_SAVE:if(isfinite(m.v[SET_VOLUME]))m.log("Set kalibrasyon taslağı kaydedildi");else snprintf(m.error,sizeof m.error,"Önce set hacmini girin.");break;
 case CHANNEL_UP:m.settingChannel=0;break;case CHANNEL_DOWN:m.settingChannel=1;break;
 case LOCK:m.locked=true;m.navigate(HOME);break;case UNLOCK:m.locked=false;break;
 default:break;
 }m.dirty=true;
}
}
