#ifndef VENA_PORT_MODEL_HPP
#define VENA_PORT_MODEL_HPP
#include <stdint.h>
#include <stddef.h>
#include <gui/vena/SensorPort.hpp>
namespace vena {
enum Page { HOME=1,MENU,MODES,MORE,PARAMS,NUMPAD,BOLUS,BOLUS_DONE,SETTINGS,GENERAL,DISPLAY,AUDIO,LANGUAGE,CLOCK,INF_SETTINGS,PRESSURE,AIR,KVO_SETTINGS,BOLUS_SETTINGS,SYSTEM,PIN,SERVICE,SENSORS,CALIBRATION,SERVICE_RECORDS,PATIENTS,PATIENT_FORM,PATIENT_CONFIRM,DRUGS,DRUG_DETAIL,REPORTS,FILTERS,REPORT_LIST,HISTORY,RESULT,CONFIRM=42,CHECK,PRIME };
enum Mode { RATE,TIME,SEQUENCE,PIGGYBACK,WEIGHT,TPN,INTERMITTENT,MICRO,TRAPEZOID };
enum State { READY,RUNNING,PAUSED,ALARM,COMPLETE,KVO,STOPPED };
enum Field { RATE_F,VOLUME,MINUTES,DOSE,WEIGHT_F,DRUG_AMOUNT,DILUENT,EACH,DOSE_MIN,INTERVAL,COUNT,R1,V1,R2,V2,R3,V3,SECONDARY,SECOND_RATE,RISE,PLATEAU,FALL,BOL_VOLUME,BOL_SECONDS,BOL_RATE,KVO_RATE,KVO_MIN,BRIGHTNESS,SOUND,UP_LOW,UP_HIGH,DOWN_LOW,DOWN_HIGH,AIR_SINGLE,AIR_TOTAL,AGE_MIN,AGE_MAX,SET_VOLUME,NFIELDS };
struct FieldDef { const char* label; const char* unit; double low,high; unsigned decimals; };
struct Step { double rate, seconds; int kind; }; // 0 constant, 1 rise, 2 fall, 3 wait
struct Patient { char name[48],code[24],ward[32]; int age,gender; double weight; };
struct Record { char patient[48],drug[40]; int mode,age,gender; double volume; uint32_t seconds; };
class Model {
public:
 Model();
 SensorSnapshot sensors;
 void refreshSensors();
 Page page,returnPage,editReturn; Mode mode; State state; Field editing;
 double v[NFIELDS],elapsed,delivered,bolusDelivered,bolusElapsed,bolusGoal,bolusDuration,bolusRate,primeVolume,kvoElapsed;
 double planVolume,planSeconds,planRate,stepElapsed; Step steps[40]; int stepCount,stepIndex,seqTab,derived;
 bool bolusActive,bolusManual,primeActive,kvoEnabled,muted,serviceUnlocked,dirty,light,locked;
 char entry[96],error[128],patientName[48],drugName[40],history[24][96];
 int historyCount,selectedPatient,selectedDrug,patientCount,recordCount,filterGender,filterDrug,settingChannel,textField,formAge,formGender,brightness,sound;
 Patient patients[12],draft; Record records[24];
 void navigate(Page p); void newProgram(Mode m); bool set(Field f,double value); bool validate(); bool calculate();
 bool start(); void pause(); bool resume(); void stop(); void raiseAlarm(const char* reason); void clearAlarm();
 bool beginBolus(bool manual); void endBolus(); void tick(double seconds); void complete();
 void edit(Field f,Page back); void key(char c); bool accept(); void log(const char* s);
 void finishRecord(const char* result); void savePatient(); int matchingRecords() const;
 const char* stateName() const; const char* modeName() const; const FieldDef& definition(Field f) const;
 bool canEdit(Field f) const; void syncMotor(); bool motorProgramValid();
 bool busy() const; double rateNow() const; double remaining() const; double remainingSeconds() const;
 static const char* modeLabel(int m); static const char* drugLabel(int i);
 static const FieldDef fields[NFIELDS];
private: bool replaceEntry,recordOpen; void addStep(double rate,double seconds,int kind=0); void applyDerived(Field changed);
};
Model& model();
}
#endif
