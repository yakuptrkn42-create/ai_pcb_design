#ifndef SENSOR_CONFIG_H
#define SENSOR_CONFIG_H

/* PC5 and PC4 are not used by this project's motor, SDRAM, QSPI, touch or SD.
 * Use MCU signal names; verify their connector positions against your board.
 * Inputs MUST be conditioned to 0..3.3 V. Never connect an unknown sensor
 * supply/output directly to these pins. See SENSOR_ENTEGRASYONU_TR.md. */
#define SENSOR_OPTICAL_PORT GPIOC
#define SENSOR_OPTICAL_PIN  GPIO_PIN_5
#define SENSOR_AIR_PORT     GPIOC
#define SENSOR_AIR_PIN      GPIO_PIN_4
/* Existing onboard LEDs, active LOW: LED1 green and LED3 red. */
#define SENSOR_OPTICAL_LED_PORT GPIOG
#define SENSOR_OPTICAL_LED_PIN  GPIO_PIN_6
#define SENSOR_AIR_LED_PORT     GPIOD
#define SENSOR_AIR_LED_PIN      GPIO_PIN_5

#define SENSOR_OPTICAL_DEBOUNCE_MS 20U
#define SENSOR_AIR_HOLD_MS         2000U
#define SENSOR_STALE_MS             100U
/* BS241 supplied datasheet, page 1: bubble = LOW (0.2..0.5 V),
 * no bubble = HIGH (minimum 2.4 V, typical 4.3 V), supply 4.5..5.5 V.
 * Use a NONINVERTING TTL-compatible 5V-input-tolerant level buffer to 3.3 V.
 * Page 2: blue=GND, red=Vcc, white=output; a black wire is NOT identified.
 * Confirm the actual four-wire variant before connecting its wires.
 * Set CONFIRMED to 0 only for raw 0/1 commissioning display. */
#ifndef SENSOR_AIR_ACTIVE_LEVEL
#define SENSOR_AIR_ACTIVE_LEVEL 0U
#endif
#ifndef SENSOR_AIR_POLARITY_CONFIRMED
#define SENSOR_AIR_POLARITY_CONFIRMED 1U
#endif
#if (SENSOR_AIR_ACTIVE_LEVEL > 1U) || (SENSOR_AIR_POLARITY_CONFIRMED > 1U)
#error Sensor air configuration must be 0 or 1
#endif
#endif
